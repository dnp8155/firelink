import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';

// Books a Porter delivery for a vendor shipment.
// Requires PORTER_API_KEY in app secrets.
// Porter API docs: https://dev.porter.in/
export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { pickup_address, drop_address, pickup_lat, pickup_lng, drop_lat, drop_lng, package_details } = body || {};

    if (!pickup_address || !drop_address) {
      return Response.json({ error: 'pickup_address and drop_address are required' }, { status: 400 });
    }

    const apiKey = secrets.get('PORTER_API_KEY');
    if (!apiKey) {
      return Response.json({ error: 'Porter is not configured. Add PORTER_API_KEY in app secrets.' }, { status: 503 });
    }

    // Create a Porter delivery quote / booking (using Porter's Brew API)
    const porterRes = await fetch('https://api.porter.in/v1/deliveries', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        pickup_details: {
          address: { full_address: pickup_address },
          lat: pickup_lat || undefined,
          lng: pickup_lng || undefined,
        },
        drop_details: {
          address: { full_address: drop_address },
          lat: drop_lat || undefined,
          lng: drop_lng || undefined,
        },
        package_details: package_details || { quantity: 1 },
      }),
    });

    if (!porterRes.ok) {
      const err = await porterRes.json().catch(() => ({}));
      return Response.json({ error: err.message || err.error?.message || 'Porter booking failed' }, { status: 502 });
    }

    const delivery = await porterRes.json();

    return Response.json({
      success: true,
      delivery_id: delivery.delivery_id || delivery.order_id,
      status: delivery.status || 'booked',
      fare: delivery.fare || delivery.estimated_price,
      tracking_url: delivery.tracking_url,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}