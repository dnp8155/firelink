import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';

// Creates a Razorpay order for cart checkout payment.
// Requires RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET in app secrets.
export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { amount, order_id } = body || {};

    if (!amount || amount <= 0) {
      return Response.json({ error: 'A positive amount is required' }, { status: 400 });
    }

    const keyId = secrets.get('RAZORPAY_KEY_ID');
    const keySecret = secrets.get('RAZORPAY_KEY_SECRET');
    if (!keyId || !keySecret) {
      return Response.json({ error: 'Razorpay is not configured. Add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET in app secrets.' }, { status: 503 });
    }

    // Create Razorpay order (amount in paise for INR)
    const auth = btoa(`${keyId}:${keySecret}`);
    const rzpRes = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: String(Math.round(amount * 100)),
        currency: 'INR',
        receipt: order_id || `fl_${Date.now()}`,
        notes: { user_id: user.id, order_id: order_id || '' },
      }),
    });

    if (!rzpRes.ok) {
      const err = await rzpRes.json().catch(() => ({}));
      return Response.json({ error: err.error?.description || 'Razorpay order creation failed' }, { status: 502 });
    }

    const order = await rzpRes.json();

    return Response.json({
      success: true,
      razorpay_order_id: order.id,
      amount: order.amount,
      currency: order.currency,
      key_id: keyId,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}