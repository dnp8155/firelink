import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

// Transactional vendor notifications — admin-triggered only.
// Each type is a fixed template; the vendor (and product) is resolved
// server-side so the client can't choose arbitrary recipients or content.

const TEMPLATES = {
  vendor_approved: {
    subject: "Your FireLink vendor application is approved",
    link: "/vendor/dashboard",
    text: (v, extra) =>
      "Dear " + (v.contact_person || v.company_name) + ",\n\n" +
      "Congratulations! Your vendor application for " + v.company_name + " has been approved by the FireLink team.\n\n" +
      "Your Vendor Portal is now fully active. You can submit products for approval, respond to RFQs with quotations, and start receiving orders from FireLink customers.\n\n" +
      "Welcome aboard!\n— Team FireLink",
  },
  vendor_rejected: {
    subject: "Your FireLink vendor application was not approved",
    link: "/vendor/verification",
    text: (v, extra) =>
      "Dear " + (v.contact_person || v.company_name) + ",\n\n" +
      "After reviewing your application for " + v.company_name + ", the FireLink team is unable to approve it at this time." +
      (extra.remarks ? "\n\nReviewer remarks: " + extra.remarks : "") +
      "\n\nYou can update your company profile and documents in the Verification Center, then contact FireLink support to re-apply.\n\n— Team FireLink",
  },
  documents_required: {
    subject: "Additional documents required — FireLink vendor application",
    link: "/vendor/verification",
    text: (v, extra) =>
      "Dear " + (v.contact_person || v.company_name) + ",\n\n" +
      "The FireLink verification team has requested additional documents or replacements for your vendor application of " + v.company_name + "." +
      (extra.remarks ? "\n\nRemarks: " + extra.remarks : "") +
      "\n\nPlease open the Verification Center in your Vendor Portal to upload the requested documents.\n\n— Team FireLink",
  },
  vendor_suspended: {
    subject: "Your FireLink vendor account is suspended",
    link: "/vendor/verification",
    text: (v, extra) =>
      "Dear " + (v.contact_person || v.company_name) + ",\n\n" +
      "Your FireLink vendor account for " + v.company_name + " has been suspended. Selling operations are currently locked." +
      (extra.remarks ? "\n\nReason: " + extra.remarks : "") +
      "\n\nPlease contact FireLink support to resolve this.\n\n— Team FireLink",
  },
  product_approved: {
    subject: "Your product is now live on FireLink",
    link: "/vendor/products",
    text: (v, extra) =>
      "Dear " + (v.contact_person || v.company_name) + ",\n\n" +
      "Great news — your product \"" + (extra.productName || "") + "\" has been approved and is now live on the FireLink marketplace. Customers can now discover and order it.\n\n— Team FireLink",
  },
  product_rejected: {
    subject: "Your product listing was not approved",
    link: "/vendor/products",
    text: (v, extra) =>
      "Dear " + (v.contact_person || v.company_name) + ",\n\n" +
      "Your product \"" + (extra.productName || "") + "\" could not be approved for the FireLink marketplace." +
      (extra.remarks ? "\n\nReviewer remarks: " + extra.remarks : "") +
      "\n\nYou can update the listing and resubmit it for review from the Products page.\n\n— Team FireLink",
  },
  product_disabled: {
    subject: "Your product listing has been disabled",
    link: "/vendor/products",
    text: (v, extra) =>
      "Dear " + (v.contact_person || v.company_name) + ",\n\n" +
      "Your product \"" + (extra.productName || "") + "\" has been disabled on the FireLink marketplace and is no longer visible to customers." +
      (extra.remarks ? "\n\nReason: " + extra.remarks : "") +
      "\n\nPlease contact FireLink support if you believe this is an error.\n\n— Team FireLink",
  },
};

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const payload = await req.json().catch(() => null);
    const type = payload && payload.type;
    const vendorId = payload && payload.vendor_id;
    if (!type || !vendorId) return Response.json({ error: 'type and vendor_id are required' }, { status: 400 });
    const template = TEMPLATES[type];
    if (!template) return Response.json({ error: 'Unknown notification type' }, { status: 400 });

    const extra = {
      productName: (payload && payload.product_name) || '',
      remarks: (payload && payload.remarks) || '',
    };

    const vendor = await base44.asServiceRole.entities.Vendor.get(vendorId).catch(() => null);
    if (!vendor) return Response.json({ error: 'Vendor not found' }, { status: 404 });

    const subject = template.subject;
    const text = template.text(vendor, extra);

    let emailSent = false;
    try {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: vendor.email,
        subject,
        from_name: 'FireLink',
        text,
      });
      emailSent = true;
    } catch (e) {
      // email delivery is best-effort (address may not be reachable yet)
    }

    let notified = false;
    try {
      const ownerId = vendor.owner_id || vendor.created_by_id;
      if (ownerId) {
        await base44.asServiceRole.entities.AppNotification.create({
          user_id: ownerId,
          title: subject,
          message: text.slice(0, 280),
          type: 'system',
          link: template.link,
        });
        notified = true;
      }
    } catch (e) {
      // in-app notification is best-effort
    }

    return Response.json({ ok: true, email_sent: emailSent, notified });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}