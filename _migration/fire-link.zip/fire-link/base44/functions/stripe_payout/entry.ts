import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';

// Creates a Stripe payout for a vendor wallet withdrawal.
// The Stripe secret key must be set as STRIPE_SECRET_KEY in app secrets.
export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { wallet_id, amount } = body || {};

    if (!wallet_id || !amount || amount <= 0) {
      return Response.json({ error: 'wallet_id and a positive amount are required' }, { status: 400 });
    }

    const stripeKey = secrets.get('STRIPE_SECRET_KEY');
    if (!stripeKey) return Response.json({ error: 'Stripe is not configured. Add STRIPE_SECRET_KEY in app secrets.' }, { status: 503 });

    // Verify wallet ownership
    const wallet = await base44.entities.VendorWallet.get(wallet_id);
    if (!wallet) return Response.json({ error: 'Wallet not found' }, { status: 404 });
    const vid = user.data?.vendor_id || user.id;
    if (wallet.vendor_id !== vid && user.role !== 'admin') {
      return Response.json({ error: 'Not your wallet' }, { status: 403 });
    }
    if ((wallet.balance || 0) < amount) {
      return Response.json({ error: 'Insufficient balance' }, { status: 400 });
    }

    // Create Stripe payout (amount in paise for INR)
    const stripeRes = await fetch('https://api.stripe.com/v1/payouts', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${stripeKey}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        amount: String(Math.round(amount * 100)),
        currency: 'inr',
        description: `FireLink vendor payout — ${wallet.vendor_name || ''}`.trim(),
      }),
    });

    if (!stripeRes.ok) {
      const err = await stripeRes.json().catch(() => ({}));
      return Response.json({ error: err.error?.message || 'Stripe payout failed' }, { status: 502 });
    }

    const payout = await stripeRes.json();

    // Record the debit transaction
    const tx = {
      type: 'debit',
      amount,
      description: 'Withdrawal to bank (Stripe)',
      reference: payout.id,
      date: new Date().toISOString(),
    };
    await base44.entities.VendorWallet.update(wallet_id, {
      balance: (wallet.balance || 0) - amount,
      transactions: [tx, ...(wallet.transactions || [])],
    });

    return Response.json({ success: true, payout_id: payout.id, status: payout.status });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}