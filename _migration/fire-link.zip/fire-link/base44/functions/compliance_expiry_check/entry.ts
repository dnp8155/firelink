import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

// Compliance auto-expiry checker.
// Scans all Certificates and NOCs, and for those expiring in 60/30/7 days
// sends an email to the organization's contact and an in-app notification
// to the record owner. De-duplicated via AppNotification title pattern.

const THRESHOLDS = [60, 30, 7];
const MS_PER_DAY = 24 * 60 * 60 * 1000;

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const d = new Date(dateStr + "T00:00:00");
  if (isNaN(d.getTime())) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.round((d.getTime() - today.getTime()) / MS_PER_DAY);
}

function thresholdFor(daysLeft) {
  // Match to the nearest defined threshold (exact day, ±1 for safety)
  for (const t of THRESHOLDS) {
    if (Math.abs(daysLeft - t) <= 1) return t;
  }
  return null;
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);

    // Allow both admin manual-run and scheduled (no-user) invocation
    const user = await base44.auth.me().catch(() => null);
    const isManualRun = !!user;
    if (isManualRun && user.role !== "admin") {
      return Response.json({ error: "Forbidden — admin only" }, { status: 403 });
    }

    const notified = [];
    const skipped = [];

    // ---- Certificates ----
    const certs = await base44.asServiceRole.entities.Certificate.list("-expiry_date", 500);
    for (const cert of (certs || [])) {
      const dl = daysUntil(cert.expiry_date);
      if (dl == null || dl < 0) continue;
      const t = thresholdFor(dl);
      if (!t) continue;

      // De-dup: skip if a notification with the exact dedup title already exists
      const dedupTitle = `[Compliance] ${cert.title || "Certificate"} expires in ${t} days (${cert.certificate_number || cert.id})`;
      const existing = await base44.asServiceRole.entities.AppNotification
        .filter({ title: dedupTitle }, "-created_date", 1).catch(() => []);
      if (existing && existing.length) { skipped.push(dedupTitle); continue; }

      // Resolve org contact email
      let orgEmail = null;
      let ownerId = cert.created_by_id;
      if (cert.organization_id) {
        const org = await base44.asServiceRole.entities.Organization.get(cert.organization_id).catch(() => null);
        if (org) {
          orgEmail = org.email || null;
          if (org.owner_id) ownerId = org.owner_id;
        }
      }

      const body =
        "Dear Team,\n\n" +
        `This is an automated reminder that the following fire-safety certificate is expiring soon:\n\n` +
        `Certificate: ${cert.title || "—"}\n` +
        `Number: ${cert.certificate_number || "—"}\n` +
        `Expiry Date: ${cert.expiry_date}\n` +
        `Days remaining: ${dl}\n\n` +
        `Please initiate the renewal process immediately to stay compliant.\n\n` +
        `— Team FireLink Compliance Monitor`;

      if (orgEmail) {
        try {
          await base44.asServiceRole.integrations.Core.SendEmail({
            to: orgEmail,
            subject: dedupTitle,
            from_name: "FireLink Compliance",
            text: body,
          });
        } catch (e) { /* best-effort */ }
      }

      if (ownerId) {
        try {
          await base44.asServiceRole.entities.AppNotification.create({
            user_id: ownerId,
            title: dedupTitle,
            message: `${cert.title || "Certificate"} expires on ${cert.expiry_date} (${dl} days left). Schedule renewal now.`,
            type: "certificate",
            link: "/certificates",
          });
        } catch (e) { /* best-effort */ }
      }

      notified.push(dedupTitle);
    }

    // ---- NOCs ----
    const nocs = await base44.asServiceRole.entities.NOC.list("-expiry_date", 500);
    for (const noc of (nocs || [])) {
      const dl = daysUntil(noc.expiry_date);
      if (dl == null || dl < 0) continue;
      const t = thresholdFor(dl);
      if (!t) continue;

      const dedupTitle = `[Compliance] Fire NOC ${noc.noc_number || noc.id} expires in ${t} days`;
      const existing = await base44.asServiceRole.entities.AppNotification
        .filter({ title: dedupTitle }, "-created_date", 1).catch(() => []);
      if (existing && existing.length) { skipped.push(dedupTitle); continue; }

      let orgEmail = null;
      let ownerId = noc.created_by_id;
      if (noc.organization_id) {
        const org = await base44.asServiceRole.entities.Organization.get(noc.organization_id).catch(() => null);
        if (org) { orgEmail = org.email || null; if (org.owner_id) ownerId = org.owner_id; }
      }

      const body =
        "Dear Team,\n\n" +
        `Your Fire NOC (number ${noc.noc_number || "—"}) issued by ${noc.authority || "the authority"} is expiring soon.\n\n` +
        `Expiry Date: ${noc.expiry_date}\nDays remaining: ${dl}\n\n` +
        `Please initiate the renewal process to maintain compliance.\n\n— Team FireLink Compliance Monitor`;

      if (orgEmail) {
        try {
          await base44.asServiceRole.integrations.Core.SendEmail({
            to: orgEmail,
            subject: dedupTitle,
            from_name: "FireLink Compliance",
            text: body,
          });
        } catch (e) { /* best-effort */ }
      }

      if (ownerId) {
        try {
          await base44.asServiceRole.entities.AppNotification.create({
            user_id: ownerId,
            title: dedupTitle,
            message: `Fire NOC ${noc.noc_number || ""} expires on ${noc.expiry_date} (${dl} days left). Renew now.`,
            type: "noc",
            link: "/fire-noc",
          });
        } catch (e) { /* best-effort */ }
      }

      notified.push(dedupTitle);
    }

    return Response.json({
      ok: true,
      checked_certificates: (certs || []).length,
      checked_nocs: (nocs || []).length,
      notified: notified.length,
      skipped_duplicates: skipped.length,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}