import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { useRole } from "@/lib/RoleContext";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { ClipboardCheck, Plus, ArrowRight, CalendarDays } from "lucide-react";

const NEXT_STATUS = { open: "assigned", assigned: "in_progress", in_progress: "awaiting_verification", awaiting_verification: "closed" };

export default function CAPA() {
  const { data: capas, loading, reload } = useList("CAPA", {}, "-created_date", 100);
  const { activeRole } = useRole();
  const { toast } = useToast();
  const canManage = ["org_admin", "platform_admin", "super_admin"].includes(activeRole);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ finding: "", asset_name: "", severity: "medium", responsible_person: "", target_date: "", corrective_action: "", preventive_action: "" });

  const submit = async () => {
    if (!form.finding) { toast({ title: "Finding is required", variant: "destructive" }); return; }
    setSaving(true);
    try {
      await base44.entities.CAPA.create({ capa_number: "CAPA-" + Date.now().toString().slice(-5), ...form, status: "open" });
      toast({ title: "CAPA created" });
      setOpen(false);
      setForm({ finding: "", asset_name: "", severity: "medium", responsible_person: "", target_date: "", corrective_action: "", preventive_action: "" });
      reload();
    } catch (e) {
      toast({ title: "Failed to create CAPA", description: e.message, variant: "destructive" });
    } finally { setSaving(false); }
  };

  const advance = async (c) => {
    const next = NEXT_STATUS[c.status];
    if (!next) return;
    try {
      await base44.entities.CAPA.update(c.id, { status: next });
      toast({ title: `Moved to ${next.replace(/_/g, " ")}`, description: c.capa_number });
      reload();
    } catch (e) {
      toast({ title: "Update failed", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div>
      <PageHeader
        title="CAPA"
        icon={ClipboardCheck}
        subtitle="Corrective and Preventive Actions for audit findings."
        actions={canManage ? <Button onClick={() => setOpen(true)}><Plus className="h-4 w-4" /> New CAPA</Button> : null}
      />
      {loading ? (
        <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-28 animate-pulse rounded-2xl bg-slate-100" />)}</div>
      ) : capas.length === 0 ? (
        <SectionCard><EmptyState icon={ClipboardCheck} title="No CAPA records" description="Findings from inspections and audits are tracked here." /></SectionCard>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {capas.map((c) => (
            <SectionCard key={c.id}>
              <div className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-mono text-xs text-slate-400">{c.capa_number}</p>
                    <p className="mt-1 text-sm font-semibold text-slate-900">{c.finding}</p>
                  </div>
                  <StatusBadge status={c.status} tone={statusTone(c.status)} />
                </div>
                <div className="mt-3 flex flex-wrap gap-2 text-[11px]">
                  <span className="rounded-full bg-slate-100 px-2 py-1 font-medium text-slate-600">{c.asset_name || "General"}</span>
                  <StatusBadge status={c.severity} tone={c.severity === "critical" ? "red" : c.severity === "high" ? "amber" : "slate"} />
                  {c.target_date && <span className="flex items-center gap-1 rounded-full bg-slate-100 px-2 py-1 font-medium text-slate-600"><CalendarDays className="h-3 w-3" /> {c.target_date}</span>}
                </div>
                {c.corrective_action && <p className="mt-3 text-xs text-slate-500"><span className="font-semibold text-slate-700">Corrective:</span> {c.corrective_action}</p>}
                {c.preventive_action && <p className="mt-1 text-xs text-slate-500"><span className="font-semibold text-slate-700">Preventive:</span> {c.preventive_action}</p>}
                {canManage && NEXT_STATUS[c.status] && (
                  <Button size="sm" variant="outline" className="mt-4" onClick={() => advance(c)}>
                    Move to {NEXT_STATUS[c.status].replace(/_/g, " ")} <ArrowRight className="h-3.5 w-3.5" />
                  </Button>
                )}
              </div>
            </SectionCard>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>New CAPA</DialogTitle></DialogHeader>
          <div className="space-y-4 py-1">
            <div className="space-y-1.5">
              <Label>Finding</Label>
              <Textarea value={form.finding} onChange={(e) => setForm({ ...form, finding: e.target.value })} placeholder="What was found during inspection/audit?" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Asset</Label>
                <Input value={form.asset_name} onChange={(e) => setForm({ ...form, asset_name: e.target.value })} placeholder="Asset name (optional)" />
              </div>
              <div className="space-y-1.5">
                <Label>Severity</Label>
                <select value={form.severity} onChange={(e) => setForm({ ...form, severity: e.target.value })} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-rose-300">
                  <option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="critical">Critical</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Responsible Person</Label>
                <Input value={form.responsible_person} onChange={(e) => setForm({ ...form, responsible_person: e.target.value })} placeholder="Name" />
              </div>
              <div className="space-y-1.5">
                <Label>Target Date</Label>
                <Input type="date" value={form.target_date} onChange={(e) => setForm({ ...form, target_date: e.target.value })} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Corrective Action</Label>
              <Textarea value={form.corrective_action} onChange={(e) => setForm({ ...form, corrective_action: e.target.value })} placeholder="Action to fix the issue…" />
            </div>
            <div className="space-y-1.5">
              <Label>Preventive Action</Label>
              <Textarea value={form.preventive_action} onChange={(e) => setForm({ ...form, preventive_action: e.target.value })} placeholder="Action to prevent recurrence…" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={submit} disabled={saving}>{saving ? "Creating…" : "Create CAPA"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}