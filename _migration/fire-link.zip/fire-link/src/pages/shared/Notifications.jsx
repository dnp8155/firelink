import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { useAuth } from "@/lib/AuthContext";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Bell, CheckCheck, Package, FileText, Award, Wrench, LifeBuoy } from "lucide-react";
import { cn } from "@/lib/utils";

const TYPE_ICON = { order: Package, rfq: FileText, quote: FileText, certificate: Award, service: Wrench, ticket: LifeBuoy };

export default function Notifications() {
  const { data, loading, reload } = useList("AppNotification", {}, "-created_date", 100);
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const mine = data.filter((n) => !n.user_id || n.user_id === "demo" || n.user_id === user?.id);
  const unread = mine.filter((n) => !n.read).length;

  const openNotification = async (n) => {
    try { if (!n.read) await base44.entities.AppNotification.update(n.id, { read: true }); } catch {}
    if (n.link) navigate(n.link);
    else reload();
  };

  const markAll = async () => {
    try {
      await base44.entities.AppNotification.updateMany({ read: false }, { $set: { read: true } });
      toast({ title: "All caught up", description: "All notifications marked as read." });
      reload();
    } catch (e) {
      toast({ title: "Failed", description: e.message, variant: "destructive" });
    }
  };

  useEffect(() => { document.title = `Notifications${unread ? ` (${unread})` : ""} · Fire & Safety Connect`; }, [unread]);

  return (
    <div>
      <PageHeader
        title="Notifications"
        icon={Bell}
        subtitle={unread ? `${unread} unread notification${unread !== 1 ? "s" : ""}` : "You're all caught up."}
        actions={unread > 0 ? <Button variant="outline" onClick={markAll}><CheckCheck className="h-4 w-4" /> Mark all read</Button> : null}
      />
      {loading ? (
        <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-slate-100" />)}</div>
      ) : mine.length === 0 ? (
        <SectionCard><EmptyState icon={Bell} title="No notifications" description="Order updates, quote replies and compliance alerts will show up here." /></SectionCard>
      ) : (
        <SectionCard>
          <div className="divide-y divide-slate-50">
            {mine.map((n) => {
              const Icon = TYPE_ICON[n.type] || Bell;
              return (
                <button key={n.id} onClick={() => openNotification(n)} className="flex w-full items-center gap-3 px-5 py-3.5 text-left transition hover:bg-slate-50">
                  <div className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-lg", n.read ? "bg-slate-100 text-slate-400" : "bg-rose-50 text-rose-600")}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className={cn("text-sm", n.read ? "font-normal text-slate-600" : "font-semibold text-slate-900")}>{n.title}</p>
                    <p className="truncate text-xs text-slate-500">{n.message}</p>
                  </div>
                  {!n.read && <span className="h-2 w-2 shrink-0 rounded-full bg-rose-500" />}
                </button>
              );
            })}
          </div>
        </SectionCard>
      )}
    </div>
  );
}