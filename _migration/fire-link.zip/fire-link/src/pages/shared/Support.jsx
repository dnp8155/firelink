import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { useAuth } from "@/lib/AuthContext";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { LifeBuoy, Plus, Clock } from "lucide-react";

const CATEGORIES = ["order", "payment", "product", "rfq", "asset", "certificate", "compliance", "service", "technical"];

export default function Support() {
  const { data: tickets, loading, reload } = useList("SupportTicket", {}, "-created_date", 100);
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ subject: "", category: "order", priority: "medium", description: "" });

  const submit = async () => {
    if (!form.subject) { toast({ title: "Please add a subject", variant: "destructive" }); return; }
    setSaving(true);
    try {
      await base44.entities.SupportTicket.create({
        ticket_number: "TKT-" + Date.now().toString().slice(-6),
        subject: form.subject,
        category: form.category,
        priority: form.priority,
        description: form.description,
        user_id: user?.id || "demo",
        user_name: user?.full_name || "Demo User",
        status: "open",
      });
      toast({ title: "Ticket created", description: "Our support team will respond shortly." });
      setOpen(false);
      setForm({ subject: "", category: "order", priority: "medium", description: "" });
      reload();
    } catch (e) {
      toast({ title: "Failed to create ticket", description: e.message, variant: "destructive" });
    } finally { setSaving(false); }
  };

  return (
    <div>
      <PageHeader
        title="Help & Support"
        icon={LifeBuoy}
        subtitle="Raise a ticket and track its status."
        actions={<Button onClick={() => setOpen(true)}><Plus className="h-4 w-4" /> New Ticket</Button>}
      />
      {loading ? (
        <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-slate-100" />)}</div>
      ) : tickets.length === 0 ? (
        <SectionCard><EmptyState icon={LifeBuoy} title="No tickets" description="Any support tickets you raise will be tracked here." /></SectionCard>
      ) : (
        <SectionCard>
          <div className="divide-y divide-slate-50">
            {tickets.map((t) => (
              <div key={t.id} className="flex flex-col gap-2 px-5 py-4 sm:flex-row sm:items-center">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-mono text-xs text-slate-400">{t.ticket_number}</p>
                    <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-slate-500">{t.category}</span>
                    <StatusBadge status={t.priority} tone={t.priority === "urgent" ? "red" : t.priority === "high" ? "amber" : "slate"} />
                  </div>
                  <p className="mt-0.5 text-sm font-semibold text-slate-800">{t.subject}</p>
                  {t.description && <p className="line-clamp-1 text-xs text-slate-500">{t.description}</p>}
                </div>
                <div className="flex items-center gap-2">
                  <span className="flex items-center gap-1 text-[11px] text-slate-400"><Clock className="h-3 w-3" /> {t.created_date?.slice(0, 10)}</span>
                  <StatusBadge status={t.status} tone={statusTone(t.status)} />
                </div>
              </div>
            ))}
          </div>
        </SectionCard>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Raise a Support Ticket</DialogTitle></DialogHeader>
          <div className="space-y-4 py-1">
            <div className="space-y-1.5">
              <Label>Subject</Label>
              <Input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} placeholder="Briefly describe your issue" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Category</Label>
                <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm capitalize outline-none focus:border-rose-300">
                  {CATEGORIES.map((c) => <option key={c} value={c} className="capitalize">{c}</option>)}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label>Priority</Label>
                <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-rose-300">
                  <option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="urgent">Urgent</option>
                </select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Description</Label>
              <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Add any details that will help us resolve this faster…" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={submit} disabled={saving}>{saving ? "Creating…" : "Create Ticket"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}