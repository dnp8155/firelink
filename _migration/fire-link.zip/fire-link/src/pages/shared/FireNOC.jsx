import React from "react";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { useRole } from "@/lib/RoleContext";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Flame, CalendarDays, Landmark, RefreshCw } from "lucide-react";

export default function FireNOC() {
  const { data: docs, loading, reload } = useList("NOC", {}, "-expiry_date", 50);
  const { activeRole } = useRole();
  const { toast } = useToast();
  const canManage = ["customer", "org_admin", "super_admin", "platform_admin"].includes(activeRole);

  const startRenewal = async (doc) => {
    try {
      await base44.entities.NOC.update(doc.id, { status: "renewal_in_progress" });
      toast({ title: "Renewal initiated", description: `${doc.noc_number} — our team will follow up.` });
      reload();
    } catch (e) {
      toast({ title: "Failed to update", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div>
      <PageHeader title="Fire NOC" icon={Flame} subtitle="No Objection Certificates issued by fire authorities." />
      {loading ? (
        <div className="grid gap-4 lg:grid-cols-2">{Array.from({ length: 2 }).map((_, i) => <div key={i} className="h-44 animate-pulse rounded-2xl bg-slate-100" />)}</div>
      ) : docs.length === 0 ? (
        <SectionCard><EmptyState icon={Flame} title="No NOC records" description="Fire NOC records for your sites will appear here." /></SectionCard>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {docs.map((d) => (
            <SectionCard key={d.id}>
              <div className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-mono text-sm font-bold text-slate-900">{d.noc_number}</p>
                    <p className="mt-0.5 text-xs text-slate-500">{d.organization_name} · {d.site_name}</p>
                  </div>
                  <StatusBadge status={d.status} tone={statusTone(d.status)} />
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
                  <div className="rounded-xl bg-slate-50 p-3">
                    <p className="flex items-center gap-1.5 text-slate-500"><Landmark className="h-3.5 w-3.5" /> Authority</p>
                    <p className="mt-1 font-semibold text-slate-800">{d.authority}</p>
                  </div>
                  <div className="rounded-xl bg-slate-50 p-3">
                    <p className="flex items-center gap-1.5 text-slate-500"><CalendarDays className="h-3.5 w-3.5" /> Validity</p>
                    <p className="mt-1 font-semibold text-slate-800">{d.issue_date} → {d.expiry_date}</p>
                  </div>
                </div>
                {canManage && ["valid", "expiring_soon", "expired"].includes(d.status) && (
                  <Button variant="outline" size="sm" className="mt-4" onClick={() => startRenewal(d)}>
                    <RefreshCw className="h-3.5 w-3.5" /> Request Renewal
                  </Button>
                )}
              </div>
            </SectionCard>
          ))}
        </div>
      )}
    </div>
  );
}