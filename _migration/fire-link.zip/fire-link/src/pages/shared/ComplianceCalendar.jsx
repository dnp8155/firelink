import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useList } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/lib/AuthContext";
import {
  Calendar, Award, Flame, AlertTriangle, CheckCircle2, Bell, RefreshCw,
  ChevronLeft, ChevronRight, ShieldCheck,
} from "lucide-react";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const DAYS_IN_WEEK = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function daysInMonth(year, month) {
  return new Date(year, month + 1, 0).getDate();
}
function firstDayOfMonth(year, month) {
  return new Date(year, month, 1).getDay();
}

export default function ComplianceCalendar() {
  const { user } = useAuth();
  const { toast } = useToast();
  const certs = useList("Certificate", {}, "expiry_date", 500);
  const nocs = useList("NOC", {}, "expiry_date", 500);
  const capas = useList("CAPA", {}, "-created_date", 200);
  const [cursor, setCursor] = useState(() => { const d = new Date(); return { y: d.getFullYear(), m: d.getMonth() }; });
  const [running, setRunning] = useState(false);

  const events = useMemo(() => {
    const map = {};
    const add = (dateStr, item, type) => {
      if (!dateStr) return;
      const key = dateStr.slice(0, 10);
      if (!map[key]) map[key] = [];
      map[key].push({ ...item, _type: type });
    };
    (certs.data || []).forEach((c) => add(c.expiry_date, c, "certificate"));
    (nocs.data || []).forEach((n) => add(n.expiry_date, n, "noc"));
    (capas.data || []).forEach((c) => add(c.target_date || c.due_date, c, "capa"));
    return map;
  }, [certs.data, nocs.data, capas.data]);

  const today = new Date();
  const todayKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;

  // Upcoming alerts (next 90 days) sorted
  const upcoming = useMemo(() => {
    const items = [];
    const now = Date.now();
    const addItems = (list, type) => {
      (list || []).forEach((item) => {
        const dateStr = item.expiry_date || item.target_date || item.due_date;
        if (!dateStr) return;
        const diff = Math.ceil((new Date(dateStr).getTime() - now) / (24 * 60 * 60 * 1000));
        if (diff < 0 || diff > 90) return;
        items.push({ ...item, _type: type, _days: diff, _date: dateStr });
      });
    };
    addItems(certs.data, "certificate");
    addItems(nocs.data, "noc");
    addItems(capas.data, "capa");
    return items.sort((a, b) => a._days - b._days).slice(0, 12);
  }, [certs.data, nocs.data, capas.data]);

  const runCheck = async () => {
    setRunning(true);
    try {
      await base44.functions.invoke("compliance_expiry_check", {});
      toast({ title: "Compliance check completed", description: "Expiry alerts processed." });
      certs.reload();
      nocs.reload();
    } catch (e) {
      toast({ title: "Check failed", description: e.message, variant: "destructive" });
    } finally {
      setRunning(false);
    }
  };

  // Calendar grid
  const year = cursor.y, month = cursor.m;
  const dim = daysInMonth(year, month);
  const fd = firstDayOfMonth(year, month);
  const cells = [];
  for (let i = 0; i < fd; i++) cells.push(null);
  for (let d = 1; d <= dim; d++) cells.push(d);

  const expiringCount = upcoming.filter((i) => i._days <= 30).length;
  const expiredCount = upcoming.filter((i) => i._days <= 0).length + (certs.data.filter((c) => c.status === "expired").length) + (nocs.data.filter((n) => n.status === "expired").length);

  return (
    <div>
      <PageHeader
        title="Compliance Calendar"
        subtitle="Track certificate & NOC expiries, CAPA deadlines — never miss a renewal."
        icon={ShieldCheck}
        actions={
          <Button onClick={runCheck} disabled={running} variant="default" className="gap-1.5">
            {running ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Bell className="h-4 w-4" />}
            Run Expiry Check
          </Button>
        }
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex items-center gap-2 text-amber-600"><AlertTriangle className="h-4 w-4" /><span className="text-xs font-semibold uppercase tracking-wide">Expiring (≤30d)</span></div>
          <p className="mt-1.5 text-2xl font-bold text-slate-900">{expiringCount}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex items-center gap-2 text-rose-600"><Flame className="h-4 w-4" /><span className="text-xs font-semibold uppercase tracking-wide">Expired</span></div>
          <p className="mt-1.5 text-2xl font-bold text-slate-900">{expiredCount}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex items-center gap-2 text-violet-600"><Award className="h-4 w-4" /><span className="text-xs font-semibold uppercase tracking-wide">Certificates</span></div>
          <p className="mt-1.5 text-2xl font-bold text-slate-900">{certs.data.length}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex items-center gap-2 text-blue-600"><Flame className="h-4 w-4" /><span className="text-xs font-semibold uppercase tracking-wide">Fire NOCs</span></div>
          <p className="mt-1.5 text-2xl font-bold text-slate-900">{nocs.data.length}</p>
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        {/* Calendar */}
        <SectionCard title={`${MONTHS[month]} ${year}`} className="lg:col-span-2"
          actions={
            <div className="flex items-center gap-1">
              <button onClick={() => setCursor((c) => { const m = c.m - 1; return m < 0 ? { y: c.y - 1, m: 11 } : { y: c.y, m }; })} className="rounded-lg p-1.5 hover:bg-slate-100"><ChevronLeft className="h-4 w-4 text-slate-500" /></button>
              <button onClick={() => { const d = new Date(); setCursor({ y: d.getFullYear(), m: d.getMonth() }); }} className="rounded-lg px-2 py-1 text-xs font-medium text-slate-600 hover:bg-slate-100">Today</button>
              <button onClick={() => setCursor((c) => { const m = c.m + 1; return m > 11 ? { y: c.y + 1, m: 0 } : { y: c.y, m }; })} className="rounded-lg p-1.5 hover:bg-slate-100"><ChevronRight className="h-4 w-4 text-slate-500" /></button>
            </div>
          }
        >
          <div className="p-4">
            <div className="mb-2 grid grid-cols-7 gap-1">
              {DAYS_IN_WEEK.map((d) => <div key={d} className="text-center text-[10px] font-bold uppercase text-slate-400">{d}</div>)}
            </div>
            <div className="grid grid-cols-7 gap-1">
              {cells.map((day, idx) => {
                if (!day) return <div key={idx} />;
                const key = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
                const dayEvents = events[key] || [];
                const isToday = key === todayKey;
                return (
                  <div key={idx} className={`min-h-[64px] rounded-lg border p-1.5 ${isToday ? "border-rose-400 bg-rose-50" : "border-slate-100 bg-slate-50/50"}`}>
                    <p className={`text-xs font-semibold ${isToday ? "text-rose-600" : "text-slate-500"}`}>{day}</p>
                    <div className="mt-1 space-y-0.5">
                      {dayEvents.slice(0, 2).map((ev, i) => (
                        <div key={i} className={`truncate rounded px-1 py-0.5 text-[9px] font-medium ${ev._type === "noc" ? "bg-orange-100 text-orange-700" : ev._type === "capa" ? "bg-blue-100 text-blue-700" : "bg-violet-100 text-violet-700"}`}>
                          {ev._type === "noc" ? "NOC" : ev._type === "capa" ? "CAPA" : "Cert"}
                        </div>
                      ))}
                      {dayEvents.length > 2 && <p className="text-[9px] text-slate-400">+{dayEvents.length - 2}</p>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </SectionCard>

        {/* Upcoming alerts */}
        <SectionCard title="Upcoming Alerts (90 days)" actions={<Link to="/compliance" className="text-xs font-medium text-rose-600 hover:underline">View all</Link>}>
          {upcoming.length === 0 ? (
            <EmptyState icon={CheckCircle2} title="All clear!" description="No certificates or NOCs expiring in the next 90 days." />
          ) : (
            <div className="max-h-[420px] divide-y divide-slate-50 overflow-y-auto">
              {upcoming.map((item) => {
                const urgent = item._days <= 7;
                const warn = item._days <= 30;
                return (
                  <div key={item.id} className="flex items-start gap-3 px-5 py-3">
                    <div className={`flex h-9 w-9 shrink-0 flex-col items-center justify-center rounded-lg text-white ${urgent ? "bg-rose-500" : warn ? "bg-amber-500" : "bg-slate-400"}`}>
                      <span className="text-sm font-bold leading-none">{item._days}</span>
                      <span className="text-[7px] uppercase leading-none">days</span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-slate-800">
                        {item.title || item.noc_number || "Untitled"}
                      </p>
                      <p className="text-xs text-slate-500">
                        {item._type === "noc" ? "Fire NOC" : item._type === "capa" ? "CAPA" : "Certificate"}
                        {item.authority ? ` · ${item.authority}` : ""}
                      </p>
                      <p className="text-xs text-slate-400">{item._date}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </SectionCard>
      </div>
    </div>
  );
}