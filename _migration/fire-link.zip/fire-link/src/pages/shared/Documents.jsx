import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { useAuth } from "@/lib/AuthContext";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { FolderOpen, Upload, Download, FileText } from "lucide-react";
import { cn } from "@/lib/utils";

const TYPES = ["certificate", "manual", "datasheet", "drawing", "purchase_order", "invoice", "inspection_report", "maintenance_report", "fire_noc", "engineering_report", "other"];
const TYPE_LABEL = { purchase_order: "Purchase Order", fire_noc: "Fire NOC", inspection_report: "Inspection Report", maintenance_report: "Maintenance Report", engineering_report: "Engineering Report" };

export default function Documents() {
  const { data: docs, loading, reload } = useList("Document", {}, "-created_date", 200);
  const { user } = useAuth();
  const { toast } = useToast();
  const [type, setType] = useState("all");
  const [q, setQ] = useState("");
  const [uploading, setUploading] = useState(false);
  const [newDoc, setNewDoc] = useState(null);
  const [newType, setNewType] = useState("other");

  const filtered = useMemo(() =>
    docs.filter((d) => (type === "all" || d.type === type) && (!q || d.name.toLowerCase().includes(q.toLowerCase()))),
    [docs, type, q]);

  const onFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      setNewDoc({ name: file.name, file_url });
      toast({ title: "File uploaded", description: "Choose a document type and save." });
    } catch (err) {
      toast({ title: "Upload failed", description: err.message, variant: "destructive" });
    } finally { setUploading(false); e.target.value = ""; }
  };

  const save = async () => {
    if (!newDoc) return;
    try {
      await base44.entities.Document.create({
        name: newDoc.name,
        type: newType,
        file_url: newDoc.file_url,
        uploaded_by: user?.full_name || "Demo User",
        version: 1,
      });
      toast({ title: "Document saved to vault" });
      setNewDoc(null);
      reload();
    } catch (err) {
      toast({ title: "Save failed", description: err.message, variant: "destructive" });
    }
  };

  return (
    <div>
      <PageHeader
        title="Document Vault"
        icon={FolderOpen}
        subtitle="Certificates, manuals, invoices, drawings — all in one secure place."
        actions={
          <label className="cursor-pointer">
            <input type="file" className="hidden" onChange={onFile} disabled={uploading} />
            <span className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-rose-700">
              <Upload className="h-4 w-4" /> {uploading ? "Uploading…" : "Upload Document"}
            </span>
          </label>
        }
      />

      {newDoc && (
        <SectionCard className="mb-4">
          <div className="flex flex-col gap-3 p-5 sm:flex-row sm:items-center">
            <FileText className="h-5 w-5 shrink-0 text-rose-600" />
            <p className="min-w-0 flex-1 truncate text-sm font-semibold text-slate-800">{newDoc.name}</p>
            <select value={newType} onChange={(e) => setNewType(e.target.value)} className="rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-rose-300">
              {TYPES.map((t) => <option key={t} value={t}>{TYPE_LABEL[t] || t.charAt(0).toUpperCase() + t.slice(1)}</option>)}
            </select>
            <Button size="sm" onClick={save}>Save to Vault</Button>
            <Button size="sm" variant="ghost" onClick={() => setNewDoc(null)}>Discard</Button>
          </div>
        </SectionCard>
      )}

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search documents…" className="flex-1 rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-rose-300" />
        <select value={type} onChange={(e) => setType(e.target.value)} className="rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm capitalize outline-none focus:border-rose-300">
          <option value="all">All types</option>
          {TYPES.map((t) => <option key={t} value={t}>{TYPE_LABEL[t] || t.charAt(0).toUpperCase() + t.slice(1)}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-24 animate-pulse rounded-xl bg-slate-100" />)}</div>
      ) : filtered.length === 0 ? (
        <SectionCard><EmptyState icon={FolderOpen} title="No documents found" description="Upload certificates, datasheets, invoices and reports to your vault." /></SectionCard>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((d) => (
            <div key={d.id} className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition hover:shadow-md">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-50 text-rose-600"><FileText className="h-5 w-5" /></div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-slate-800">{d.name}</p>
                <p className="text-xs capitalize text-slate-500">{TYPE_LABEL[d.type] || d.type} · v{d.version || 1}</p>
              </div>
              {d.file_url && (
                <a href={d.file_url} target="_blank" rel="noreferrer" className="rounded-lg border border-slate-200 p-2 text-slate-500 hover:bg-slate-50" title="Download">
                  <Download className="h-4 w-4" />
                </a>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}