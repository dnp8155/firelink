import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { useRole } from "@/lib/RoleContext";
import { useAuth } from "@/lib/AuthContext";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { Wrench, Plus, Play, CheckCircle2, CalendarDays } from "lucide-react";

const SERVICE_TYPES = ["Annual Inspection", "Refilling", "Repair", "Sprinkler Repair", "Pump Servicing", "Installation", "Emergency Callout"];

export default function Maintenance() {
  const { data: requests, loading, reload } = useList("ServiceRequest", {}, "-created_date", 100);
  const { activeRole } = useRole();
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ service_type: SERVICE_TYPES[0], priority: "medium", asset_name: "", description: "", scheduled_date: "" });

  const canBook = ["customer", "org_admin", "super_admin"].includes(activeRole);
  const isField = ["vendor", "vendor_admin", "technician"].includes(activeRole);

  const submit = async () => {
    if (!form.service_type || !form.asset_name) { toast({ title: "Fill service type and asset", variant: "destructive" }); return; }
    setSaving(true);
    try {
      await base44.entities.ServiceRequest.create({
        request_number: "SRV-" + Date.now().toString().slice(-6),
        customer_id: user?.id,
        customer_name: user?.full_name || user?.email || "Customer",
        organization_id: user?.data?.organization_id || user?.organization_id || null,
        asset_name: form.asset_name,
        service_type: form.service_type,
        priority: form.priority,
        description: form.description,
        scheduled_date: form.scheduled_date || null,
        status: "open",
      });
      toast({ title: "Service request booked", description: "Our team will contact you shortly." });
      setOpen(false);
      setForm({ service_type: SERVICE_TYPES[0], priority: "medium", asset_name: "", description: "", scheduled_date: "" });
      reload();
    } catch (e) {
      toast({ title: "Failed to book", description: e.message, variant: "destructive" });
    } finally { setSaving(false); }
  };

  const setStatus = async (r, status) => {
    try {
      await base44.entities.ServiceRequest.update(r.id, { status, completion_notes: status === "completed" ? "Work completed by service team." : undefined });
      toast({ title: `Marked ${status.replace("_", " ")}`, description: r.request_number });
      reload();
    } catch (e) {
      toast({ title: "Update failed", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div>
      <PageHeader
        title={isField ? "Service Jobs" : "Maintenance & Service"}
        icon={Wrench}
        subtitle={isField ? "Jobs assigned to you and incoming service requests." : "Book, track and review maintenance for your assets."}
        actions={canBook ? <Button onClick={() => setOpen(true)}><Plus className="h-4 w-4" /> Book Service</Button> : null}
      />

      {loading ? (
        <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-slate-100" />)}</div>
      ) : requests.length === 0 ? (
        <SectionCard><EmptyState icon={Wrench} title="No service requests" description={canBook ? "Book a service for any asset — refills, repairs or inspections." : "New jobs will appear here."} /></SectionCard>
      ) : (
        <SectionCard>
          <div className="divide-y divide-slate-50">
            {requests.map((r) => (
              <div key={r.id} className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-50 text-amber-600"><Wrench className="h-5 w-5" /></div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-mono text-xs text-slate-400">{r.request_number}</p>
                    <StatusBadge status={r.priority} tone={r.priority === "critical" ? "red" : r.priority === "high" ? "amber" : "slate"} />
                  </div>
                  <p className="mt-0.5 text-sm font-semibold text-slate-800">{r.service_type} — {r.asset_name || "Asset"}</p>
                  <p className="text-xs text-slate-500">{r.customer_name} · {r.site_name || "Site"}{r.scheduled_date && <> · <CalendarDays className="inline h-3 w-3" /> {r.scheduled_date}</>}</p>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={r.status} tone={statusTone(r.status)} />
                  {isField && ["open", "assigned"].includes(r.status) && <Button size="sm" variant="outline" onClick={() => setStatus(r, "in_progress")}><Play className="h-3.5 w-3.5" /> Start</Button>}
                  {isField && r.status === "in_progress" && <Button size="sm" onClick={() => setStatus(r, "completed")}><CheckCircle2 className="h-3.5 w-3.5" /> Complete</Button>}
                </div>
              </div>
            ))}
          </div>
        </SectionCard>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Book a Service</DialogTitle></DialogHeader>
          <div className="space-y-4 py-1">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Service Type</Label>
                <select value={form.service_type} onChange={(e) => setForm({ ...form, service_type: e.target.value })} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-rose-300">
                  {SERVICE_TYPES.map((t) => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label>Priority</Label>
                <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-rose-300">
                  <option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="critical">Critical</option>
                </select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Asset</Label>
              <Input value={form.asset_name} onChange={(e) => setForm({ ...form, asset_name: e.target.value })} placeholder="e.g. CO₂ Extinguisher #FE-001" />
            </div>
            <div className="space-y-1.5">
              <Label>Preferred Date</Label>
              <Input type="date" value={form.scheduled_date} onChange={(e) => setForm({ ...form, scheduled_date: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Issue Details</Label>
              <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Describe the problem or service needed…" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={submit} disabled={saving}>{saving ? "Booking…" : "Book Service"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}