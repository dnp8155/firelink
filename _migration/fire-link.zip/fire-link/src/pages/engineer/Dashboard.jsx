import React from "react";
import { Link } from "react-router-dom";
import { KpiCard, PageHeader, SectionCard } from "@/components/ui-bits";
import { FolderKanban, ClipboardCheck, Calculator, ClipboardList, FileBarChart, Flame, Droplets, Sparkles, Plus, ArrowRight } from "lucide-react";

const QUICK = [
  { label: "New Project", path: "/engineering/projects", icon: Plus, tone: "rose" },
  { label: "Fire Load", path: "/engineering/fire-load", icon: Flame, tone: "amber" },
  { label: "Hydraulic Calc", path: "/engineering/hydraulic", icon: Droplets, tone: "blue" },
  { label: "Generate BOQ", path: "/engineering/boq", icon: ClipboardList, tone: "violet" },
  { label: "Ask Engineering AI", path: "/engineering/ai", icon: Sparkles, tone: "slate" },
];

export default function EngineerDashboard() {
  return (
    <div>
      <PageHeader title="Engineering Dashboard" subtitle="Calculations, BOQs and technical reports." />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <KpiCard label="Active Projects" value={4} icon={FolderKanban} tone="violet" />
        <KpiCard label="Pending Reviews" value={2} icon={ClipboardCheck} tone="amber" />
        <KpiCard label="Calculations" value={18} icon={Calculator} tone="blue" />
        <KpiCard label="BOQs" value={7} icon={ClipboardList} tone="rose" />
        <KpiCard label="Reports" value={11} icon={FileBarChart} tone="green" />
      </div>

      <div className="mt-6">
        <SectionCard title="Quick Actions">
          <div className="grid grid-cols-2 gap-2 p-4 sm:grid-cols-3 lg:grid-cols-5">
            {QUICK.map((q) => (
              <Link key={q.label} to={q.path} className="flex flex-col items-center gap-2 rounded-xl border border-slate-100 bg-slate-50/60 p-4 text-center transition hover:border-violet-200 hover:bg-violet-50/50">
                <q.icon className="h-5 w-5 text-violet-600" />
                <span className="text-xs font-medium text-slate-700">{q.label}</span>
              </Link>
            ))}
          </div>
        </SectionCard>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <SectionCard title="Active Projects">
          <div className="divide-y divide-slate-50">
            {[
              { n: "PRJ-001", t: "Phoenix Mall — Sprinkler Design", s: "In Progress" },
              { n: "PRJ-002", t: "Acme Plant — Fire Load Study", s: "Review" },
              { n: "PRJ-003", t: "Skyline Towers — Hydrant Network", s: "In Progress" },
            ].map((p) => (
              <div key={p.n} className="flex items-center gap-3 px-5 py-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-violet-50 text-violet-600"><FolderKanban className="h-4 w-4" /></div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-slate-800">{p.t}</p>
                  <p className="text-xs text-slate-500">{p.n}</p>
                </div>
                <span className="text-xs font-medium text-slate-500">{p.s}</span>
                <ArrowRight className="h-4 w-4 text-slate-300" />
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Recent Calculations">
          <div className="divide-y divide-slate-50">
            {[
              { t: "Fire Load — Production Block A", v: "245 MJ/m²" },
              { t: "Hydraulic — Zone B Sprinkler", v: "12.5 bar" },
              { t: "Tank Sizing — Phoenix Mall", v: "180 m³" },
            ].map((c, i) => (
              <div key={i} className="flex items-center gap-3 px-5 py-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-50 text-blue-600"><Calculator className="h-4 w-4" /></div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-slate-800">{c.t}</p>
                  <p className="text-xs text-slate-500">Result: {c.v}</p>
                </div>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>

      <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-700">
        ⚠️ Engineering calculations and AI recommendations require review by a qualified professional.
      </div>
    </div>
  );
}