import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState, KpiCard } from "@/components/ui-bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { FolderTree, Plus, Trash2, Pencil, Package, Wrench } from "lucide-react";
import { cn } from "@/lib/utils";

export default function CategoryManagement() {
  const { toast } = useToast();
  const cats = useList("Category", {}, "display_order", 200);
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ name: "", slug: "", type: "product", parent_id: "", icon: "", description: "", display_order: 0, is_active: true });
  const [typeFilter, setTypeFilter] = useState("all");

  const filtered = cats.data.filter((c) => typeFilter === "all" || c.type === typeFilter);
  const productCount = cats.data.filter((c) => c.type === "product").length;
  const serviceCount = cats.data.filter((c) => c.type === "service").length;

  const openCreate = () => { setEditId(null); setForm({ name: "", slug: "", type: "product", parent_id: "", icon: "", description: "", display_order: 0, is_active: true }); setOpen(true); };
  const openEdit = (c) => { setEditId(c.id); setForm({ name: c.name, slug: c.slug || "", type: c.type, parent_id: c.parent_id || "", icon: c.icon || "", description: c.description || "", display_order: c.display_order || 0, is_active: c.is_active }); setOpen(true); };

  const save = async () => {
    if (!form.name.trim()) { toast({ title: "Name is required", variant: "destructive" }); return; }
    const slug = form.slug.trim().toLowerCase().replace(/[^a-z0-9-]/g, "-") || form.name.trim().toLowerCase().replace(/[^a-z0-9-]/g, "-");
    setBusy(true);
    try {
      if (editId) { await base44.entities.Category.update(editId, { ...form, slug }); toast({ title: "Category updated" }); }
      else { await base44.entities.Category.create({ ...form, slug }); toast({ title: "Category created" }); }
      setOpen(false); cats.reload();
    } catch (e) { toast({ title: "Save failed", description: e.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };

  const toggle = async (c) => { try { await base44.entities.Category.update(c.id, { is_active: !c.is_active }); cats.reload(); } catch (e) { toast({ title: "Toggle failed", description: e.message, variant: "destructive" }); } };
  const remove = async (c) => { if (!window.confirm(`Delete category "${c.name}"?`)) return; try { await base44.entities.Category.delete(c.id); cats.reload(); } catch (e) { toast({ title: "Delete failed", description: e.message, variant: "destructive" }); } };

  return (
    <div>
      <PageHeader title="Category Management" subtitle="Organize product & service categories for the marketplace." icon={FolderTree}
        actions={<Button onClick={openCreate} className="bg-rose-600 hover:bg-rose-700"><Plus className="h-4 w-4" /> New Category</Button>} />

      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-3">
        <KpiCard label="Total Categories" value={cats.loading ? "…" : cats.data.length} icon={FolderTree} tone="rose" />
        <KpiCard label="Product Categories" value={cats.loading ? "…" : productCount} icon={Package} tone="amber" />
        <KpiCard label="Service Categories" value={cats.loading ? "…" : serviceCount} icon={Wrench} tone="violet" />
      </div>

      <div className="mb-4 flex gap-2">
        {[{ k: "all", l: "All" }, { k: "product", l: "Products" }, { k: "service", l: "Services" }].map((t) => (
          <button key={t.k} onClick={() => setTypeFilter(t.k)} className={cn("rounded-lg px-3 py-1.5 text-sm font-medium transition", typeFilter === t.k ? "bg-slate-900 text-white" : "bg-white text-slate-600 border border-slate-200 hover:bg-slate-50")}>{t.l}</button>
        ))}
      </div>

      {cats.loading ? (
        <div className="space-y-3">{[0, 1, 2].map((i) => <div key={i} className="h-16 animate-pulse rounded-2xl bg-slate-200/60" />)}</div>
      ) : filtered.length === 0 ? (
        <SectionCard><EmptyState icon={FolderTree} title="No categories yet" description="Create your first product or service category." action={<Button onClick={openCreate} className="bg-rose-600"><Plus className="h-4 w-4" /> New Category</Button>} /></SectionCard>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((c) => (
            <SectionCard key={c.id}>
              <div className="p-5">
                <div className="flex items-start gap-3">
                  <div className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-xl", c.type === "product" ? "bg-amber-50 text-amber-600" : "bg-violet-50 text-violet-600")}>
                    {c.type === "product" ? <Package className="h-5 w-5" /> : <Wrench className="h-5 w-5" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-slate-900">{c.name}</p>
                    {c.slug && <code className="text-[11px] text-slate-400">{c.slug}</code>}
                    {c.description && <p className="mt-1 text-xs text-slate-500 line-clamp-2">{c.description}</p>}
                  </div>
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <button onClick={() => toggle(c)} className={cn("relative h-5 w-9 rounded-full transition-colors", c.is_active ? "bg-emerald-500" : "bg-slate-300")}>
                    <span className={cn("absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all", c.is_active ? "left-[18px]" : "left-0.5")} />
                  </button>
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(c)} className="text-slate-400 hover:text-blue-600"><Pencil className="h-4 w-4" /></button>
                    <button onClick={() => remove(c)} className="text-slate-300 hover:text-rose-600"><Trash2 className="h-4 w-4" /></button>
                  </div>
                </div>
              </div>
            </SectionCard>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editId ? "Edit Category" : "Create Category"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Category Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Fire Extinguishers" /></div>
            <div><Label>Slug (optional)</Label><Input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} placeholder="auto-generated if left blank" className="font-mono text-sm" /></div>
            <div><Label>Type</Label><select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"><option value="product">Product</option><option value="service">Service</option></select></div>
            <div><Label>Icon name (Lucide)</Label><Input value={form.icon} onChange={(e) => setForm({ ...form, icon: e.target.value })} placeholder="e.g. Flame" /></div>
            <div><Label>Description</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} /></div>
            <div className="flex items-center gap-2"><Input type="number" value={form.display_order} onChange={(e) => setForm({ ...form, display_order: Number(e.target.value) })} className="w-28" /><Label className="text-slate-500">Display order</Label></div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save} disabled={busy} className="bg-rose-600 hover:bg-rose-700">{editId ? "Update" : "Create"}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}