import React, { useState } from "react";
import { useList, formatINR } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState, KpiCard } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Users, ShoppingBag, Building2, Package, Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function CustomerManagement() {
  const users = useList("User", {}, "-created_date", 500);
  const orders = useList("Order", {}, "-created_date", 500);
  const orgs = useList("Organization", {}, "-created_date", 200);
  const [q, setQ] = useState("");

  const orderCount = (uid) => orders.data.filter((o) => o.customer_id === uid).length;
  const orderTotal = (uid) => orders.data.filter((o) => o.customer_id === uid).reduce((s, o) => s + (o.total || 0), 0);

  const filtered = users.data.filter((u) =>
    !q || (u.full_name || "").toLowerCase().includes(q.toLowerCase()) || (u.email || "").toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div>
      <PageHeader title="Customer Management" subtitle="View and manage all registered customers." icon={Users} />
      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="Total Customers" value={users.loading ? "…" : users.data.length} icon={Users} tone="rose" />
        <KpiCard label="Organizations" value={orgs.loading ? "…" : orgs.data.length} icon={Building2} tone="blue" />
        <KpiCard label="Total Orders" value={orders.loading ? "…" : orders.data.length} icon={Package} tone="amber" />
        <KpiCard label="Total Revenue" value={orders.loading ? "…" : formatINR(orders.data.reduce((s, o) => s + (o.total || 0), 0))} icon={ShoppingBag} tone="green" />
      </div>

      <div className="mb-4">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name or email…" className="pl-9" />
        </div>
      </div>

      {users.loading ? (
        <div className="space-y-3">{[0, 1, 2].map((i) => <div key={i} className="h-16 animate-pulse rounded-2xl bg-slate-200/60" />)}</div>
      ) : filtered.length === 0 ? (
        <SectionCard><EmptyState icon={Users} title="No customers found" /></SectionCard>
      ) : (
        <SectionCard>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-500">
                <tr><th className="px-5 py-3">Customer</th><th className="px-5 py-3">Email</th><th className="px-5 py-3">Role</th><th className="px-5 py-3">Orders</th><th className="px-5 py-3">Total Spent</th><th className="px-5 py-3">Joined</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/50">
                    <td className="px-5 py-3"><div className="flex items-center gap-2"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-rose-50 text-xs font-semibold text-rose-600">{(u.full_name || u.email || "?").charAt(0).toUpperCase()}</div><span className="font-medium text-slate-800">{u.full_name || "—"}</span></div></td>
                    <td className="px-5 py-3 text-slate-600">{u.email || "—"}</td>
                    <td className="px-5 py-3"><StatusBadge status={u.role || "user"} tone={statusTone(u.role || "user")} /></td>
                    <td className="px-5 py-3 text-slate-700">{orderCount(u.id)}</td>
                    <td className="px-5 py-3 font-medium text-slate-800">{formatINR(orderTotal(u.id))}</td>
                    <td className="px-5 py-3 text-xs text-slate-500">{u.created_date ? new Date(u.created_date).toLocaleDateString() : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>
      )}
    </div>
  );
}