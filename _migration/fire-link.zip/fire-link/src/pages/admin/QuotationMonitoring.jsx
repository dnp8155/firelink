import React, { useState } from "react";
import { useList, formatINR } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState, KpiCard } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { ReceiptText, Search, TrendingUp, Calendar } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function QuotationMonitoring() {
  const quotes = useList("Quotation", {}, "-created_date", 500);
  const [q, setQ] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const filtered = quotes.data.filter((qt) =>
    (statusFilter === "all" || qt.status === statusFilter) &&
    (!q || (qt.rfq_number || "").toLowerCase().includes(q.toLowerCase()) || (qt.vendor_name || "").toLowerCase().includes(q.toLowerCase()))
  );

  const totalValue = quotes.data.reduce((s, q) => s + (q.total || 0), 0);
  const accepted = quotes.data.filter((q) => q.status === "accepted").length;

  return (
    <div>
      <PageHeader title="Quotation Monitoring" subtitle="Global view of all vendor quotations across RFQs." icon={ReceiptText} />
      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="Total Quotations" value={quotes.loading ? "…" : quotes.data.length} icon={ReceiptText} tone="rose" />
        <KpiCard label="Total Value" value={formatINR(totalValue)} icon={TrendingUp} tone="green" />
        <KpiCard label="Accepted" value={accepted} icon={ReceiptText} tone="blue" />
        <KpiCard label="Pending" value={quotes.data.filter((q) => q.status === "submitted").length} icon={Calendar} tone="amber" />
      </div>

      <div className="mb-4 flex flex-wrap gap-3">
        <div className="relative max-w-sm"><Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" /><Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by RFQ or vendor…" className="pl-9" /></div>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="rounded-lg border border-slate-200 px-3 py-2 text-sm"><option value="all">All Status</option>{["submitted", "revised", "accepted", "rejected", "expired"].map((s) => <option key={s}>{s}</option>)}</select>
      </div>

      {quotes.loading ? (
        <div className="space-y-3">{[0, 1, 2].map((i) => <div key={i} className="h-16 animate-pulse rounded-2xl bg-slate-200/60" />)}</div>
      ) : filtered.length === 0 ? (
        <SectionCard><EmptyState icon={ReceiptText} title="No quotations found" /></SectionCard>
      ) : (
        <SectionCard>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-500"><tr><th className="px-5 py-3">RFQ</th><th className="px-5 py-3">Vendor</th><th className="px-5 py-3">Version</th><th className="px-5 py-3">Subtotal</th><th className="px-5 py-3">Tax</th><th className="px-5 py-3">Total</th><th className="px-5 py-3">Status</th><th className="px-5 py-3">Date</th></tr></thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.map((qt) => (
                  <tr key={qt.id} className="hover:bg-slate-50/50">
                    <td className="px-5 py-3 font-medium text-slate-800">{qt.rfq_number || "—"}</td>
                    <td className="px-5 py-3 text-slate-600">{qt.vendor_name || "—"}</td>
                    <td className="px-5 py-3 text-slate-500">v{qt.version || 1}</td>
                    <td className="px-5 py-3 text-slate-700">{formatINR(qt.subtotal)}</td>
                    <td className="px-5 py-3 text-slate-500">{formatINR(qt.tax)}</td>
                    <td className="px-5 py-3 font-semibold text-slate-800">{formatINR(qt.total)}</td>
                    <td className="px-5 py-3"><StatusBadge status={qt.status} tone={statusTone(qt.status)} /></td>
                    <td className="px-5 py-3 text-xs text-slate-500">{qt.created_date ? new Date(qt.created_date).toLocaleDateString() : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>
      )}
    </div>
  );
}