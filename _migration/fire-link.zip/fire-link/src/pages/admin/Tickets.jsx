import React from "react";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { LifeBuoy, UserPlus, CheckCircle2, Clock } from "lucide-react";

export default function AdminTickets() {
  const { data: tickets, loading, reload } = useList("SupportTicket", {}, "-created_date", 200);
  const { toast } = useToast();

  const act = async (t, status) => {
    try {
      await base44.entities.SupportTicket.update(t.id, { status, assigned_to: status === "assigned" ? "Support Team" : t.assigned_to });
      await base44.entities.AuditLog.create({ user_name: "Admin User", user_id: "admin", action: `Ticket ${status}`, module: "SupportTicket", entity_id: t.ticket_number, before_value: t.status, after_value: status });
      toast({ title: `Ticket ${status}`, description: t.ticket_number });
      reload();
    } catch (e) {
      toast({ title: "Action failed", description: e.message, variant: "destructive" });
    }
  };

  const open = tickets.filter((t) => !["resolved", "closed"].includes(t.status));
  const closed = tickets.filter((t) => ["resolved", "closed"].includes(t.status));

  return (
    <div>
      <PageHeader title="Support Tickets" icon={LifeBuoy} subtitle={`${open.length} open ticket(s).`} />
      {loading ? (
        <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-20 animate-pulse rounded-xl bg-slate-100" />)}</div>
      ) : tickets.length === 0 ? (
        <SectionCard><EmptyState icon={LifeBuoy} title="No tickets" /></SectionCard>
      ) : (
        <div className="space-y-5">
          {open.length > 0 && (
            <SectionCard title={`Open (${open.length})`}>
              <div className="divide-y divide-slate-50">
                {open.map((t) => (
                  <div key={t.id} className="flex flex-col gap-2 px-5 py-4 sm:flex-row sm:items-center">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="font-mono text-xs text-slate-400">{t.ticket_number}</p>
                        <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-semibold uppercase text-slate-500">{t.category}</span>
                      </div>
                      <p className="mt-0.5 text-sm font-semibold text-slate-800">{t.subject}</p>
                      <p className="text-xs text-slate-500">{t.user_name} · {t.created_date?.slice(0, 10)} · <Clock className="inline h-3 w-3" /> {t.priority}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <StatusBadge status={t.status} tone={statusTone(t.status)} />
                      {t.status === "open" && <Button size="sm" variant="outline" onClick={() => act(t, "assigned")}><UserPlus className="h-3.5 w-3.5" /> Assign</Button>}
                      {["assigned", "in_progress", "waiting_for_customer"].includes(t.status) && <Button size="sm" onClick={() => act(t, "resolved")}><CheckCircle2 className="h-3.5 w-3.5" /> Resolve</Button>}
                    </div>
                  </div>
                ))}
              </div>
            </SectionCard>
          )}
          {closed.length > 0 && (
            <SectionCard title={`Closed (${closed.length})`}>
              <div className="divide-y divide-slate-50">
                {closed.map((t) => (
                  <div key={t.id} className="flex items-center gap-3 px-5 py-3">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-slate-700">{t.subject}</p>
                      <p className="font-mono text-xs text-slate-400">{t.ticket_number} · {t.user_name}</p>
                    </div>
                    <StatusBadge status={t.status} tone={statusTone(t.status)} />
                  </div>
                ))}
              </div>
            </SectionCard>
          )}
        </div>
      )}
    </div>
  );
}