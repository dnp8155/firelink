import React from "react";
import { useList } from "@/hooks/useList";
import { KpiCard, PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { Building2, Users, ShieldCheck, TrendingUp } from "lucide-react";

export default function Organizations() {
  const orgs = useList("Organization", {}, "-created_date", 200);
  const sites = useList("Site", {}, "-created_date", 200);
  const assets = useList("Asset", {}, "-created_date", 500);

  const orgSites = (id) => sites.data.filter((s) => s.organization_id === id).length;
  const orgAssets = (id) => assets.data.filter((a) => a.organization_id === id).length;

  return (
    <div>
      <PageHeader title="Organizations" icon={Building2} subtitle="All customer organizations on the platform." />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="Organizations" value={orgs.data.length} icon={Building2} tone="blue" />
        <KpiCard label="Sites" value={sites.data.length} icon={Building2} tone="violet" />
        <KpiCard label="Assets Managed" value={assets.data.length} icon={ShieldCheck} tone="rose" />
        <KpiCard label="Enterprise Plans" value={orgs.data.filter((o) => o.plan === "enterprise").length} icon={TrendingUp} tone="green" />
      </div>

      <div className="mt-6">
        <SectionCard title="All Organizations">
          {orgs.loading ? (
            <div className="space-y-3 p-5">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-slate-100" />)}</div>
          ) : orgs.data.length === 0 ? (
            <EmptyState icon={Building2} title="No organizations" />
          ) : (
            <div className="divide-y divide-slate-50">
              {orgs.data.map((o) => (
                <div key={o.id} className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-blue-600"><Building2 className="h-5 w-5" /></div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold text-slate-900">{o.name}</p>
                    <p className="text-xs text-slate-500">{o.industry} · {o.city} · {o.email}</p>
                    <p className="mt-0.5 text-[11px] text-slate-400">{orgSites(o.id)} sites · {orgAssets(o.id)} assets</p>
                  </div>
                  <div className="w-32">
                    <div className="flex items-center justify-between text-[11px] text-slate-500">
                      <span>Compliance</span><span className="font-bold text-slate-800">{o.compliance_score || 0}%</span>
                    </div>
                    <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-slate-100">
                      <div className={`h-full rounded-full ${o.compliance_score >= 80 ? "bg-emerald-500" : o.compliance_score >= 60 ? "bg-amber-500" : "bg-rose-500"}`} style={{ width: `${o.compliance_score || 0}%` }} />
                    </div>
                  </div>
                  <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide ${o.plan === "enterprise" ? "bg-violet-50 text-violet-600" : o.plan === "business" ? "bg-blue-50 text-blue-600" : "bg-slate-100 text-slate-500"}`}>{o.plan}</span>
                </div>
              ))}
            </div>
          )}
        </SectionCard>
      </div>
    </div>
  );
}