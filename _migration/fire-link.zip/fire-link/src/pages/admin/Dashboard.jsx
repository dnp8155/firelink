import React from "react";
import { useList, formatINR } from "@/hooks/useList";
import { KpiCard, PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { Users, Store, Building2, Package, IndianRupee, FileText, LifeBuoy, AlertTriangle, PackageCheck } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid, LineChart, Line, Legend } from "recharts";

const monthKey = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
const monthLabel = (d) => d.toLocaleString("en", { month: "short" });

export default function AdminDashboard() {
  const orgs = useList("Organization", {}, "-created_date", 200);
  const vendors = useList("Vendor", {}, "-created_date", 200);
  const products = useList("Product", {}, "-created_date", 300);
  const orders = useList("Order", {}, "-created_date", 300);
  const rfqs = useList("RFQ", {}, "-created_date", 200);
  const assets = useList("Asset", {}, "-created_date", 300);
  const tickets = useList("SupportTicket", {}, "-created_date", 200);

  // ---- All metrics derive from real database records ----
  const gmv = orders.data.reduce((s, o) => s + (o.total || 0), 0);
  const customers = new Set(orders.data.map((o) => o.customer_id).filter(Boolean)).size;
  const pendingVendors = vendors.data.filter((v) => ["submitted", "pending", "documents_required", "under_review"].includes(v.approval_status)).length;
  const pendingProducts = products.data.filter((p) => p.approval_status === "pending").length;
  const refunded = orders.data.filter((o) => o.payment_status === "refunded").length;
  const openDisputes = orders.data.filter((o) => ["returned"].includes(o.status)).length;

  // Revenue by month (last 6 months, from real orders)
  const revByMonth = {};
  orders.data.forEach((o) => {
    if (!o.created_date) return;
    revByMonth[monthKey(new Date(o.created_date))] = (revByMonth[monthKey(new Date(o.created_date))] || 0) + (o.total || 0);
  });
  const revData = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i);
    revData.push({ m: monthLabel(d), v: revByMonth[monthKey(d)] || 0 });
  }

  // Customer (cumulative orders) & vendor growth by month (last 6 months, real data)
  const byMonth = { c: {}, v: {} };
  orders.data.forEach((o) => {
    if (!o.created_date || !o.customer_id) return;
    const k = monthKey(new Date(o.created_date));
    byMonth.c[k] = (byMonth.c[k] || 0) + 1;
  });
  vendors.data.forEach((v) => {
    if (!v.created_date) return;
    const k = monthKey(new Date(v.created_date));
    byMonth.v[k] = (byMonth.v[k] || 0) + 1;
  });
  const growthData = [];
  let cumCustomers = 0, cumVendors = 0;
  for (let i = 5; i >= 0; i--) {
    const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i);
    const k = monthKey(d);
    cumCustomers += byMonth.c[k] || 0;
    cumVendors += byMonth.v[k] || 0;
    growthData.push({ m: monthLabel(d), c: cumCustomers, v: cumVendors });
  }

  return (
    <div>
      <PageHeader title="Admin Dashboard" subtitle="Platform-wide marketplace and operations." />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4 xl:grid-cols-6">
        <KpiCard label="Customers" value={customers} icon={Users} tone="rose" />
        <KpiCard label="Vendors" value={vendors.data.length} icon={Store} tone="green" />
        <KpiCard label="Organizations" value={orgs.data.length} icon={Building2} tone="blue" />
        <KpiCard label="Products" value={products.data.length} icon={Package} tone="violet" />
        <KpiCard label="Orders" value={orders.data.length} icon={Package} tone="amber" />
        <KpiCard label="GMV" value={formatINR(gmv)} icon={IndianRupee} tone="teal" />
      </div>
      <div className="mt-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="RFQs" value={rfqs.data.length} icon={FileText} tone="slate" />
        <KpiCard label="Assets Managed" value={assets.data.length} icon={Building2} tone="rose" />
        <KpiCard label="Support Tickets" value={tickets.data.length} icon={LifeBuoy} tone="amber" />
        <KpiCard label="Pending Approvals" value={pendingVendors + pendingProducts} icon={AlertTriangle} tone="rose" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-1">
          <SectionCard title="Admin Alerts">
            <div className="space-y-2 p-4">
              <AlertRow icon={Store} label="Vendor approvals pending" value={pendingVendors} tone="amber" />
              <AlertRow icon={PackageCheck} label="Product approvals pending" value={pendingProducts} tone="amber" />
              <AlertRow icon={AlertTriangle} label="Refunded orders" value={refunded} tone="rose" />
              <AlertRow icon={AlertTriangle} label="Open return disputes" value={openDisputes} tone="rose" />
              <AlertRow icon={LifeBuoy} label="Unassigned tickets" value={tickets.data.filter((t) => t.status === "open").length} tone="blue" />
            </div>
          </SectionCard>
        </div>
        <SectionCard title="Marketplace Revenue" className="lg:col-span-2">
          <div className="h-60 p-4">
            {orders.data.length === 0 ? (
              <EmptyState icon={IndianRupee} title="No revenue yet" description="Monthly GMV from real orders will chart here." />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={revData}>
                  <defs><linearGradient id="ar" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#e11d48" stopOpacity={0.3} /><stop offset="100%" stopColor="#e11d48" stopOpacity={0} /></linearGradient></defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="m" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 100000}L`} />
                  <Tooltip formatter={(v) => formatINR(v)} contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0" }} />
                  <Area type="monotone" dataKey="v" stroke="#e11d48" strokeWidth={2.5} fill="url(#ar)" />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </SectionCard>
      </div>

      <div className="mt-6">
        <SectionCard title="Customer & Vendor Growth">
          <div className="h-60 p-4">
            {vendors.data.length === 0 && orders.data.length === 0 ? (
              <EmptyState icon={Users} title="No growth data yet" description="Cumulative customers and vendors will chart here as the platform grows." />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={growthData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="m" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0" }} />
                  <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
                  <Line type="monotone" dataKey="c" name="Customers" stroke="#e11d48" strokeWidth={2.5} dot={false} />
                  <Line type="monotone" dataKey="v" name="Vendors" stroke="#10b981" strokeWidth={2.5} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}

function AlertRow({ icon: Icon, label, value, tone }) {
  const tones = { amber: "bg-amber-50 text-amber-700", rose: "bg-rose-50 text-rose-700", blue: "bg-blue-50 text-blue-700" };
  return (
    <div className="flex items-center gap-3 rounded-lg border border-slate-100 px-3 py-2.5">
      <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${tones[tone]}`}><Icon className="h-4 w-4" /></div>
      <span className="flex-1 text-sm text-slate-700">{label}</span>
      <span className="text-sm font-semibold text-slate-900">{value}</span>
    </div>
  );
}