import React from "react";
import { useList, formatINR } from "@/hooks/useList";
import { KpiCard, PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { AlertTriangle, Undo2, IndianRupee, PackageX } from "lucide-react";

export default function AdminDisputes() {
  const orders = useList("Order", {}, "-created_date", 500);

  // Disputes = returns awaiting resolution, refunds and cancellations
  const disputes = orders.data.filter((o) =>
    ["returned", "refunded", "cancelled"].includes(o.status) || o.payment_status === "refunded" || o.return_reason
  );
  const awaiting = orders.data.filter((o) => o.status === "returned");
  const refunded = orders.data.filter((o) => o.payment_status === "refunded");
  const refundValue = refunded.reduce((s, o) => s + (o.total || 0), 0);

  return (
    <div>
      <PageHeader title="Disputes & Refunds" icon={AlertTriangle} subtitle="Return requests, refunds and cancellations across the platform." />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="Total Disputes" value={disputes.length} icon={AlertTriangle} tone="rose" />
        <KpiCard label="Awaiting Resolution" value={awaiting.length} icon={Undo2} tone="amber" />
        <KpiCard label="Refunded" value={refunded.length} icon={IndianRupee} tone="green" />
        <KpiCard label="Refund Value" value={formatINR(refundValue)} icon={IndianRupee} tone="slate" />
      </div>

      <div className="mt-5">
        {orders.loading ? (
          <div className="space-y-2">{[0, 1, 2].map((i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-slate-100" />)}</div>
        ) : disputes.length === 0 ? (
          <SectionCard><EmptyState icon={AlertTriangle} title="No disputes" description="Return requests, refunds and cancellations will appear here." /></SectionCard>
        ) : (
          <div className="space-y-3">
            {disputes.map((o) => (
              <SectionCard key={o.id}>
                <div className="flex flex-col gap-3 p-5 sm:flex-row sm:items-center">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-bold text-slate-900">{o.order_number}</p>
                      <StatusBadge status={o.status} tone={statusTone(o.status)} />
                      <StatusBadge status={o.payment_status} tone={statusTone(o.payment_status)} />
                    </div>
                    <p className="mt-1 text-xs text-slate-500">
                      {o.customer_name || "Customer"} → {o.vendor_name || "Vendor"} · {formatINR(o.total)} · {o.created_date ? new Date(o.created_date).toLocaleDateString() : "—"}
                    </p>
                    {o.return_reason && <p className="mt-1.5 rounded-lg bg-amber-50 px-2.5 py-1.5 text-xs text-amber-700 ring-1 ring-amber-100">Reason: {o.return_reason}</p>}
                    {o.notes && <p className="mt-1 text-xs text-slate-500">Notes: {o.notes}</p>}
                  </div>
                  <div className="flex items-center gap-2 text-right">
                    {o.status === "returned" && <span className="flex items-center gap-1 text-xs font-medium text-amber-600"><PackageX className="h-3.5 w-3.5" /> Vendor review in progress</span>}
                    {o.status === "refunded" && <span className="text-xs font-medium text-emerald-600">Refund processed</span>}
                    <p className="text-sm font-bold text-slate-900">{formatINR(o.total)}</p>
                  </div>
                </div>
              </SectionCard>
            ))}
          </div>
        )}
      </div>
      <p className="mt-3 text-xs text-slate-400">
        Refund processing lives in Platform Orders — use “Mark Refunded” there once a return dispute is resolved.
      </p>
    </div>
  );
}