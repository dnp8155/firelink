import React, { useMemo } from "react";
import { useList, formatINR } from "@/hooks/useList";
import { KpiCard, PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid, PieChart, Pie, Cell, Legend } from "recharts";
import { BarChart3, ShoppingBag, Store, Building2, Package, FileText, Boxes } from "lucide-react";

const COLORS = ["#e11d48", "#f59e0b", "#10b981", "#3b82f6", "#8b5cf6", "#64748b"];

export default function PlatformAnalytics() {
  const orders = useList("Order", {}, "-created_date", 500);
  const products = useList("Product", {}, "-created_date", 500);
  const vendors = useList("Vendor", {}, "-created_date", 500);
  const orgs = useList("Organization", {}, "-created_date", 500);
  const rfqs = useList("RFQ", {}, "-created_date", 500);
  const assets = useList("Asset", {}, "-created_date", 500);

  const gmv = orders.data.reduce((s, o) => s + (o.total || 0), 0);

  const statusData = useMemo(() => {
    const m = {};
    orders.data.forEach((o) => { m[o.status] = (m[o.status] || 0) + 1; });
    return Object.entries(m).map(([name, value]) => ({ name, value }));
  }, [orders.data]);

  const catData = useMemo(() => {
    const m = {};
    products.data.forEach((p) => { m[p.category] = (m[p.category] || 0) + 1; });
    return Object.entries(m).map(([name, value]) => ({ name, value }));
  }, [products.data]);

  const rfqData = useMemo(() => {
    const m = {};
    rfqs.data.forEach((r) => { m[r.status] = (m[r.status] || 0) + 1; });
    return Object.entries(m).map(([name, value]) => ({ name, value }));
  }, [rfqs.data]);

  if (orders.loading) return <div className="h-96 animate-pulse rounded-2xl bg-slate-100" />;

  return (
    <div>
      <PageHeader title="Platform Analytics" icon={BarChart3} subtitle="Marketplace performance, growth and RFQ conversion." />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4 xl:grid-cols-7">
        <KpiCard label="GMV" value={formatINR(gmv)} icon={BarChart3} tone="rose" />
        <KpiCard label="Orders" value={orders.data.length} icon={Package} tone="blue" />
        <KpiCard label="RFQs" value={rfqs.data.length} icon={FileText} tone="violet" />
        <KpiCard label="Products" value={products.data.length} icon={ShoppingBag} tone="green" />
        <KpiCard label="Vendors" value={vendors.data.length} icon={Store} tone="amber" />
        <KpiCard label="Organizations" value={orgs.data.length} icon={Building2} tone="teal" />
        <KpiCard label="Assets Managed" value={assets.data.length} icon={Boxes} tone="slate" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <SectionCard title="Orders by Status">
          <div className="h-64 p-4">
            {statusData.length === 0 ? <EmptyState title="No orders" /> : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={statusData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={3}>
                    {statusData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0" }} />
                  <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </SectionCard>

        <SectionCard title="Catalog by Category">
          <div className="h-64 p-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={catData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} interval={0} angle={-20} textAnchor="end" height={50} />
                <YAxis tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0" }} />
                <Bar dataKey="value" fill="#e11d48" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <SectionCard title="RFQ Pipeline">
          <div className="h-64 p-4">
            {rfqData.length === 0 ? <EmptyState title="No RFQs" /> : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={rfqData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={3}>
                    {rfqData.map((_, i) => <Cell key={i} fill={COLORS[(i + 2) % COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0" }} />
                  <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </SectionCard>

        <SectionCard title="Vendor Mix">
          <div className="h-64 p-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={vendors.data.map((v) => ({ name: v.company_name.split(" ")[0], value: v.revenue || 0 }))} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 100000}L`} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} width={80} />
                <Tooltip formatter={(v) => formatINR(v)} contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0" }} />
                <Bar dataKey="value" fill="#3b82f6" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>
      </div>
    </div>
  );
}