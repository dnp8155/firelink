import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useList, formatINR } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState, KpiCard } from "@/components/ui-bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { Percent, IndianRupee, Pencil, TrendingUp } from "lucide-react";
import { cn } from "@/lib/utils";

export default function CommissionManagement() {
  const { toast } = useToast();
  const settlements = useList("Settlement", {}, "-created_date", 200);
  const vendors = useList("Vendor", { approval_status: "approved" }, "company_name", 200);
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ vendor_id: "", vendor_name: "", commission_rate: 5 });

  const totalCommission = settlements.data.reduce((s, x) => s + (x.commission || 0), 0);
  const totalGross = settlements.data.reduce((s, x) => s + (x.gross || 0), 0);
  const pendingCount = settlements.data.filter((s) => s.status === "pending").length;

  const byVendor = {};
  settlements.data.forEach((s) => {
    const key = s.vendor_name || "Unknown";
    if (!byVendor[key]) byVendor[key] = { vendor_id: s.vendor_id, gross: 0, commission: 0, net: 0, count: 0 };
    byVendor[key].gross += s.gross || 0;
    byVendor[key].commission += s.commission || 0;
    byVendor[key].net += s.net_payable || 0;
    byVendor[key].count += 1;
  });
  const vendorRows = Object.entries(byVendor);

  const save = async () => {
    if (!form.vendor_id) { toast({ title: "Select a vendor", variant: "destructive" }); return; }
    setBusy(true);
    try {
      const existing = settlements.data.find((s) => s.vendor_id === form.vendor_id);
      if (existing) { await base44.entities.Settlement.update(existing.id, { commission_rate: form.commission_rate / 100, commission: (existing.gross || 0) * (form.commission_rate / 100), net_payable: (existing.gross || 0) * (1 - form.commission_rate / 100) }); }
      toast({ title: "Commission rate updated" });
      setOpen(false); settlements.reload();
    } catch (e) { toast({ title: "Save failed", description: e.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };

  return (
    <div>
      <PageHeader title="Commission Management" subtitle="Configure commission rates per vendor and track earnings." icon={Percent}
        actions={<Button onClick={() => { setEditId(null); setForm({ vendor_id: "", vendor_name: "", commission_rate: 5 }); setOpen(true); }} className="bg-rose-600 hover:bg-rose-700">Set Rate</Button>} />

      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="Total Gross Sales" value={formatINR(totalGross)} icon={IndianRupee} tone="green" />
        <KpiCard label="Total Commission" value={formatINR(totalCommission)} icon={Percent} tone="rose" />
        <KpiCard label="Pending Settlements" value={pendingCount} icon={TrendingUp} tone="amber" />
        <KpiCard label="Approved Vendors" value={vendors.data.length} icon={TrendingUp} tone="blue" />
      </div>

      {settlements.loading ? (
        <div className="space-y-3">{[0, 1, 2].map((i) => <div key={i} className="h-16 animate-pulse rounded-2xl bg-slate-200/60" />)}</div>
      ) : vendorRows.length === 0 ? (
        <SectionCard><EmptyState icon={Percent} title="No commission data yet" description="Settlements will appear here once orders are processed." /></SectionCard>
      ) : (
        <SectionCard title="Commission by Vendor">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-500"><tr><th className="px-5 py-3">Vendor</th><th className="px-5 py-3">Orders</th><th className="px-5 py-3">Gross Sales</th><th className="px-5 py-3">Commission</th><th className="px-5 py-3">Net Payable</th><th className="px-5 py-3"></th></tr></thead>
              <tbody className="divide-y divide-slate-50">
                {vendorRows.map(([name, s]) => (
                  <tr key={name} className="hover:bg-slate-50/50">
                    <td className="px-5 py-3 font-medium text-slate-800">{name}</td>
                    <td className="px-5 py-3 text-slate-600">{s.count}</td>
                    <td className="px-5 py-3 text-slate-700">{formatINR(s.gross)}</td>
                    <td className="px-5 py-3 font-semibold text-rose-600">{formatINR(s.commission)}</td>
                    <td className="px-5 py-3 font-medium text-emerald-600">{formatINR(s.net)}</td>
                    <td className="px-5 py-3"><button onClick={() => { setForm({ vendor_id: s.vendor_id, vendor_name: name, commission_rate: 5 }); setOpen(true); }} className="text-slate-400 hover:text-blue-600"><Pencil className="h-4 w-4" /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Set Commission Rate</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Vendor</Label><select value={form.vendor_id} onChange={(e) => { const v = vendors.data.find((x) => x.id === e.target.value); setForm({ ...form, vendor_id: e.target.value, vendor_name: v?.company_name || "" }); }} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"><option value="">Select vendor…</option>{vendors.data.map((v) => <option key={v.id} value={v.id}>{v.company_name}</option>)}</select></div>
            <div><Label>Commission Rate (%)</Label><Input type="number" step="0.5" value={form.commission_rate} onChange={(e) => setForm({ ...form, commission_rate: Number(e.target.value) })} /></div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save} disabled={busy} className="bg-rose-600 hover:bg-rose-700">Save Rate</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}