import React from "react";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState, KpiCard } from "@/components/ui-bits";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Briefcase, CheckCircle2, XCircle, Clock, Users } from "lucide-react";

export default function JobApproval() {
  const { toast } = useToast();
  const jobs = useList("JobVacancy", {}, "-created_date", 200);
  const [selected, setSelected] = React.useState(null);

  const pending = jobs.data.filter((j) => j.status === "pending").length;
  const approved = jobs.data.filter((j) => j.status === "approved").length;

  const setStatus = async (j, status) => {
    try { await base44.entities.JobVacancy.update(j.id, { status }); toast({ title: `Job ${status}` }); jobs.reload(); setSelected(null); }
    catch (e) { toast({ title: "Action failed", description: e.message, variant: "destructive" }); }
  };

  return (
    <div>
      <PageHeader title="Job Approval" subtitle="Review and approve vendor-posted job vacancies." icon={Briefcase} />
      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-3">
        <KpiCard label="Total Jobs" value={jobs.loading ? "…" : jobs.data.length} icon={Briefcase} tone="rose" />
        <KpiCard label="Pending Review" value={pending} icon={Clock} tone="amber" />
        <KpiCard label="Approved" value={approved} icon={CheckCircle2} tone="green" />
      </div>

      {jobs.loading ? (
        <div className="space-y-3">{[0, 1, 2].map((i) => <div key={i} className="h-20 animate-pulse rounded-2xl bg-slate-200/60" />)}</div>
      ) : jobs.data.length === 0 ? (
        <SectionCard><EmptyState icon={Briefcase} title="No job vacancies yet" description="Vendor-posted jobs will appear here for approval." /></SectionCard>
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {jobs.data.map((j) => (
            <SectionCard key={j.id}>
              <div className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-slate-900">{j.title}</p>
                    <p className="text-xs text-slate-500">{j.vendor_name || "—"} · {j.role}</p>
                    <div className="mt-2 flex flex-wrap gap-2 text-xs text-slate-500">
                      <span className="rounded-full bg-slate-100 px-2 py-0.5">{j.job_type?.replace("_", " ")}</span>
                      <span className="rounded-full bg-slate-100 px-2 py-0.5">{j.location || "Remote"}</span>
                      {j.experience_years > 0 && <span className="rounded-full bg-slate-100 px-2 py-0.5">{j.experience_years} yrs exp</span>}
                      <span className="rounded-full bg-slate-100 px-2 py-0.5">{j.openings} openings</span>
                    </div>
                  </div>
                  <StatusBadge status={j.status} tone={statusTone(j.status)} />
                </div>
                {j.status === "pending" && (
                  <div className="mt-3 flex justify-end gap-2">
                    <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => setStatus(j, "approved")}><CheckCircle2 className="h-3.5 w-3.5" /> Approve</Button>
                    <Button size="sm" variant="outline" onClick={() => setStatus(j, "rejected")}><XCircle className="h-3.5 w-3.5" /> Reject</Button>
                  </div>
                )}
              </div>
            </SectionCard>
          ))}
        </div>
      )}
    </div>
  );
}