import React, { useState } from "react";
import { PERMISSIONS, ROLES } from "@/lib/roles";
import { PageHeader, SectionCard } from "@/components/ui-bits";
import { KeyRound, Check, Minus, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";

export default function RolesMatrix() {
  const roles = Object.keys(PERMISSIONS);
  const [active, setActive] = useState(roles[0]);
  const matrix = PERMISSIONS[active];
  const modules = Object.keys(matrix);
  const allActions = [...new Set(modules.flatMap((m) => matrix[m]))];

  return (
    <div>
      <PageHeader title="Roles & Permissions" icon={KeyRound} subtitle="RBAC matrix — what each role can do across platform modules." />
      <div className="mb-4 flex items-start gap-2.5 rounded-2xl border border-slate-200 bg-slate-50 p-4">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-slate-500" />
        <p className="text-xs text-slate-600">
          Permission changes are locked to Super Admin. This matrix drives route protection and action visibility for every role — new roles can be added via the platform configuration.
        </p>
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        {roles.map((r) => (
          <button key={r} onClick={() => setActive(r)} className={cn("rounded-full px-3.5 py-1.5 text-xs font-semibold transition", active === r ? "bg-slate-900 text-white" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50")}>
            {ROLES[r]?.label || r}
          </button>
        ))}
      </div>

      <SectionCard title={`${ROLES[active]?.label || active} — Permission Matrix`}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-400">
                <th className="px-5 py-3 font-medium">Module</th>
                <th className="px-3 py-3 font-medium">Allowed Actions</th>
                <th className="px-3 py-3 text-right font-medium">Count</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {modules.map((m) => (
                <tr key={m}>
                  <td className="px-5 py-3 font-medium capitalize text-slate-800">{m.replace(/_/g, " ")}</td>
                  <td className="px-3 py-3">
                    <div className="flex flex-wrap gap-1.5">
                      {allActions.map((a) => {
                        const has = matrix[m].includes(a);
                        return (
                          <span key={a} className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium", has ? "bg-emerald-50 text-emerald-700" : "bg-slate-50 text-slate-300")}>
                            {has ? <Check className="h-3 w-3" /> : <Minus className="h-3 w-3" />} {a.replace(/_/g, " ")}
                          </span>
                        );
                      })}
                    </div>
                  </td>
                  <td className="px-3 py-3 text-right font-bold text-slate-700">{matrix[m].length}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}