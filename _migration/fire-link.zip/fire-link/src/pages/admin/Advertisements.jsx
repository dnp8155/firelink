import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState, KpiCard } from "@/components/ui-bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Image as Img } from "@/components/ui/image";
import { Megaphone, Plus, Trash2, CheckCircle2, XCircle, MousePointerClick, Eye } from "lucide-react";

export default function AdvertisementManagement() {
  const { toast } = useToast();
  const ads = useList("Advertisement", {}, "-created_date", 200);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ title: "", vendor_name: "", image_url: "", target_url: "", placement: "banner", start_date: "", end_date: "", budget: 0 });

  const create = async () => {
    if (!form.title.trim() || !form.image_url.trim()) { toast({ title: "Title and image are required", variant: "destructive" }); return; }
    setBusy(true);
    try { await base44.entities.Advertisement.create({ ...form, status: "pending" }); toast({ title: "Advertisement created" }); setOpen(false); ads.reload(); }
    catch (e) { toast({ title: "Create failed", description: e.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };

  const setStatus = async (a, status) => { try { await base44.entities.Advertisement.update(a.id, { status }); toast({ title: `Advertisement ${status}` }); ads.reload(); } catch (e) { toast({ title: "Action failed", description: e.message, variant: "destructive" }); } };
  const remove = async (a) => { if (!window.confirm("Delete this advertisement?")) return; try { await base44.entities.Advertisement.delete(a.id); ads.reload(); } catch (e) { toast({ title: "Delete failed", description: e.message, variant: "destructive" }); } };

  const pending = ads.data.filter((a) => a.status === "pending").length;
  const active = ads.data.filter((a) => a.status === "active" || a.status === "approved").length;

  return (
    <div>
      <PageHeader title="Advertisement Management" subtitle="Review and manage marketplace banner ads." icon={Megaphone}
        actions={<Button onClick={() => setOpen(true)} className="bg-rose-600 hover:bg-rose-700"><Plus className="h-4 w-4" /> New Ad</Button>} />
      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="Total Ads" value={ads.loading ? "…" : ads.data.length} icon={Megaphone} tone="rose" />
        <KpiCard label="Pending Review" value={pending} icon={Eye} tone="amber" />
        <KpiCard label="Active" value={active} icon={CheckCircle2} tone="green" />
        <KpiCard label="Total Impressions" value={ads.data.reduce((s, a) => s + (a.impressions || 0), 0)} icon={MousePointerClick} tone="blue" />
      </div>

      {ads.loading ? (
        <div className="space-y-3">{[0, 1, 2].map((i) => <div key={i} className="h-24 animate-pulse rounded-2xl bg-slate-200/60" />)}</div>
      ) : ads.data.length === 0 ? (
        <SectionCard><EmptyState icon={Megaphone} title="No advertisements yet" action={<Button onClick={() => setOpen(true)} className="bg-rose-600"><Plus className="h-4 w-4" /> New Ad</Button>} /></SectionCard>
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {ads.data.map((a) => (
            <SectionCard key={a.id}>
              <div className="p-5">
                <div className="flex gap-4">
                  <div className="h-20 w-28 shrink-0 overflow-hidden rounded-lg bg-slate-100">{a.image_url && <Img src={a.image_url} className="h-full w-full" />}</div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-slate-900">{a.title}</p>
                    <p className="text-xs text-slate-500">{a.vendor_name || "Platform"} · {a.placement}</p>
                    <div className="mt-1 flex gap-3 text-xs text-slate-400"><span>{a.impressions || 0} views</span><span>{a.clicks || 0} clicks</span></div>
                  </div>
                  <StatusBadge status={a.status} tone={statusTone(a.status)} />
                </div>
                <div className="mt-3 flex items-center justify-end gap-2">
                  {a.status === "pending" && <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => setStatus(a, "active")}><CheckCircle2 className="h-3.5 w-3.5" /> Approve</Button>}
                  {a.status === "active" && <Button size="sm" variant="outline" onClick={() => setStatus(a, "inactive")}>Deactivate</Button>}
                  {a.status === "inactive" && <Button size="sm" variant="outline" onClick={() => setStatus(a, "active")}>Activate</Button>}
                  {a.status === "pending" && <Button size="sm" variant="outline" onClick={() => setStatus(a, "rejected")}><XCircle className="h-3.5 w-3.5" /> Reject</Button>}
                  <Button size="sm" variant="ghost" onClick={() => remove(a)}><Trash2 className="h-3.5 w-3.5 text-slate-400" /></Button>
                </div>
              </div>
            </SectionCard>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Create Advertisement</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
            <div><Label>Vendor Name (optional)</Label><Input value={form.vendor_name} onChange={(e) => setForm({ ...form, vendor_name: e.target.value })} /></div>
            <div><Label>Image URL</Label><Input value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} placeholder="https://…" /></div>
            <div><Label>Target URL</Label><Input value={form.target_url} onChange={(e) => setForm({ ...form, target_url: e.target.value })} placeholder="https://…" /></div>
            <div><Label>Placement</Label><select value={form.placement} onChange={(e) => setForm({ ...form, placement: e.target.value })} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm">{["home", "category", "product_detail", "sidebar", "banner"].map((p) => <option key={p}>{p}</option>)}</select></div>
            <div className="grid grid-cols-2 gap-3"><div><Label>Start Date</Label><Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} /></div><div><Label>End Date</Label><Input type="date" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} /></div></div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={create} disabled={busy} className="bg-rose-600 hover:bg-rose-700">Create</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}