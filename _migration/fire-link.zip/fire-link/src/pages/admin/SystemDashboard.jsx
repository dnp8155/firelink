import React from "react";
import { useList } from "@/hooks/useList";
import { KpiCard, PageHeader, SectionCard } from "@/components/ui-bits";
import { Crown, KeyRound, Building2, Store, Flag, Plug, Activity, ScrollText, Shield, Server, Cpu, HardDrive, Wifi, Users, Package, ShoppingBag, UserCheck } from "lucide-react";

export default function SystemDashboard() {
  const orgs = useList("Organization", {}, "-created_date", 500);
  const vendors = useList("Vendor", {}, "-created_date", 500);
  const flags = useList("FeatureFlag", {}, "-created_date", 500);
  const users = useList("User", {}, "-created_date", 500);
  const products = useList("Product", {}, "-created_date", 500);
  const orders = useList("Order", {}, "-created_date", 500);

  return (
    <div>
      <PageHeader title="System Dashboard" subtitle="Platform-wide configuration, security and governance." icon={Crown} />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="Total Roles" value={8} icon={KeyRound} tone="rose" />
        <KpiCard label="Organizations" value={orgs.loading ? "…" : orgs.data.length} icon={Building2} tone="blue" />
        <KpiCard label="Vendors (approved)" value={vendors.loading ? "…" : vendors.data.length} icon={Store} tone="green" />
        <KpiCard label="Feature Flags" value={flags.loading ? "…" : flags.data.length} icon={Flag} tone="violet" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <SectionCard title="System Health">
          <div className="space-y-3 p-5">
            <HealthRow icon={Server} label="API Gateway" value="Operational" tone="green" />
            <HealthRow icon={Cpu} label="Compute (avg)" value="42% load" tone="green" />
            <HealthRow icon={HardDrive} label="Database" value="Healthy" tone="green" />
            <HealthRow icon={Wifi} label="Realtime" value="Operational" tone="green" />
            <HealthRow icon={Plug} label="Integrations" value="2 degraded" tone="amber" />
          </div>
        </SectionCard>

        <SectionCard title="Governance Modules">
          <div className="grid grid-cols-2 gap-2 p-4">
            {[
              { l: "Roles & Permissions", p: "/admin/roles", i: KeyRound },
              { l: "Feature Flags", p: "/admin/feature-flags", i: Flag },
              { l: "Integrations", p: "/admin/integrations", i: Plug },
              { l: "Audit Logs", p: "/admin/audit", i: ScrollText },
              { l: "Security", p: "/admin/system-health", i: Shield },
              { l: "System Health", p: "/admin/system-health", i: Activity },
            ].map((m) => (
              <a key={m.l} href={m.p} className="flex items-center gap-2.5 rounded-xl border border-slate-100 bg-slate-50/60 p-3.5 text-sm font-medium text-slate-700 transition hover:border-rose-200 hover:bg-rose-50/50">
                <m.i className="h-4 w-4 text-rose-600" /> {m.l}
              </a>
            ))}
          </div>
        </SectionCard>
      </div>

      {/* Total Account Review */}
      <SectionCard title="Total Account Review" className="mt-4">
        <div className="grid grid-cols-2 gap-4 p-5 lg:grid-cols-4">
          <AccountStat label="Total Users" value={users.loading ? "…" : users.data.length} icon={Users} />
          <AccountStat label="Vendors" value={vendors.loading ? "…" : vendors.data.length} icon={Store} />
          <AccountStat label="Products" value={products.loading ? "…" : products.data.length} icon={Package} />
          <AccountStat label="Orders" value={orders.loading ? "…" : orders.data.length} icon={ShoppingBag} />
        </div>
        <div className="border-t border-slate-100 px-5 py-4">
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-500">Vendor Status Breakdown</h4>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {["approved", "submitted", "under_review", "rejected", "suspended", "draft", "documents_required"].map((s) => {
              const count = vendors.data.filter((v) => v.approval_status === s).length;
              return (
                <div key={s} className="rounded-lg bg-slate-50 p-3">
                  <p className="text-xs capitalize text-slate-500">{s.replace(/_/g, " ")}</p>
                  <p className="mt-1 text-lg font-bold text-slate-900">{count}</p>
                </div>
              );
            })}
          </div>
        </div>
        <div className="border-t border-slate-100 px-5 py-4">
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-500">Product Status Breakdown</h4>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {["approved", "pending", "draft", "rejected", "disabled"].map((s) => {
              const count = products.data.filter((p) => p.approval_status === s).length;
              return (
                <div key={s} className="rounded-lg bg-slate-50 p-3">
                  <p className="text-xs capitalize text-slate-500">{s.replace(/_/g, " ")}</p>
                  <p className="mt-1 text-lg font-bold text-slate-900">{count}</p>
                </div>
              );
            })}
          </div>
        </div>
      </SectionCard>

      <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-700">
        ⚠️ High-risk actions in this workspace require additional confirmation.
      </div>
    </div>
  );
}

function AccountStat({ label, value, icon: Icon }) {
  return (
    <div className="flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-4">
      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-rose-50 text-rose-600">
        <Icon className="h-5 w-5" />
      </div>
      <div>
        <p className="text-xs font-medium uppercase tracking-wider text-slate-500">{label}</p>
        <p className="text-xl font-bold text-slate-900">{value}</p>
      </div>
    </div>
  );
}

function HealthRow({ icon: Icon, label, value, tone }) {
  const tones = { green: "text-emerald-600 bg-emerald-50", amber: "text-amber-600 bg-amber-50", rose: "text-rose-600 bg-rose-50" };
  return (
    <div className="flex items-center gap-3">
      <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${tones[tone]}`}><Icon className="h-4 w-4" /></div>
      <span className="flex-1 text-sm text-slate-700">{label}</span>
      <span className="text-sm font-medium text-slate-900">{value}</span>
    </div>
  );
}