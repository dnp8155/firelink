import React from "react";
import { Link } from "react-router-dom";
import { useList, formatINR } from "@/hooks/useList";
import { KpiCard, PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Image } from "@/components/ui/image";
import { ShoppingBag, PackageCheck, PackageX, Archive, ArrowRight } from "lucide-react";

export default function AdminMarketplace() {
  const products = useList("Product", {}, "-created_date", 500);

  const count = (s) => products.data.filter((p) => p.approval_status === s).length;
  const byVendor = {};
  products.data.forEach((p) => {
    const key = p.vendor_name || "Unassigned";
    if (!byVendor[key]) byVendor[key] = { total: 0, live: 0, pending: 0, stock: 0 };
    byVendor[key].total += 1;
    if (p.approval_status === "approved") byVendor[key].live += 1;
    if (p.approval_status === "pending") byVendor[key].pending += 1;
    byVendor[key].stock += p.stock || 0;
  });
  const vendorRows = Object.entries(byVendor).sort((a, b) => b[1].total - a[1].total).slice(0, 8);

  return (
    <div>
      <PageHeader title="Marketplace Management" icon={ShoppingBag} subtitle="Catalog health across every vendor." actions={
        <Link to="/admin/product-approvals" className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-sm font-medium text-white hover:bg-slate-800">
          Review Approvals <ArrowRight className="h-4 w-4" />
        </Link>
      } />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="Total Listings" value={products.data.length} icon={ShoppingBag} tone="rose" />
        <KpiCard label="Live" value={count("approved")} icon={PackageCheck} tone="green" />
        <KpiCard label="Pending Approval" value={count("pending")} icon={PackageX} tone="amber" />
        <KpiCard label="Disabled / Draft" value={count("disabled") + count("draft")} icon={Archive} tone="slate" />
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <SectionCard title="Catalog by Vendor">
          {vendorRows.length === 0 ? <EmptyState icon={ShoppingBag} title="No listings yet" /> : (
            <div className="divide-y divide-slate-50">
              {vendorRows.map(([name, s]) => (
                <div key={name} className="flex items-center gap-3 px-5 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-slate-800">{name}</p>
                    <p className="text-xs text-slate-500">{s.live} live · {s.pending} pending · {s.stock} units in stock</p>
                  </div>
                  <span className="text-sm font-semibold text-slate-800">{s.total}</span>
                </div>
              ))}
            </div>
          )}
        </SectionCard>

        <SectionCard title="Latest Listings">
          {products.data.length === 0 ? <EmptyState icon={ShoppingBag} title="No listings yet" /> : (
            <div className="divide-y divide-slate-50">
              {products.data.slice(0, 8).map((p) => (
                <div key={p.id} className="flex items-center gap-3 px-5 py-3">
                  <div className="h-9 w-9 shrink-0 overflow-hidden rounded-lg bg-slate-100">
                    {p.image_url ? <Image src={p.image_url} className="h-full w-full" /> : <ShoppingBag className="m-2.5 h-4 w-4 text-slate-300" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-slate-800">{p.name}</p>
                    <p className="text-xs text-slate-500">{p.vendor_name || "—"} · {formatINR(p.price)}</p>
                  </div>
                  <StatusBadge status={p.approval_status} tone={statusTone(p.approval_status)} />
                </div>
              ))}
            </div>
          )}
        </SectionCard>
      </div>
    </div>
  );
}