import React from "react";
import { PageHeader, SectionCard } from "@/components/ui-bits";
import { Plug, Mail, Bot, HardDrive, Mic, Image as ImageIcon, Video, Webhook, CheckCircle2, XCircle, Globe } from "lucide-react";

const CORE_SERVICES = [
  { icon: Mail, name: "Transactional Email", desc: "Order, RFQ and vendor lifecycle notifications." },
  { icon: Bot, name: "AI Assistant (LLM)", desc: "Customer & engineering copilots." },
  { icon: HardDrive, name: "File Storage", desc: "Public & private document storage with signed URLs." },
  { icon: Mic, name: "Speech Generation", desc: "Text-to-speech for accessible content." },
  { icon: ImageIcon, name: "Image Generation", desc: "AI product and marketing imagery." },
  { icon: Video, name: "Video Generation", desc: "AI video for marketing assets." },
];

const FUNCTIONS = [
  { name: "ai_assistant", desc: "AI copilot for customer and engineering questions." },
  { name: "verify_qr", desc: "Public QR verification for assets and certificates." },
  { name: "vendor_notification", desc: "Vendor & product approval transactional emails." },
  { name: "order_notification", desc: "Order lifecycle and RFQ award notifications." },
  { name: "get_vendor_document_url", desc: "Signed URLs for private vendor documents." },
];

const CONNECTORS = ["Gmail", "Google Calendar", "Google Sheets", "Google Drive", "Slack", "Notion", "GitHub", "Salesforce", "HubSpot", "QuickBooks"];

export default function Integrations() {
  return (
    <div>
      <PageHeader
        title="Integrations"
        subtitle="Platform services, backend functions and available connectors."
        icon={Plug}
      />

      <div className="grid gap-4 lg:grid-cols-2">
        <SectionCard title="Core Platform Services">
          <div className="grid gap-2 p-4 sm:grid-cols-2">
            {CORE_SERVICES.map((s) => (
              <div key={s.name} className="flex items-start gap-2.5 rounded-xl border border-slate-100 bg-slate-50/60 p-3.5">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600">
                  <s.icon className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-slate-800">{s.name}</p>
                  <p className="text-[11px] text-slate-500">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Backend Functions" actions={<span className="text-[11px] font-medium text-slate-400">{FUNCTIONS.length} active</span>}>
          <div className="divide-y divide-slate-50">
            {FUNCTIONS.map((f) => (
              <div key={f.name} className="flex items-center gap-3 px-5 py-3.5">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-violet-50 text-violet-600">
                  <Webhook className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-mono text-sm font-medium text-slate-800">{f.name}</p>
                  <p className="text-xs text-slate-500">{f.desc}</p>
                </div>
                <span className="flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-semibold text-emerald-600">
                  <CheckCircle2 className="h-3 w-3" /> Active
                </span>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>

      <div className="mt-4">
        <SectionCard title="Available App Connectors" actions={<span className="text-[11px] font-medium text-slate-400">Not connected</span>}>
          <div className="grid grid-cols-2 gap-2 p-4 sm:grid-cols-5">
            {CONNECTORS.map((c) => (
              <div key={c} className="flex flex-col items-center gap-1.5 rounded-xl border border-slate-100 bg-slate-50/60 px-3 py-4 text-center">
                <XCircle className="h-4 w-4 text-slate-300" />
                <span className="text-xs font-medium text-slate-600">{c}</span>
              </div>
            ))}
          </div>
          <p className="border-t border-slate-50 px-5 py-3 text-xs text-slate-400">
            <Globe className="mr-1 inline h-3 w-3" />
            Connectors are linked from the workspace Integrations settings. Once authorized, their data flows through the backend functions above.
          </p>
        </SectionCard>
      </div>
    </div>
  );
}