import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useList, formatINR } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Image } from "@/components/ui/image";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { PackageCheck, CheckCircle2, XCircle, Star } from "lucide-react";
import { cn } from "@/lib/utils";

export default function ProductApprovals() {
  const { data: products, loading, reload } = useList("Product", {}, "-created_date", 200);
  const { toast } = useToast();
  const [confirm, setConfirm] = useState(null);

  const act = async () => {
    if (!confirm) return;
    const { product, action } = confirm;
    try {
      await base44.entities.Product.update(product.id, { approval_status: action });
      await base44.entities.AuditLog.create({
        user_name: "Admin User", user_id: "admin", action: `Product ${action}`,
        module: "Product", entity_id: product.name, before_value: product.approval_status, after_value: action,
      });
      const notifyTypes = { approved: "product_approved", rejected: "product_rejected", disabled: "product_disabled" };
      if (notifyTypes[action] && product.vendor_id) {
        base44.functions.invoke("vendor_notification", { type: notifyTypes[action], vendor_id: product.vendor_id, product_id: product.id, product_name: product.name })
          .then((res) => { if (res?.data?.email_sent) toast({ title: "Vendor notified by email" }); })
          .catch(() => {});
      }
      toast({ title: `Product ${action}`, description: product.name });
      setConfirm(null);
      reload();
    } catch (e) {
      toast({ title: "Action failed", description: e.message, variant: "destructive" });
    }
  };

  const pending = products.filter((p) => p.approval_status === "pending");
  const live = products.filter((p) => p.approval_status !== "pending");

  return (
    <div>
      <PageHeader title="Product Approvals" icon={PackageCheck} subtitle={`${pending.length} listing(s) awaiting approval.`} />

      {loading ? (
        <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-20 animate-pulse rounded-xl bg-slate-100" />)}</div>
      ) : pending.length > 0 ? (
        <SectionCard title={`Pending Review (${pending.length})`} className="mb-5">
          <div className="divide-y divide-slate-50">
            {pending.map((p) => (
              <div key={p.id} className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center">
                <div className="h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-slate-100">
                  {p.image_url ? <Image src={p.image_url} fittingType="fill" className="h-full w-full" /> : <div className="flex h-full w-full items-center justify-center text-slate-300"><PackageCheck className="h-5 w-5" /></div>}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-slate-900">{p.name}</p>
                  <p className="text-xs text-slate-500">{p.vendor_name} · {p.category} · {formatINR(p.price)}</p>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => setConfirm({ product: p, action: "approved" })}><CheckCircle2 className="h-3.5 w-3.5" /> Approve</Button>
                  <Button size="sm" variant="outline" onClick={() => setConfirm({ product: p, action: "rejected" })}><XCircle className="h-3.5 w-3.5" /> Reject</Button>
                </div>
              </div>
            ))}
          </div>
        </SectionCard>
      ) : null}

      <SectionCard title={`Live Listings (${live.length})`}>
        {live.length === 0 ? <EmptyState icon={PackageCheck} title="No approved products" /> : (
          <div className="divide-y divide-slate-50">
            {live.map((p) => (
              <div key={p.id} className="flex items-center gap-3 px-5 py-3.5">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-slate-800">{p.name}</p>
                  <p className="text-xs text-slate-500">{p.vendor_name} · {formatINR(p.price)} {p.featured && <Star className="ml-1 inline h-3 w-3 fill-amber-400 text-amber-400" />}</p>
                </div>
                <StatusBadge status={p.approval_status} tone={statusTone(p.approval_status)} />
                {p.approval_status === "approved" && <Button size="sm" variant="ghost" onClick={() => setConfirm({ product: p, action: "disabled" })}>Disable</Button>}
                {p.approval_status === "disabled" && <Button size="sm" variant="outline" onClick={() => setConfirm({ product: p, action: "approved" })}>Re-enable</Button>}
              </div>
            ))}
          </div>
        )}
      </SectionCard>

      <Dialog open={!!confirm} onOpenChange={(o) => !o && setConfirm(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Confirm Action</DialogTitle></DialogHeader>
          <p className="text-sm text-slate-600">
            Mark <span className="font-semibold text-slate-900">{confirm?.product?.name}</span> as <span className="font-semibold">{confirm?.action}</span>?
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirm(null)}>Cancel</Button>
            <Button onClick={act} variant={confirm?.action === "rejected" ? "destructive" : "default"}>Confirm</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}