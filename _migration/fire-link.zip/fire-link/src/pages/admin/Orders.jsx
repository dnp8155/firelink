import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useList, formatINR } from "@/hooks/useList";
import { KpiCard, PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Package, IndianRupee, Search, Undo2, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

export default function AdminOrders() {
  const orders = useList("Order", {}, "-created_date", 300);
  const { toast } = useToast();
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("all");

  const filtered = orders.data.filter((o) => {
    const matchQ = !q || `${o.order_number} ${o.customer_name || ""} ${o.vendor_name || ""}`.toLowerCase().includes(q.toLowerCase());
    const matchF = filter === "all" || (filter === "disputes" ? ["returned", "refunded"].includes(o.status) : o.status === filter);
    return matchQ && matchF;
  });

  const gmv = orders.data.reduce((s, o) => s + (o.total || 0), 0);
  const pending = orders.data.filter((o) => o.status === "pending").length;
  const disputes = orders.data.filter((o) => ["returned", "refunded"].includes(o.status)).length;

  const markRefunded = async (o) => {
    try {
      await base44.entities.Order.update(o.id, { status: "refunded", payment_status: "refunded" });
      await base44.entities.AuditLog.create({
        user_name: "Admin", user_id: "admin", action: "Order refunded",
        module: "Platform Orders", entity_id: o.order_number, before_value: o.status, after_value: "refunded",
      });
      toast({ title: "Order marked refunded", description: o.order_number });
      orders.reload();
    } catch (e) {
      toast({ title: "Action failed", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div>
      <PageHeader title="Platform Orders" icon={Package} subtitle="All marketplace orders across every customer and vendor." />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="Total Orders" value={orders.data.length} icon={Package} tone="rose" />
        <KpiCard label="GMV" value={formatINR(gmv)} icon={IndianRupee} tone="green" />
        <KpiCard label="Pending Acceptance" value={pending} icon={Clock} tone="amber" />
        <KpiCard label="Returns & Refunds" value={disputes} icon={Undo2} tone="slate" />
      </div>

      <div className="mt-5 mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search orders, customers, vendors…" className="w-full rounded-lg border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-sm outline-none focus:border-rose-300" />
        </div>
        <div className="flex flex-wrap gap-1.5">
          {["all", "pending", "accepted", "dispatched", "delivered", "returned", "refunded", "disputes"].map((s) => (
            <button key={s} onClick={() => setFilter(s)} className={cn("rounded-full px-3 py-1.5 text-xs font-medium capitalize", filter === s ? "bg-slate-900 text-white" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50")}>{s}</button>
          ))}
        </div>
      </div>

      {orders.loading ? (
        <div className="space-y-2">{[0, 1, 2, 3].map((i) => <div key={i} className="h-14 animate-pulse rounded-xl bg-slate-100" />)}</div>
      ) : filtered.length === 0 ? (
        <SectionCard><EmptyState icon={Package} title="No orders" description="Platform-wide orders will appear here." /></SectionCard>
      ) : (
        <SectionCard>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-400">
                <th className="px-5 py-3 font-medium">Order</th>
                <th className="px-5 py-3 font-medium">Customer</th>
                <th className="px-5 py-3 font-medium">Vendor</th>
                <th className="px-5 py-3 font-medium">Total</th>
                <th className="px-5 py-3 font-medium">Status</th>
                <th className="px-5 py-3 font-medium">Payment</th>
                <th className="px-5 py-3 font-medium text-right">Actions</th>
              </tr></thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.map((o) => (
                  <tr key={o.id} className="hover:bg-slate-50/50">
                    <td className="px-5 py-3">
                      <p className="font-medium text-slate-800">{o.order_number}</p>
                      <p className="text-xs text-slate-400">{o.created_date ? new Date(o.created_date).toLocaleDateString() : "—"}</p>
                    </td>
                    <td className="px-5 py-3 text-slate-600">{o.customer_name || "—"}</td>
                    <td className="px-5 py-3 text-slate-600">{o.vendor_name || "—"}</td>
                    <td className="px-5 py-3 font-semibold text-slate-800">{formatINR(o.total)}</td>
                    <td className="px-5 py-3"><StatusBadge status={o.status} tone={statusTone(o.status)} /></td>
                    <td className="px-5 py-3"><StatusBadge status={o.payment_status} tone={statusTone(o.payment_status)} /></td>
                    <td className="px-5 py-3 text-right">
                      {o.status === "returned" ? (
                        <Button size="sm" variant="outline" onClick={() => markRefunded(o)}>Mark Refunded</Button>
                      ) : (
                        <span className="text-xs text-slate-400">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>
      )}
    </div>
  );
}