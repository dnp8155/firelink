import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { Store, CheckCircle2, XCircle, PauseCircle, Star, FileText } from "lucide-react";

export default function VendorApprovals() {
  const { data: vendors, loading, reload } = useList("Vendor", {}, "-created_date", 200);
  const { toast } = useToast();
  const [confirm, setConfirm] = useState(null); // { vendor, action }

  const act = async () => {
    if (!confirm) return;
    const { vendor, action } = confirm;
    try {
      await base44.entities.Vendor.update(vendor.id, { approval_status: action });
      await base44.entities.AuditLog.create({
        user_name: "Admin User", user_id: "admin", action: `Vendor ${action}`,
        module: "Vendor", entity_id: vendor.company_name, before_value: vendor.approval_status, after_value: action,
      });
      const notifyTypes = { approved: "vendor_approved", rejected: "vendor_rejected", documents_required: "documents_required", suspended: "vendor_suspended" };
      if (notifyTypes[action]) {
        base44.functions.invoke("vendor_notification", { type: notifyTypes[action], vendor_id: vendor.id })
          .then((res) => { if (res?.data?.email_sent) toast({ title: "Vendor notified by email" }); })
          .catch(() => {});
      }
      toast({ title: `Vendor ${action}`, description: vendor.company_name });
      setConfirm(null);
      reload();
    } catch (e) {
      toast({ title: "Action failed", description: e.message, variant: "destructive" });
    }
  };

  const pending = vendors.filter((v) => ["submitted", "pending", "documents_required", "under_review"].includes(v.approval_status));

  return (
    <div>
      <PageHeader title="Vendor Approvals" icon={Store} subtitle={`${pending.length} vendor application(s) awaiting review.`} />
      {loading ? (
        <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-24 animate-pulse rounded-2xl bg-slate-100" />)}</div>
      ) : vendors.length === 0 ? (
        <SectionCard><EmptyState icon={Store} title="No vendors" /></SectionCard>
      ) : (
        <div className="space-y-3">
          {vendors.map((v) => (
            <SectionCard key={v.id}>
              <div className="flex flex-col gap-3 p-5 sm:flex-row sm:items-center">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600"><Store className="h-5 w-5" /></div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-sm font-bold text-slate-900">{v.company_name}</p>
                    <StatusBadge status={v.approval_status} tone={statusTone(v.approval_status)} />
                    {v.rating > 0 && <span className="flex items-center gap-1 text-xs text-slate-500"><Star className="h-3 w-3 fill-amber-400 text-amber-400" /> {v.rating}</span>}
                  </div>
                  <p className="text-xs text-slate-500">{v.contact_person} · {v.email} · {v.city}</p>
                  <p className="mt-0.5 text-[11px] text-slate-400">GST: {v.gst_number || "—"} · Categories: {(v.categories || []).join(", ") || "—"}</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {v.approval_status !== "approved" && <Button size="sm" onClick={() => setConfirm({ vendor: v, action: "approved" })}><CheckCircle2 className="h-3.5 w-3.5" /> Approve</Button>}
                  {v.approval_status !== "rejected" && <Button size="sm" variant="outline" onClick={() => setConfirm({ vendor: v, action: "rejected" })}><XCircle className="h-3.5 w-3.5" /> Reject</Button>}
                  {v.approval_status !== "approved" && <Button size="sm" variant="outline" onClick={() => setConfirm({ vendor: v, action: "documents_required" })}><FileText className="h-3.5 w-3.5" /> Request Docs</Button>}
                  {v.approval_status === "approved" && <Button size="sm" variant="ghost" onClick={() => setConfirm({ vendor: v, action: "suspended" })}><PauseCircle className="h-3.5 w-3.5" /> Suspend</Button>}
                </div>
              </div>
            </SectionCard>
          ))}
        </div>
      )}

      <Dialog open={!!confirm} onOpenChange={(o) => !o && setConfirm(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Confirm Action</DialogTitle></DialogHeader>
          <p className="text-sm text-slate-600">
            Are you sure you want to mark <span className="font-semibold text-slate-900">{confirm?.vendor?.company_name}</span> as <span className="font-semibold">{confirm?.action}</span>?
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirm(null)}>Cancel</Button>
            <Button onClick={act} variant={confirm?.action === "rejected" ? "destructive" : "default"}>Confirm</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}