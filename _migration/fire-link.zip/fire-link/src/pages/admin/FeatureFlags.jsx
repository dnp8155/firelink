import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState, KpiCard } from "@/components/ui-bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { Flag, Plus, Trash2, ToggleLeft } from "lucide-react";
import { cn } from "@/lib/utils";

export default function FeatureFlags() {
  const { toast } = useToast();
  const flags = useList("FeatureFlag", {}, "key", 200);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ key: "", name: "", description: "", category: "Marketplace" });

  const enabledCount = flags.data.filter((f) => f.enabled).length;

  const create = async () => {
    const key = form.key.trim().toLowerCase().replace(/[^a-z0-9_]/g, "_");
    if (!form.name.trim() || !key) {
      toast({ title: "Name and key are required.", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      await base44.entities.FeatureFlag.create({
        key,
        name: form.name.trim(),
        description: form.description.trim(),
        category: form.category,
        enabled: true,
      });
      toast({ title: "Flag created", description: `"${key}" is live and enabled.` });
      setOpen(false);
      setForm({ key: "", name: "", description: "", category: "Marketplace" });
      flags.reload();
    } catch (e) {
      toast({ title: "Failed to create flag", description: e.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const toggle = async (f) => {
    try {
      await base44.entities.FeatureFlag.update(f.id, { enabled: !f.enabled });
      flags.reload();
    } catch (e) {
      toast({ title: "Toggle failed", description: e.message, variant: "destructive" });
    }
  };

  const remove = async (f) => {
    if (!window.confirm(`Delete flag "${f.name}"? Features gated by it will use their default behavior.`)) return;
    try {
      await base44.entities.FeatureFlag.delete(f.id);
      flags.reload();
    } catch (e) {
      toast({ title: "Delete failed", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div>
      <PageHeader
        title="Feature Flags"
        subtitle="Enable, disable and manage platform features per release."
        icon={Flag}
        actions={
          <Button onClick={() => setOpen(true)} className="bg-rose-600 hover:bg-rose-700">
            <Plus className="h-4 w-4" /> New Flag
          </Button>
        }
      />

      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-3">
        <KpiCard label="Total Flags" value={flags.loading ? "…" : flags.data.length} icon={Flag} tone="violet" />
        <KpiCard label="Enabled" value={flags.loading ? "…" : enabledCount} icon={ToggleLeft} tone="green" />
        <KpiCard label="Disabled" value={flags.loading ? "…" : flags.data.length - enabledCount} icon={ToggleLeft} tone="slate" />
      </div>

      {flags.loading ? (
        <div className="space-y-3">{[0, 1, 2].map((i) => <div key={i} className="h-16 animate-pulse rounded-2xl bg-slate-200/60" />)}</div>
      ) : flags.data.length === 0 ? (
        <SectionCard>
          <EmptyState
            icon={Flag}
            title="No feature flags yet"
            description="Create your first flag to control feature rollout across the platform."
            action={<Button onClick={() => setOpen(true)} className="bg-rose-600"><Plus className="h-4 w-4" /> New Flag</Button>}
          />
        </SectionCard>
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {flags.data.map((f) => (
            <SectionCard key={f.id}>
              <div className="flex items-start gap-3 p-5">
                <div className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-xl", f.enabled ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-400")}>
                  <Flag className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-sm font-semibold text-slate-900">{f.name}</p>
                    <code className="rounded bg-slate-100 px-1.5 py-0.5 font-mono text-[11px] text-slate-600">{f.key}</code>
                    {f.category && <span className="rounded-full bg-violet-50 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-violet-600">{f.category}</span>}
                  </div>
                  {f.description && <p className="mt-1 text-xs text-slate-500">{f.description}</p>}
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <button
                    onClick={() => toggle(f)}
                    className={cn(
                      "relative h-6 w-11 rounded-full transition-colors",
                      f.enabled ? "bg-emerald-500" : "bg-slate-300"
                    )}
                    aria-label={f.enabled ? "Disable flag" : "Enable flag"}
                  >
                    <span className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all", f.enabled ? "left-[22px]" : "left-0.5")} />
                  </button>
                  <button onClick={() => remove(f)} className="text-slate-300 transition hover:text-rose-600" aria-label="Delete flag">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </SectionCard>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Create Feature Flag</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Display Name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Product Comparison" />
            </div>
            <div>
              <Label>Key</Label>
              <Input value={form.key} onChange={(e) => setForm({ ...form, key: e.target.value })} placeholder="e.g. marketplace_compare" className="font-mono text-sm" />
              <p className="mt-1 text-[11px] text-slate-400">Lowercase letters, numbers and underscores.</p>
            </div>
            <div>
              <Label>Category</Label>
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm">
                {["Marketplace", "Customer Portal", "Vendor Portal", "Compliance", "AI", "Platform"].map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <Label>Description</Label>
              <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} placeholder="What does this flag control?" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={create} disabled={busy} className="bg-rose-600 hover:bg-rose-700">Create Flag</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}