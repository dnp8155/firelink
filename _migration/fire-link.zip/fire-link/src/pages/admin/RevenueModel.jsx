import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose,
} from "@/components/ui/dialog";
import {
  TrendingUp, Percent, Tag, Crown, Star, Megaphone, ShieldPlus,
  ShieldCheck, FileText, CalendarClock, Target, Truck, Award, Loader2, Pencil,
} from "lucide-react";

const ICON_MAP = {
  product_commission: Percent,
  service_commission: Percent,
  quotation_fee: FileText,
  premium_vendor: Crown,
  job_posting: Tag,
  featured_vendor: Star,
  featured_product: Star,
  advertisement: Megaphone,
  amc_lead: ShieldPlus,
  certificate_verify: ShieldCheck,
  tender_listing: FileText,
  annual_subscription: CalendarClock,
  lead_generation: Target,
  logistics_commission: Truck,
  certificate_service: Award,
};

const CATEGORY_TONE = {
  commission: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  fee: "bg-blue-50 text-blue-700 ring-blue-200",
  subscription: "bg-violet-50 text-violet-700 ring-violet-200",
  advertising: "bg-amber-50 text-amber-700 ring-amber-200",
  lead: "bg-teal-50 text-teal-700 ring-teal-200",
  service: "bg-rose-50 text-rose-700 ring-rose-200",
};

const MODEL_LABEL = {
  percentage: "Percentage",
  flat: "Flat Fee",
  subscription: "Subscription",
  referral: "Referral",
};

const DEFAULTS = [
  { key: "product_commission", name: "Product Commission", category: "commission", model_type: "percentage", rate: 8, fee: 0, applies_to: "Marketplace product orders", description: "Commission charged on product sales through the marketplace.", display_order: 1 },
  { key: "service_commission", name: "Service Commission", category: "commission", model_type: "percentage", rate: 10, fee: 0, applies_to: "Service bookings", description: "Commission charged on service bookings completed via platform.", display_order: 2 },
  { key: "quotation_fee", name: "Quotation Fee", category: "fee", model_type: "flat", rate: 0, fee: 99, applies_to: "RFQ quotations submitted", description: "Flat fee per quotation submitted by vendors on RFQs.", display_order: 3 },
  { key: "premium_vendor", name: "Premium Vendor Membership", category: "subscription", model_type: "subscription", rate: 0, fee: 4999, applies_to: "Vendor monthly membership", description: "Premium membership subscription for vendors with enhanced visibility.", display_order: 4 },
  { key: "job_posting", name: "Job Posting Fee", category: "fee", model_type: "flat", rate: 0, fee: 499, applies_to: "Each job vacancy posted", description: "Flat fee for posting a job vacancy on the platform.", display_order: 5 },
  { key: "featured_vendor", name: "Featured Vendor", category: "advertising", model_type: "flat", rate: 0, fee: 1499, applies_to: "Vendor spotlight placement", description: "Fee to feature a vendor on the marketplace homepage and search.", display_order: 6 },
  { key: "featured_product", name: "Featured Product", category: "advertising", model_type: "flat", rate: 0, fee: 799, applies_to: "Product spotlight placement", description: "Fee to feature a product listing in the marketplace.", display_order: 7 },
  { key: "advertisement", name: "Advertisement Banner", category: "advertising", model_type: "flat", rate: 0, fee: 2999, applies_to: "Banner ad placements", description: "Fee for banner advertisement placements across the platform.", display_order: 8 },
  { key: "amc_lead", name: "AMC Lead Charges", category: "lead", model_type: "flat", rate: 0, fee: 149, applies_to: "Each AMC lead delivered", description: "Charge per AMC lead delivered to vendors.", display_order: 9 },
  { key: "certificate_verify", name: "Certificate Verification Fee", category: "fee", model_type: "flat", rate: 0, fee: 49, applies_to: "Each certificate verification", description: "Fee per certificate verification request.", display_order: 10 },
  { key: "tender_listing", name: "Tender Listing Fee", category: "fee", model_type: "flat", rate: 0, fee: 1999, applies_to: "Each tender published", description: "Fee for listing a tender on the platform.", display_order: 11 },
  { key: "annual_subscription", name: "Annual Subscription", category: "subscription", model_type: "subscription", rate: 0, fee: 24999, applies_to: "Organization annual plan", description: "Annual platform subscription for organizations.", display_order: 12 },
  { key: "lead_generation", name: "Lead Generation Charges", category: "lead", model_type: "flat", rate: 0, fee: 99, applies_to: "Qualified lead delivered", description: "Charge per qualified lead delivered to vendors.", display_order: 13 },
  { key: "logistics_commission", name: "Logistics Commission (Porter Referral)", category: "commission", model_type: "referral", rate: 5, fee: 0, applies_to: "Porter delivery bookings", description: "Commission earned on Porter logistics bookings via platform referral.", display_order: 14 },
  { key: "certificate_service", name: "Digital Certificate Service Charges", category: "service", model_type: "flat", rate: 0, fee: 199, applies_to: "Each digital certificate issued", description: "Service charge for generating digital certificates with QR verification.", display_order: 15 },
];

function ValueBadge({ stream }) {
  if (stream.model_type === "percentage" || stream.rate > 0) {
    return <span className="text-sm font-semibold text-slate-900">{stream.rate}%<span className="ml-1 text-xs font-normal text-slate-400">commission</span></span>;
  }
  return <span className="text-sm font-semibold text-slate-900">₹{stream.fee?.toLocaleString?.() ?? stream.fee}<span className="ml-1 text-xs font-normal text-slate-400">flat</span></span>;
}

export default function RevenueModel() {
  const { toast } = useToast();
  const [streams, setStreams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ name: "", category: "fee", model_type: "flat", rate: 0, fee: 0, applies_to: "", description: "", active: true });

  const load = async () => {
    setLoading(true);
    try {
      const list = await base44.entities.RevenueStream.list("display_order", 50);
      setStreams(list);
      // Backfill defaults if missing
      const existingKeys = list.map((s) => s.key);
      const missing = DEFAULTS.filter((d) => !existingKeys.includes(d.key));
      if (missing.length > 0) {
        const created = await base44.entities.RevenueStream.bulkCreate(missing);
        setStreams((prev) => [...prev, ...created].sort((a, b) => a.display_order - b.display_order));
      }
    } catch (e) {
      toast({ title: "Failed to load revenue streams", description: e.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const toggleActive = async (stream) => {
    try {
      await base44.entities.RevenueStream.update(stream.id, { active: !stream.active });
      setStreams((prev) => prev.map((s) => (s.id === stream.id ? { ...s, active: !s.active } : s)));
      toast({ title: `${stream.name} ${stream.active ? "disabled" : "enabled"}` });
    } catch (e) {
      toast({ title: "Update failed", description: e.message, variant: "destructive" });
    }
  };

  const openEdit = (stream) => {
    setEditing(stream);
    setForm({
      name: stream.name,
      category: stream.category,
      model_type: stream.model_type,
      rate: stream.rate || 0,
      fee: stream.fee || 0,
      applies_to: stream.applies_to || "",
      description: stream.description || "",
      active: stream.active,
    });
  };

  const save = async () => {
    if (!editing) return;
    setBusy(true);
    try {
      const updated = await base44.entities.RevenueStream.update(editing.id, { ...form, rate: Number(form.rate), fee: Number(form.fee) });
      setStreams((prev) => prev.map((s) => (s.id === editing.id ? updated : s)));
      setEditing(null);
      toast({ title: "Revenue stream updated" });
    } catch (e) {
      toast({ title: "Save failed", description: e.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const activeCount = streams.filter((s) => s.active).length;
  const totalPotential = streams.filter((s) => s.active && s.fee > 0).reduce((sum, s) => sum + s.fee, 0);

  return (
    <div>
      <PageHeader
        title="Revenue Model"
        subtitle="Configure commission rates, fees, subscriptions and advertising across the platform."
        icon={TrendingUp}
        actions={
          <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm shadow-sm">
            <span className="font-semibold text-emerald-600">{activeCount}</span>
            <span className="text-slate-400">active streams</span>
          </div>
        }
      />

      {loading ? (
        <div className="flex items-center justify-center py-20 text-slate-400">
          <Loader2 className="h-6 w-6 animate-spin" />
        </div>
      ) : streams.length === 0 ? (
        <SectionCard>
          <EmptyState icon={TrendingUp} title="No revenue streams" description="Revenue streams will auto-seed on first load." />
        </SectionCard>
      ) : (
        <>
          {/* Summary */}
          <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              { label: "Total Streams", value: streams.length, icon: TrendingUp, tone: "blue" },
              { label: "Active", value: activeCount, icon: TrendingUp, tone: "green" },
              { label: "Commission Streams", value: streams.filter((s) => s.category === "commission").length, icon: Percent, tone: "amber" },
              { label: "Flat Fees Total", value: `₹${totalPotential.toLocaleString()}`, icon: Tag, tone: "violet" },
            ].map((k) => (
              <div key={k.label} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-medium uppercase tracking-wider text-slate-500">{k.label}</p>
                  <k.icon className="h-4 w-4 text-slate-400" />
                </div>
                <p className="mt-2 text-lg font-semibold text-slate-900">{k.value}</p>
              </div>
            ))}
          </div>

          {/* Stream cards */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {streams.map((stream) => {
              const Icon = ICON_MAP[stream.key] || Tag;
              return (
                <div key={stream.id} className="flex flex-col rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md">
                  <div className="flex items-start justify-between">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-rose-600 text-white shadow-sm">
                      <Icon className="h-5 w-5" />
                    </div>
                    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ring-1 ring-inset ${CATEGORY_TONE[stream.category]}`}>
                      {stream.category}
                    </span>
                  </div>
                  <h3 className="mt-3 text-sm font-semibold text-slate-900">{stream.name}</h3>
                  <p className="mt-1 line-clamp-2 text-xs text-slate-500">{stream.description || stream.applies_to}</p>
                  <div className="mt-3 flex items-center justify-between">
                    <ValueBadge stream={stream} />
                    <span className="text-[10px] font-medium uppercase tracking-wide text-slate-400">{MODEL_LABEL[stream.model_type]}</span>
                  </div>
                  <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3">
                    <button
                      onClick={() => toggleActive(stream)}
                      className={`relative inline-flex h-5 w-9 items-center rounded-full transition ${stream.active ? "bg-emerald-500" : "bg-slate-200"}`}
                    >
                      <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition ${stream.active ? "translate-x-4" : "translate-x-0.5"}`} />
                    </button>
                    <Button variant="ghost" size="sm" onClick={() => openEdit(stream)}>
                      <Pencil className="h-3.5 w-3.5" /> Edit
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {/* Edit dialog */}
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Revenue Stream</DialogTitle>
          </DialogHeader>
          {editing && (
            <div className="space-y-4 py-2">
              <div>
                <Label>Name</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Category</Label>
                  <select
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm"
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                  >
                    {["commission", "fee", "subscription", "advertising", "lead", "service"].map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label>Model Type</Label>
                  <select
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm"
                    value={form.model_type}
                    onChange={(e) => setForm({ ...form, model_type: e.target.value })}
                  >
                    {["percentage", "flat", "subscription", "referral"].map((m) => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Rate (%)</Label>
                  <Input type="number" min="0" value={form.rate} onChange={(e) => setForm({ ...form, rate: e.target.value })} />
                </div>
                <div>
                  <Label>Fee (₹)</Label>
                  <Input type="number" min="0" value={form.fee} onChange={(e) => setForm({ ...form, fee: e.target.value })} />
                </div>
              </div>
              <div>
                <Label>Applies To</Label>
                <Input value={form.applies_to} onChange={(e) => setForm({ ...form, applies_to: e.target.value })} />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="active" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} />
                <Label htmlFor="active" className="cursor-pointer">Active</Label>
              </div>
            </div>
          )}
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
            <Button onClick={save} disabled={busy} className="bg-fire-gradient text-white">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}