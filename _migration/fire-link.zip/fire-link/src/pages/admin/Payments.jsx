import React from "react";
import { base44 } from "@/api/base44Client";
import { useList, formatINR } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState, KpiCard } from "@/components/ui-bits";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { CreditCard, IndianRupee, CheckCircle2, Clock, Wallet } from "lucide-react";

export default function PaymentControl() {
  const { toast } = useToast();
  const settlements = useList("Settlement", {}, "-created_date", 200);
  const wallets = useList("VendorWallet", {}, "-created_date", 100);

  const totalPayable = settlements.data.filter((s) => s.status !== "paid").reduce((s, x) => s + (x.net_payable || 0), 0);
  const totalPaid = settlements.data.filter((s) => s.status === "paid").reduce((s, x) => s + (x.net_payable || 0), 0);
  const pendingCount = settlements.data.filter((s) => s.status === "pending").length;

  const approve = async (s) => {
    try { await base44.entities.Settlement.update(s.id, { status: "approved" }); toast({ title: "Settlement approved" }); settlements.reload(); }
    catch (e) { toast({ title: "Action failed", description: e.message, variant: "destructive" }); }
  };
  const markPaid = async (s) => {
    try {
      await base44.entities.Settlement.update(s.id, { status: "paid" });
      const wallet = wallets.data.find((w) => w.vendor_id === s.vendor_id);
      if (wallet) { await base44.entities.VendorWallet.update(wallet.id, { balance: (wallet.balance || 0) + (s.net_payable || 0), transactions: [...(wallet.transactions || []), { type: "credit", amount: s.net_payable, description: `Settlement payout ${s.period || ""}`, date: new Date().toISOString() }] }); }
      toast({ title: "Marked as paid", description: `${formatINR(s.net_payable)} credited to vendor wallet.` });
      settlements.reload();
    } catch (e) { toast({ title: "Action failed", description: e.message, variant: "destructive" }); }
  };

  return (
    <div>
      <PageHeader title="Payment Control" subtitle="Approve and release vendor settlement payouts." icon={CreditCard} />
      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="Pending Payouts" value={formatINR(totalPayable)} icon={Clock} tone="amber" />
        <KpiCard label="Total Paid" value={formatINR(totalPaid)} icon={CheckCircle2} tone="green" />
        <KpiCard label="Pending Count" value={pendingCount} icon={CreditCard} tone="rose" />
        <KpiCard label="Vendor Wallets" value={wallets.data.length} icon={Wallet} tone="blue" />
      </div>

      {settlements.loading ? (
        <div className="space-y-3">{[0, 1, 2].map((i) => <div key={i} className="h-16 animate-pulse rounded-2xl bg-slate-200/60" />)}</div>
      ) : settlements.data.length === 0 ? (
        <SectionCard><EmptyState icon={CreditCard} title="No settlements yet" description="Vendor payouts will appear here once orders are delivered." /></SectionCard>
      ) : (
        <SectionCard title="Settlement Payouts">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-500"><tr><th className="px-5 py-3">Vendor</th><th className="px-5 py-3">Period</th><th className="px-5 py-3">Orders</th><th className="px-5 py-3">Gross</th><th className="px-5 py-3">Commission</th><th className="px-5 py-3">Net Payable</th><th className="px-5 py-3">Status</th><th className="px-5 py-3">Actions</th></tr></thead>
              <tbody className="divide-y divide-slate-50">
                {settlements.data.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/50">
                    <td className="px-5 py-3 font-medium text-slate-800">{s.vendor_name || "—"}</td>
                    <td className="px-5 py-3 text-slate-600">{s.period || "—"}</td>
                    <td className="px-5 py-3 text-slate-600">{s.order_count || 0}</td>
                    <td className="px-5 py-3 text-slate-700">{formatINR(s.gross)}</td>
                    <td className="px-5 py-3 text-rose-600">{formatINR(s.commission)}</td>
                    <td className="px-5 py-3 font-semibold text-emerald-600">{formatINR(s.net_payable)}</td>
                    <td className="px-5 py-3"><StatusBadge status={s.status} tone={statusTone(s.status)} /></td>
                    <td className="px-5 py-3">
                      <div className="flex gap-2">
                        {s.status === "pending" && <Button size="sm" variant="outline" onClick={() => approve(s)}>Approve</Button>}
                        {s.status === "approved" && <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => markPaid(s)}>Mark Paid</Button>}
                        {s.status === "paid" && <span className="text-xs text-slate-400">Completed</span>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>
      )}
    </div>
  );
}