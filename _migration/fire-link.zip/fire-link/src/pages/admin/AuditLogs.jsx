import React, { useMemo, useState } from "react";
import { useList } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { ScrollText, Search, Monitor, Globe } from "lucide-react";

export default function AuditLogs() {
  const { data: logs, loading } = useList("AuditLog", {}, "-created_date", 200);
  const [q, setQ] = useState("");

  const filtered = useMemo(() => logs.filter((l) =>
    !q || (l.user_name + l.action + l.module).toLowerCase().includes(q.toLowerCase())
  ), [logs, q]);

  return (
    <div>
      <PageHeader title="Audit Logs" icon={ScrollText} subtitle="Immutable trail of critical platform actions." />
      <div className="mb-4">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search user, action, module…" className="w-full rounded-lg border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-sm outline-none focus:border-rose-300" />
        </div>
      </div>
      {loading ? (
        <div className="space-y-3">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-14 animate-pulse rounded-xl bg-slate-100" />)}</div>
      ) : filtered.length === 0 ? (
        <SectionCard><EmptyState icon={ScrollText} title="No audit entries" description="Approvals, status changes and admin actions will be recorded here." /></SectionCard>
      ) : (
        <SectionCard title={`${filtered.length} entries`}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-400">
                  <th className="px-5 py-3 font-medium">User</th>
                  <th className="px-3 py-3 font-medium">Action</th>
                  <th className="px-3 py-3 font-medium">Module</th>
                  <th className="px-3 py-3 font-medium">Reference</th>
                  <th className="px-3 py-3 font-medium">Change</th>
                  <th className="px-3 py-3 font-medium">Device / IP</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.map((l) => (
                  <tr key={l.id}>
                    <td className="px-5 py-3 font-medium text-slate-800">{l.user_name}</td>
                    <td className="px-3 py-3 text-slate-600">{l.action}</td>
                    <td className="px-3 py-3"><span className="rounded-full bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-600">{l.module}</span></td>
                    <td className="px-3 py-3 font-mono text-xs text-slate-500">{l.entity_id || "—"}</td>
                    <td className="px-3 py-3 text-xs text-slate-500">
                      {l.before_value || l.after_value ? (
                        <span className="flex items-center gap-1.5">
                          {l.before_value && <span className="rounded bg-rose-50 px-1.5 py-0.5 text-rose-600 line-through">{l.before_value}</span>}
                          {l.after_value && <span className="rounded bg-emerald-50 px-1.5 py-0.5 text-emerald-700">{l.after_value}</span>}
                        </span>
                      ) : "—"}
                    </td>
                    <td className="px-3 py-3 text-xs text-slate-400">
                      <span className="flex items-center gap-1"><Monitor className="h-3 w-3" /> {l.device || "—"}</span>
                      <span className="flex items-center gap-1"><Globe className="h-3 w-3" /> {l.ip_address || "—"}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>
      )}
    </div>
  );
}