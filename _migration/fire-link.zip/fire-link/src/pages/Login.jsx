import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Flame, Mail, Lock, Loader2, Eye, EyeOff, ShieldCheck, Boxes, ShoppingBag, ArrowRight, Building2 } from "lucide-react";
import Logo from "@/components/Logo";
import GoogleIcon from "@/components/GoogleIcon";
import { safeReturnTo } from "@/lib/authReturnTo";

const FEATURES = [
  { icon: Boxes, text: "Manage Fire Safety Assets" },
  { icon: ShieldCheck, text: "Track Compliance & Certificates" },
  { icon: ShoppingBag, text: "Procure Products & Services" },
];

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPwd, setShowPwd] = useState(false);
  const returnTo = safeReturnTo();
  const loginLink = "/login" + (returnTo !== "/" ? "?returnTo=" + encodeURIComponent(returnTo) : "");
  const registerLink = "/register" + (returnTo !== "/" ? "?returnTo=" + encodeURIComponent(returnTo) : "");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      setError("Please enter a valid email address.");
      return;
    }
    if (!password) {
      setError("Please enter your password.");
      return;
    }
    setLoading(true);
    try {
      await base44.auth.loginViaEmailPassword(email, password);
      window.location.href = returnTo;
    } catch (err) {
      setError("Email or password is incorrect. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = () => base44.auth.loginWithProvider("google", returnTo);

  return (
    <div className="flex min-h-screen">
      {/* Left brand panel */}
      <div className="relative hidden w-1/2 flex-col justify-between overflow-hidden bg-slate-900 p-12 lg:flex">
        <Link to="/" className="relative flex items-center gap-2.5">
          <Logo className="h-10 w-10 shrink-0 rounded-none" />
          <span className="font-display text-xl font-extrabold tracking-tight text-white">FIRE<span className="text-amber-400">LINK</span></span>
        </Link>

        <div className="relative">
          <h1 className="font-display text-4xl font-extrabold leading-tight tracking-tight text-white">
            Your Fire & Safety<br />Operations, Connected.
          </h1>
          <p className="mt-4 max-w-md text-base text-slate-300">
            Manage procurement, assets, maintenance and compliance from one intelligent platform.
          </p>
          <div className="mt-10 space-y-4">
            {FEATURES.map((f) => {
              const Icon = f.icon;
              return (
                <div key={f.text} className="flex items-center gap-3">
                  <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10 text-amber-400 backdrop-blur">
                    <Icon className="h-4 w-4" />
                  </span>
                  <span className="text-sm font-medium text-slate-200">{f.text}</span>
                </div>
              );
            })}
          </div>
        </div>

        <p className="relative text-xs text-slate-500">Trusted by fire safety teams across India</p>
      </div>

      {/* Right form */}
      <div className="flex w-full items-center justify-center px-4 py-8 lg:w-1/2">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <Link to="/" className="mb-8 flex items-center justify-center gap-2.5 lg:hidden">
            <Logo className="h-10 w-10 shrink-0 rounded-none" />
            <span className="font-display text-xl font-extrabold tracking-tight text-slate-900">FIRE<span className="text-primary">LINK</span></span>
          </Link>

          <h2 className="font-display text-2xl font-bold text-slate-900">Welcome back</h2>
          <p className="mt-1 text-sm text-slate-500">Sign in to continue to Fire & Safety Connect.</p>

          {error && (
            <div className="mt-4 rounded-lg bg-rose-50 px-3.5 py-2.5 text-sm font-medium text-rose-700 ring-1 ring-rose-200">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email">Email / Mobile Number</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  autoFocus
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-12 pl-10"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <Link to="/forgot-password" className="text-xs font-medium text-primary hover:underline">Forgot password?</Link>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                <Input
                  id="password"
                  type={showPwd ? "text" : "password"}
                  autoComplete="current-password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-12 pl-10 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPwd(!showPwd)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 transition hover:text-slate-600"
                  aria-label="Toggle password"
                >
                  {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <label className="flex items-center gap-2 text-sm text-slate-600">
              <input type="checkbox" className="h-4 w-4 rounded border-slate-300 text-primary focus:ring-primary" />
              Remember me
            </label>

            <Button type="submit" className="h-12 w-full font-semibold" disabled={loading}>
              {loading ? (
                <><Loader2 className="h-4 w-4 animate-spin" /> Signing in…</>
              ) : (
                "Sign In"
              )}
            </Button>
          </form>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-200" /></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-white px-3 text-slate-400">or</span></div>
          </div>

          <Button variant="outline" className="h-12 w-full text-sm font-medium" onClick={handleGoogle}>
            <GoogleIcon className="mr-2 h-5 w-5" /> Continue with Google
          </Button>

          <p className="mt-6 text-center text-sm text-slate-500">
            Don't have an account?{" "}
            <Link to={registerLink} className="font-semibold text-primary hover:underline">Create an account</Link>
          </p>
          <p className="mt-2 text-center text-sm text-slate-500">
            Are you a vendor?{" "}
            <Link to="/vendor/register" className="font-semibold text-primary hover:underline">Become a Vendor</Link>
          </p>
        </div>
      </div>
    </div>
  );
}