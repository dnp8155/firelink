import React from "react";
import { useNavigate } from "react-router-dom";
import { useRole } from "@/lib/RoleContext";
import { ROLES, DEMO_ACCOUNTS } from "@/lib/roles";
import { getIcon } from "@/lib/icons";
import { ArrowRight, ShieldCheck } from "lucide-react";
import Logo from "@/components/Logo";
import { cn } from "@/lib/utils";

const TONES = {
  customer: "bg-rose-50 text-rose-600",
  org_admin: "bg-blue-50 text-blue-600",
  vendor: "bg-emerald-50 text-emerald-600",
  vendor_admin: "bg-emerald-50 text-emerald-600",
  technician: "bg-amber-50 text-amber-600",
  engineer: "bg-violet-50 text-violet-600",
  platform_admin: "bg-slate-100 text-slate-600",
  super_admin: "bg-rose-50 text-rose-600",
};

export default function RoleSelector() {
  const { activeRole, setActiveRole } = useRole();
  const navigate = useNavigate();

  const choose = (role) => {
    setActiveRole(role);
    navigate(ROLES[role].home);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="mx-auto max-w-3xl px-4 py-12 sm:py-16">
        <div className="mb-10 text-center">
          <Logo className="mx-auto mb-4 h-14 w-14 shrink-0 rounded-none" />
          <h1 className="font-display text-3xl font-extrabold tracking-tight text-slate-900">FIRE<span className="text-primary">LINK</span></h1>
          <p className="mt-1.5 text-sm text-slate-500">Choose how you'd like to continue — each role opens a purpose-built workspace.</p>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          {DEMO_ACCOUNTS.map((acc) => {
            const Icon = getIcon(acc.icon);
            const role = ROLES[acc.role];
            return (
              <button
                key={acc.role}
                onClick={() => choose(acc.role)}
                className={cn(
                  "group flex items-center gap-4 rounded-xl border bg-white p-4 text-left transition hover:border-slate-300",
                  activeRole === acc.role ? "border-primary ring-2 ring-primary/10" : "border-slate-200"
                )}
              >
                <div className={cn("flex h-12 w-12 shrink-0 items-center justify-center rounded-xl", TONES[acc.role])}>
                  <Icon className="h-6 w-6" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-slate-900">{role.label}</p>
                  <p className="truncate text-xs text-slate-500">{acc.name} · {acc.org}</p>
                </div>
                <ArrowRight className="h-4 w-4 text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-primary" />
              </button>
            );
          })}
        </div>

        <div className="mt-8 flex items-center justify-center gap-2 text-xs text-slate-400">
          <ShieldCheck className="h-3.5 w-3.5" />
          Demo environment — switch roles anytime from the top bar.
        </div>
      </div>
    </div>
  );
}