import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Flame, Mail, Lock, Loader2, ArrowRight, ArrowLeft, Check, Building2, ShieldCheck, Boxes, ShoppingBag, CheckCircle2 } from "lucide-react";
import Logo from "@/components/Logo";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { toast } from "@/components/ui/use-toast";
import { safeReturnTo } from "@/lib/authReturnTo";
import { cn } from "@/lib/utils";

const STEPS = ["Account", "Organization", "Location", "Requirements", "Verification", "Complete"];
const USE_CASES = [
  "Buy Fire Safety Products",
  "Request Fire Safety Services",
  "Manage Fire Safety Assets",
  "Manage Compliance",
  "Fire NOC",
  "Maintenance / AMC",
  "Fire Safety Procurement",
  "Engineering Projects",
];
const BENEFITS = [
  { icon: Boxes, text: "Track every fire safety asset with QR codes" },
  { icon: ShieldCheck, text: "Stay compliant with automated alerts" },
  { icon: ShoppingBag, text: "Procure products & services in one place" },
];

export default function Register() {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    full_name: "", email: "", phone: "", password: "",
    company_name: "", business_type: "", industry: "", gst_number: "", company_size: "",
    address: "", city: "", state: "", pincode: "",
    use_cases: [],
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [otpCode, setOtpCode] = useState("");
  const returnTo = safeReturnTo();

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const toggleUseCase = (uc) => setForm({ ...form, use_cases: form.use_cases.includes(uc) ? form.use_cases.filter((x) => x !== uc) : [...form.use_cases, uc] });

  const validate = () => {
    if (step === 0) {
      if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) return "Please enter a valid work email.";
      if (!form.password || form.password.length < 6) return "Password must be at least 6 characters.";
      if (!form.full_name) return "Please enter your full name.";
    }
    if (step === 1 && !form.company_name) return "Please enter your company name.";
    return null;
  };

  const next = async () => {
    const err = validate();
    if (err) { setError(err); return; }
    setError("");
    if (step < 3) { setStep(step + 1); return; }
    // Step 3 → 4: register
    setLoading(true);
    try {
      await base44.auth.register({ email: form.email, password: form.password });
      setStep(4);
    } catch (e) {
      setError(e.message || "Registration failed. This email may already be registered.");
    } finally {
      setLoading(false);
    }
  };

  const back = () => { setError(""); setStep(Math.max(0, step - 1)); };

  const verify = async () => {
    setError("");
    setLoading(true);
    try {
      const result = await base44.auth.verifyOtp({ email: form.email, otpCode });
      if (result?.access_token) {
        base44.auth.setToken(result.access_token);
        try { await base44.auth.updateMe(form); } catch {}
      }
      setStep(5);
    } catch (e) {
      setError(e.message || "Invalid verification code");
    } finally {
      setLoading(false);
    }
  };

  const resend = async () => {
    try { await base44.auth.resendOtp(form.email); toast({ title: "Code sent", description: "Check your email." }); } catch (e) { setError(e.message); }
  };

  // Success step
  if (step === 5) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4">
        <div className="w-full max-w-md text-center">
          <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-600">
            <CheckCircle2 className="h-8 w-8" />
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-900">Welcome to Fire & Safety Connect.</h1>
          <p className="mt-2 text-sm text-slate-500">Your account is ready. Let's get your fire safety operations organized.</p>
          <Button onClick={() => (window.location.href = returnTo)} className="mt-6 h-12 px-8 font-semibold">
            Go to Dashboard <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  }

  // OTP verification step
  if (step === 4) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4">
        <div className="w-full max-w-md">
          <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
            <div className="mb-6 text-center">
              <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-white">
                <Mail className="h-7 w-7" />
              </div>
              <h1 className="font-display text-xl font-bold text-slate-900">Verify your email</h1>
              <p className="mt-1 text-sm text-slate-500">Verify your email/mobile to secure your account. We sent a code to {form.email}.</p>
            </div>
            {error && <div className="mb-4 rounded-lg bg-rose-50 px-3.5 py-2.5 text-sm font-medium text-rose-700 ring-1 ring-rose-200">{error}</div>}
            <div className="mb-6 flex justify-center">
              <InputOTP maxLength={6} value={otpCode} onChange={setOtpCode} autoFocus autoComplete="one-time-code">
                <InputOTPGroup>
                  {[0, 1, 2, 3, 4, 5].map((i) => <InputOTPSlot key={i} index={i} />)}
                </InputOTPGroup>
              </InputOTP>
            </div>
            <Button onClick={verify} className="h-12 w-full font-semibold" disabled={loading || otpCode.length < 6}>
              {loading ? <><Loader2 className="h-4 w-4 animate-spin" /> Verifying…</> : "Verify"}
            </Button>
            <p className="mt-4 text-center text-sm text-slate-500">
              Didn't receive the code? <button onClick={resend} className="font-semibold text-primary hover:underline">Resend OTP</button>
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Steps 0–3: multi-step form
  return (
    <div className="flex min-h-screen bg-slate-50">
      {/* Left benefits panel */}
      <div className="relative hidden w-2/5 flex-col justify-between overflow-hidden bg-slate-900 p-12 lg:flex">
        <Link to="/" className="relative flex items-center gap-2.5">
          <Logo className="h-10 w-10 shrink-0 rounded-none" />
          <span className="font-display text-xl font-extrabold tracking-tight text-white">FIRE<span className="text-amber-400">LINK</span></span>
        </Link>

        <div className="relative">
          <h1 className="font-display text-3xl font-extrabold leading-tight text-white">Create your Fire & Safety Connect account.</h1>
          <p className="mt-3 max-w-sm text-sm text-slate-300">Manage products, services, assets, maintenance and compliance from one platform.</p>
          <div className="mt-8 space-y-4">
            {BENEFITS.map((b) => {
              const Icon = b.icon;
              return (
                <div key={b.text} className="flex items-center gap-3">
                  <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10 text-amber-400 backdrop-blur"><Icon className="h-4 w-4" /></span>
                  <span className="text-sm font-medium text-slate-200">{b.text}</span>
                </div>
              );
            })}
          </div>
        </div>
        <p className="relative text-xs text-slate-500">Takes less than 2 minutes</p>
      </div>

      {/* Right form */}
      <div className="flex w-full flex-col px-4 py-8 lg:w-3/5 lg:px-12">
        <div className="mx-auto w-full max-w-md">
          {/* Mobile logo */}
          <Link to="/" className="mb-6 flex items-center justify-center gap-2.5 lg:hidden">
            <Logo className="h-10 w-10 shrink-0 rounded-none" />
            <span className="font-display text-xl font-extrabold tracking-tight text-slate-900">FIRE<span className="text-primary">LINK</span></span>
          </Link>

          {/* Progress */}
          <div className="mb-8 flex items-center justify-between">
            {STEPS.slice(0, 5).map((label, i) => (
              <div key={label} className="flex items-center">
                <div className="flex flex-col items-center">
                  <div className={cn("flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold transition", i < step ? "bg-emerald-500 text-white" : i === step ? "bg-primary text-white" : "bg-slate-200 text-slate-400")}>
                    {i < step ? <Check className="h-4 w-4" /> : i + 1}
                  </div>
                  <span className={cn("mt-1 hidden text-[10px] font-medium sm:block", i <= step ? "text-slate-700" : "text-slate-400")}>{label}</span>
                </div>
                {i < 4 && <div className={cn("mx-1 h-0.5 w-6 sm:w-10", i < step ? "bg-emerald-500" : "bg-slate-200")} />}
              </div>
            ))}
          </div>

          {error && <div className="mb-4 rounded-lg bg-rose-50 px-3.5 py-2.5 text-sm font-medium text-rose-700 ring-1 ring-rose-200">{error}</div>}

          {/* Step 0: Account */}
          {step === 0 && (
            <div className="space-y-4">
              <div>
                <h2 className="font-display text-xl font-bold text-slate-900">Account Details</h2>
                <p className="text-sm text-slate-500">Let's start with your details.</p>
              </div>
              <div><Label>Full Name</Label><Input value={form.full_name} onChange={set("full_name")} placeholder="Ravi Patel" className="h-11" /></div>
              <div><Label>Work Email</Label><Input type="email" value={form.email} onChange={set("email")} placeholder="you@company.com" className="h-11" /></div>
              <div><Label>Mobile Number</Label><Input type="tel" value={form.phone} onChange={set("phone")} placeholder="+91 98765 43210" className="h-11" /></div>
              <div><Label>Password</Label><Input type="password" value={form.password} onChange={set("password")} placeholder="Min. 6 characters" className="h-11" /></div>
            </div>
          )}

          {/* Step 1: Organization */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <h2 className="font-display text-xl font-bold text-slate-900">Organization</h2>
                <p className="text-sm text-slate-500">Tell us about your company.</p>
              </div>
              <div><Label>Company Name</Label><Input value={form.company_name} onChange={set("company_name")} placeholder="e.g. Patel Enterprises" className="h-11" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Business Type</Label>
                  <select value={form.business_type} onChange={set("business_type")} className="h-11 w-full rounded-lg border border-slate-200 px-3 text-sm">
                    <option value="">Select…</option>
                    {["Private Ltd", "Public Ltd", "Partnership", "LLP", "Proprietorship", "Government", "Other"].map((t) => <option key={t}>{t}</option>)}
                  </select>
                </div>
                <div><Label>Industry</Label><Input value={form.industry} onChange={set("industry")} placeholder="e.g. Manufacturing" className="h-11" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>GST Number</Label><Input value={form.gst_number} onChange={set("gst_number")} placeholder="27AAAAA0000A1Z5" className="h-11" /></div>
                <div><Label>Company Size</Label>
                  <select value={form.company_size} onChange={set("company_size")} className="h-11 w-full rounded-lg border border-slate-200 px-3 text-sm">
                    <option value="">Select…</option>
                    {["1–10", "11–50", "51–200", "201–500", "500+"].map((s) => <option key={s}>{s}</option>)}
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Location */}
          {step === 2 && (
            <div className="space-y-4">
              <div>
                <h2 className="font-display text-xl font-bold text-slate-900">Company Location</h2>
                <p className="text-sm text-slate-500">Where is your company located?</p>
              </div>
              <div><Label>Address</Label><Input value={form.address} onChange={set("address")} placeholder="Street address" className="h-11" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>City</Label><Input value={form.city} onChange={set("city")} placeholder="e.g. Ahmedabad" className="h-11" /></div>
                <div><Label>State</Label><Input value={form.state} onChange={set("state")} placeholder="e.g. Gujarat" className="h-11" /></div>
              </div>
              <div><Label>Pincode</Label><Input value={form.pincode} onChange={set("pincode")} placeholder="380015" className="h-11" /></div>
            </div>
          )}

          {/* Step 3: Use Case */}
          {step === 3 && (
            <div className="space-y-4">
              <div>
                <h2 className="font-display text-xl font-bold text-slate-900">What are you looking to manage?</h2>
                <p className="text-sm text-slate-500">Select all that apply — you can change this later.</p>
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {USE_CASES.map((uc) => {
                  const selected = form.use_cases.includes(uc);
                  return (
                    <button
                      key={uc}
                      type="button"
                      onClick={() => toggleUseCase(uc)}
                      className={cn("flex items-center gap-2.5 rounded-xl border p-3 text-left text-sm font-medium transition", selected ? "border-primary bg-red-50 text-primary" : "border-slate-200 bg-white text-slate-600 hover:border-slate-300")}
                    >
                      <span className={cn("flex h-5 w-5 shrink-0 items-center justify-center rounded-md border", selected ? "border-primary bg-primary text-white" : "border-slate-300")}>
                        {selected && <Check className="h-3.5 w-3.5" />}
                      </span>
                      {uc}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="mt-8 flex items-center justify-between">
            {step > 0 ? (
              <button onClick={back} className="flex items-center gap-1.5 text-sm font-medium text-slate-500 hover:text-slate-900">
                <ArrowLeft className="h-4 w-4" /> Back
              </button>
            ) : <span />}

            {step < 3 ? (
              <Button onClick={next} className="h-11 px-6 font-semibold">
                Continue <ArrowRight className="h-4 w-4" />
              </Button>
            ) : (
              <Button onClick={next} disabled={loading} className="h-11 px-6 font-semibold">
                {loading ? <><Loader2 className="h-4 w-4 animate-spin" /> Creating…</> : <>Continue <ArrowRight className="h-4 w-4" /></>}
              </Button>
            )}
          </div>

          <p className="mt-6 text-center text-sm text-slate-500">
            Already have an account?{" "}
            <Link to={"/login" + (returnTo !== "/" ? "?returnTo=" + encodeURIComponent(returnTo) : "")} className="font-semibold text-primary hover:underline">Log in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}