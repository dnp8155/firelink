import React from "react";
import { getIcon } from "@/lib/icons";
import { PageHeader, SectionCard } from "@/components/ui-bits";
import { useRole } from "@/lib/RoleContext";
import { ROLE_NAV } from "@/lib/roles";
import { useLocation } from "react-router-dom";
import { Construction, Sparkles } from "lucide-react";

export default function Generic({ title, subtitle, icon, disclaimer }) {
  const { activeRole } = useRole();
  const location = useLocation();
  const nav = ROLE_NAV[activeRole] || [];
  const match = nav.find((n) => n.path === location.pathname);
  const Icon = icon ? getIcon(icon) : match ? getIcon(match.icon) : Construction;

  return (
    <div>
      <PageHeader title={title || match?.label || "Module"} subtitle={subtitle || "This workspace is part of your role-based experience."} icon={Icon} />
      <SectionCard>
        <div className="flex flex-col items-center justify-center px-6 py-20 text-center">
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-rose-500 to-red-600 text-white shadow-lg shadow-rose-200">
            <Icon className="h-8 w-8" />
          </div>
          <h3 className="text-lg font-semibold text-slate-900">{title || match?.label}</h3>
          <p className="mt-1.5 max-w-md text-sm text-slate-500">
            This module is wired into your role-based navigation and ready for the next build phase. Data, filters and actions here will respect your role and organization.
          </p>
          <div className="mt-5 flex items-center gap-2 rounded-full bg-slate-50 px-4 py-2 text-xs font-medium text-slate-500">
            <Sparkles className="h-3.5 w-3.5 text-rose-500" /> Active role: {activeRole.replace(/_/g, " ")}
          </div>
        </div>
      </SectionCard>
      {disclaimer && <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-700">{disclaimer}</div>}
    </div>
  );
}