import React from "react";
import { Link } from "react-router-dom";
import { useList, formatINR } from "@/hooks/useList";
import { useRole } from "@/lib/RoleContext";
import { useCart } from "@/lib/CartContext";
import { Image } from "@/components/ui/image";
import {
  Wrench, AlertCircle, ShoppingBag, ShoppingCart, Star,
  ArrowRight, Calendar, ShieldCheck, TrendingUp,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid,
} from "recharts";

const STATUS_DOT = {
  open: "bg-amber-400",
  assigned: "bg-orange-500",
  in_progress: "bg-blue-500",
  expiring_soon: "bg-orange-400",
  expired: "bg-red-500",
  valid: "bg-emerald-500",
};

export default function CustomerDashboard() {
  const { roleConfig } = useRole();
  const certs = useList("Certificate", {}, "-expiry_date", 50);
  const services = useList("ServiceRequest", {}, "-created_date", 50);
  const products = useList("Product", { approval_status: "approved" }, "-rating", 8);
  const { add } = useCart();

  const recommended = products.data.slice(0, 4);
  const upcoming = services.data
    .filter((s) => ["open", "assigned", "in_progress"].includes(s.status))
    .slice(0, 2);
  const complianceAlerts = certs.data
    .filter((c) => ["expiring_soon", "expired"].includes(c.status))
    .slice(0, 2);

  const spendData = [
    { m: "Apr", v: 42000 }, { m: "May", v: 38000 }, { m: "Jun", v: 55000 },
    { m: "Jul", v: 47000 }, { m: "Aug", v: 62000 }, { m: "Sep", v: 51000 },
  ];

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div>
        <h1 className="text-xl font-semibold tracking-tight text-slate-900">
          Welcome back, {roleConfig.label}
        </h1>
        <p className="mt-0.5 text-sm text-slate-500">
          Your tasks, compliance and spending at a glance.
        </p>
      </div>

      {/* Top row: Tasks + Compliance alerts */}
      <div className="grid gap-4 lg:grid-cols-2">
        {/* Upcoming service tasks */}
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-800">Upcoming Tasks</h2>
            <Link to="/customer/service-requests" className="text-xs font-medium text-rose-600 hover:underline">
              View all
            </Link>
          </div>
          <div className="space-y-3">
            {upcoming.length === 0 ? (
              <div className="flex items-center gap-3 rounded-lg border border-slate-100 bg-slate-50/50 px-4 py-5 text-sm text-slate-500">
                <Wrench className="h-4 w-4 text-slate-300" />
                No pending service tasks.
              </div>
            ) : (
              upcoming.map((s) => (
                <div key={s.id} className="flex items-center gap-3 rounded-lg border border-slate-100 px-4 py-3.5 transition hover:border-slate-200 hover:bg-slate-50/50">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Wrench className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-slate-800">{s.service_type}</p>
                    <p className="text-xs text-slate-500">{s.asset_name || "Asset"} · {s.scheduled_date || "—"}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`h-2 w-2 rounded-full ${STATUS_DOT[s.status] || "bg-slate-300"}`} />
                    <span className="text-xs font-medium capitalize text-slate-600">{s.status.replace(/_/g, " ")}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Compliance alerts */}
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-800">Compliance Alerts</h2>
            <Link to="/customer/certificates" className="text-xs font-medium text-rose-600 hover:underline">
              View all
            </Link>
          </div>
          <div className="space-y-3">
            {complianceAlerts.length === 0 ? (
              <div className="flex items-center gap-3 rounded-lg border border-emerald-100 bg-emerald-50/40 px-4 py-5 text-sm text-emerald-700">
                <ShieldCheck className="h-4 w-4 text-emerald-500" />
                All certificates are valid.
              </div>
            ) : (
              complianceAlerts.map((c) => (
                <div key={c.id} className="flex items-center gap-3 rounded-lg border border-slate-100 px-4 py-3.5 transition hover:border-slate-200 hover:bg-slate-50/50">
                  <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${c.status === "expired" ? "bg-red-50 text-red-600" : "bg-orange-50 text-orange-600"}`}>
                    <AlertCircle className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-slate-800">{c.title}</p>
                    <p className="text-xs text-slate-500">Expires {c.expiry_date || "—"}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`h-2 w-2 rounded-full ${STATUS_DOT[c.status] || "bg-slate-300"}`} />
                    <span className={`text-xs font-medium capitalize ${c.status === "expired" ? "text-red-600" : "text-orange-600"}`}>
                      {c.status.replace(/_/g, " ")}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Spend chart */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold text-slate-800">Spend</h2>
            <p className="text-xs text-slate-500">Last 6 months</p>
          </div>
          <div className="flex items-center gap-1.5 rounded-lg bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-600">
            <TrendingUp className="h-3 w-3" />
            +12.4%
          </div>
        </div>
        <div className="h-60">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={spendData} barCategoryGap="28%" margin={{ top: 8, right: 0, left: -12, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="m" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
              <YAxis
                tick={{ fontSize: 12, fill: "#94a3b8" }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(v) => `${v / 1000}k`}
              />
              <Tooltip
                cursor={{ fill: "#fff1f2" }}
                formatter={(v) => [formatINR(v), "Spend"]}
                contentStyle={{ borderRadius: 10, border: "1px solid #e2e8f0", fontSize: 12, boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }}
              />
              <Bar dataKey="v" fill="#e11d48" radius={[6, 6, 0, 0]} maxBarSize={48} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recommended for you */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-800">Recommended for You</h2>
          <Link to="/customer/marketplace" className="flex items-center gap-1 text-xs font-medium text-rose-600 hover:underline">
            View all <ArrowRight className="h-3 w-3" />
          </Link>
        </div>
        {products.loading ? (
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-52 animate-pulse rounded-lg bg-slate-100" />
            ))}
          </div>
        ) : recommended.length === 0 ? (
          <div className="flex items-center gap-3 rounded-lg border border-slate-100 bg-slate-50/50 px-4 py-8 text-sm text-slate-500">
            <ShoppingBag className="h-4 w-4 text-slate-300" />
            No recommendations yet.
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {recommended.map((p) => (
              <div key={p.id} className="group overflow-hidden rounded-lg border border-slate-100 bg-white transition hover:border-slate-200 hover:shadow-sm">
                <Link to={`/customer/marketplace/${p.id}`} className="block aspect-square overflow-hidden bg-slate-50">
                  {p.image_url ? (
                    <Image src={p.image_url} fittingType="fill" className="h-full w-full transition group-hover:scale-105" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-slate-50 text-slate-300">
                      <ShoppingBag className="h-8 w-8" />
                    </div>
                  )}
                </Link>
                <div className="p-3">
                  <Link to={`/customer/marketplace/${p.id}`} className="line-clamp-1 text-xs font-semibold text-slate-800 hover:text-rose-600">
                    {p.name}
                  </Link>
                  <div className="mt-0.5 flex items-center gap-1 text-[11px] text-slate-500">
                    <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                    {p.rating || "New"}
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-sm font-bold text-slate-900">{formatINR(p.price)}</span>
                    <button
                      onClick={() => add(p)}
                      className="flex items-center gap-1 rounded-md bg-rose-600 px-2.5 py-1.5 text-[11px] font-semibold text-white hover:bg-rose-700"
                    >
                      <ShoppingCart className="h-3 w-3" /> Add
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}