import React from "react";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { KpiCard, PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { ClipboardCheck, Award, Flame, AlertTriangle, ShieldCheck, Bell } from "lucide-react";

export default function Compliance() {
  const orgs = useList("Organization", {}, "-created_date", 50);
  const certs = useList("Certificate", {}, "expiry_date", 100);
  const nocs = useList("NOC", {}, "expiry_date", 100);
  const capas = useList("CAPA", {}, "-created_date", 100);
  const { toast } = useToast();

  const score = orgs.data.length ? Math.round(orgs.data.reduce((s, o) => s + (o.compliance_score || 0), 0) / orgs.data.length) : 0;
  const expiring = certs.data.filter((c) => c.status === "expiring_soon");
  const expired = certs.data.filter((c) => c.status === "expired");
  const openCapas = capas.data.filter((c) => c.status !== "closed");
  const nocAlerts = nocs.data.filter((n) => n.status !== "valid");

  const remind = async (c) => {
    try {
      await base44.entities.AppNotification.create({
        user_id: "demo", title: "Certificate renewal reminder",
        message: `${c.title} expires on ${c.expiry_date}. Schedule renewal soon.`, type: "certificate", link: "/certificates",
      });
      toast({ title: "Reminder sent", description: `Renewal reminder for ${c.title}.` });
    } catch (e) {
      toast({ title: "Failed", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div>
      <PageHeader title="Compliance Management" icon={ClipboardCheck} subtitle="Certificates, NOC, CAPA and your compliance posture — in one view." />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <KpiCard label="Compliance Score" value={`${score}%`} icon={ShieldCheck} tone="green" sub="Average across organizations" />
        <KpiCard label="Expiring Certificates" value={expiring.length} icon={Award} tone="amber" />
        <KpiCard label="Expired Certificates" value={expired.length} icon={AlertTriangle} tone="rose" />
        <KpiCard label="NOC Alerts" value={nocAlerts.length} icon={Flame} tone="violet" />
        <KpiCard label="Open CAPA" value={openCapas.length} icon={ClipboardCheck} tone="blue" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <SectionCard title="Certificates Needing Attention">
          {certs.data.length === 0 ? <EmptyState icon={Award} title="No certificates" /> : (
            <div className="divide-y divide-slate-50">
              {certs.data.filter((c) => c.status !== "valid").map((c) => (
                <div key={c.id} className="flex items-center gap-3 px-5 py-3.5">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-50 text-amber-600"><Award className="h-4 w-4" /></div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-slate-800">{c.title}</p>
                    <p className="text-xs text-slate-500">{c.asset_name || "—"} · expires {c.expiry_date}</p>
                  </div>
                  <StatusBadge status={c.status} tone={statusTone(c.status)} />
                  <Button size="sm" variant="ghost" onClick={() => remind(c)} title="Send renewal reminder"><Bell className="h-3.5 w-3.5" /></Button>
                </div>
              ))}
              {certs.data.every((c) => c.status === "valid") && <EmptyState icon={ShieldCheck} title="All certificates valid" description="Nothing expiring soon." />}
            </div>
          )}
        </SectionCard>

        <SectionCard title="Fire NOC Status">
          {nocs.data.length === 0 ? <EmptyState icon={Flame} title="No NOC records" /> : (
            <div className="divide-y divide-slate-50">
              {nocs.data.map((n) => (
                <div key={n.id} className="flex items-center gap-3 px-5 py-3.5">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-rose-50 text-rose-600"><Flame className="h-4 w-4" /></div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-mono text-sm font-medium text-slate-800">{n.noc_number}</p>
                    <p className="text-xs text-slate-500">{n.site_name} · {n.authority} · valid till {n.expiry_date}</p>
                  </div>
                  <StatusBadge status={n.status} tone={statusTone(n.status)} />
                </div>
              ))}
            </div>
          )}
        </SectionCard>
      </div>

      <div className="mt-6">
        <SectionCard title="Open CAPA">
          {openCapas.length === 0 ? <EmptyState icon={ClipboardCheck} title="No open CAPA" description="All corrective actions are closed." /> : (
            <div className="divide-y divide-slate-50">
              {openCapas.map((c) => (
                <div key={c.id} className="flex items-center gap-3 px-5 py-3.5">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-50 text-blue-600"><ClipboardCheck className="h-4 w-4" /></div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-slate-800">{c.finding}</p>
                    <p className="text-xs text-slate-500">{c.capa_number} · {c.asset_name || "General"} · target {c.target_date || "—"}</p>
                  </div>
                  <StatusBadge status={c.status} tone={statusTone(c.status)} />
                </div>
              ))}
            </div>
          )}
        </SectionCard>
      </div>
    </div>
  );
}