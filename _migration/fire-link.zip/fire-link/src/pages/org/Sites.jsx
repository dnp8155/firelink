import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { Building2, MapPin, Plus, Layers, Building } from "lucide-react";

export default function Sites() {
  const { data: sites, loading, reload } = useList("Site", {}, "-created_date", 100);
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: "", address: "", city: "", state: "", floors: 1, organization_id: "org_patel", organization_name: "Patel Enterprises" });

  const submit = async () => {
    if (!form.name) { toast({ title: "Site name is required", variant: "destructive" }); return; }
    setSaving(true);
    try {
      await base44.entities.Site.create(form);
      toast({ title: "Site created", description: form.name });
      setOpen(false);
      setForm({ name: "", address: "", city: "", state: "", floors: 1, organization_id: "org_patel", organization_name: "Patel Enterprises" });
      reload();
    } catch (e) {
      toast({ title: "Failed to create site", description: e.message, variant: "destructive" });
    } finally { setSaving(false); }
  };

  return (
    <div>
      <PageHeader
        title="Sites & Buildings"
        icon={Building2}
        subtitle="Your organization's physical locations — sites, buildings and floors."
        actions={<Button onClick={() => setOpen(true)}><Plus className="h-4 w-4" /> Add Site</Button>}
      />
      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-40 animate-pulse rounded-2xl bg-slate-100" />)}</div>
      ) : sites.length === 0 ? (
        <SectionCard><EmptyState icon={Building2} title="No sites yet" description="Create your first site to start assigning assets." /></SectionCard>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {sites.map((s) => (
            <SectionCard key={s.id}>
              <div className="p-5">
                <div className="flex items-start justify-between">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600"><Building2 className="h-5 w-5" /></div>
                  <span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-semibold uppercase tracking-wide text-slate-500">{s.organization_name}</span>
                </div>
                <p className="mt-3 text-sm font-bold text-slate-900">{s.name}</p>
                <p className="mt-1 flex items-start gap-1 text-xs text-slate-500"><MapPin className="mt-0.5 h-3 w-3 shrink-0" /> {s.address}, {s.city}, {s.state}</p>
                <div className="mt-3 flex flex-wrap gap-2 text-[11px]">
                  <span className="flex items-center gap-1 rounded-full bg-slate-50 px-2 py-1 font-medium text-slate-600"><Layers className="h-3 w-3" /> {s.floors || 1} floors</span>
                  {(s.buildings || []).map((b) => (
                    <span key={b} className="flex items-center gap-1 rounded-full bg-blue-50 px-2 py-1 font-medium text-blue-700"><Building className="h-3 w-3" /> {b}</span>
                  ))}
                </div>
              </div>
            </SectionCard>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add Site</DialogTitle></DialogHeader>
          <div className="space-y-4 py-1">
            <div className="space-y-1.5">
              <Label>Site Name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Ahmedabad Plant" />
            </div>
            <div className="space-y-1.5">
              <Label>Address</Label>
              <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="Street / industrial area" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>City</Label>
                <Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>State</Label>
                <Input value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Organization</Label>
                <select value={form.organization_id} onChange={(e) => { const o = e.target.value; setForm({ ...form, organization_id: o, organization_name: o === "org_abc" ? "ABC Infrastructure Ltd" : "Patel Enterprises" }); }} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-rose-300">
                  <option value="org_patel">Patel Enterprises</option>
                  <option value="org_abc">ABC Infrastructure Ltd</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <Label>Floors</Label>
                <Input type="number" min="1" value={form.floors} onChange={(e) => setForm({ ...form, floors: Number(e.target.value) })} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={submit} disabled={saving}>{saving ? "Creating…" : "Create Site"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}