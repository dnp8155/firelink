import React from "react";
import { useList } from "@/hooks/useList";
import { KpiCard, PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { Building2, Boxes, ClipboardCheck, Award, AlertTriangle, FileText, Gauge, IndianRupee } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from "recharts";
import { formatINR } from "@/hooks/useList";

const monthKey = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
const monthLabel = (d) => d.toLocaleString("en", { month: "short" });

export default function OrgDashboard() {
  const assets = useList("Asset", {}, "-created_date", 300);
  const sites = useList("Site", {}, "-created_date", 100);
  const certs = useList("Certificate", {}, "-created_date", 200);
  const rfqs = useList("RFQ", {}, "-created_date", 100);
  const capas = useList("CAPA", {}, "-created_date", 100);
  const orders = useList("Order", {}, "-created_date", 300);

  // ---- All metrics derive from real records (no fallbacks) ----
  const dueInspections = assets.data.filter((a) => a.next_inspection_date && new Date(a.next_inspection_date) <= new Date(Date.now() + 14 * 86400000)).length;
  const expiringCerts = certs.data.filter((c) => ["expiring_soon", "expired"].includes(c.status)).length;
  const openCapa = capas.data.filter((c) => c.status !== "closed").length;
  const openRfqs = rfqs.data.filter((r) => ["open", "quoted"].includes(r.status)).length;
  const quotedRfqs = rfqs.data.filter((r) => r.status === "quoted").length;
  // Explainable compliance score: penalties for overdue inspections, expiring/expired certs and open CAPA
  const overdueAssets = assets.data.filter((a) => a.next_inspection_date && new Date(a.next_inspection_date) < new Date()).length;
  const complianceScore = Math.max(0, Math.min(100, 100 - overdueAssets * 5 - expiringCerts * 5 - openCapa * 4));

  const conditionData = ["good", "needs_attention", "faulty", "expired"].map((c) => ({
    m: c.replace("_", " "),
    v: assets.data.filter((a) => (a.condition || "good") === c).length,
  }));

  const statusData = ["active", "under_maintenance", "inactive", "decommissioned"].map((s) => ({
    m: s.replace(/_/g, " "),
    v: assets.data.filter((a) => a.status === s).length,
  }));

  const spendByMonth = {};
  orders.data.forEach((o) => {
    if (!o.created_date) return;
    spendByMonth[monthKey(new Date(o.created_date))] = (spendByMonth[monthKey(new Date(o.created_date))] || 0) + (o.total || 0);
  });
  const spendData = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i);
    spendData.push({ m: monthLabel(d), v: spendByMonth[monthKey(d)] || 0 });
  }
  const totalSpend = orders.data.reduce((s, o) => s + (o.total || 0), 0);

  return (
    <div>
      <PageHeader title="Organization Dashboard" subtitle="Operations, procurement and compliance across your sites." />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="Total Sites" value={sites.data.length} icon={Building2} tone="blue" />
        <KpiCard label="Total Assets" value={assets.data.length} icon={Boxes} tone="rose" />
        <KpiCard label="Due Inspections (14d)" value={dueInspections} icon={ClipboardCheck} tone="amber" />
        <KpiCard label="Expiring Certificates" value={expiringCerts} icon={Award} tone="violet" />
      </div>
      <div className="mt-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="Open CAPA" value={openCapa} icon={AlertTriangle} tone="rose" />
        <KpiCard label="Open RFQs" value={openRfqs} icon={FileText} tone="teal" />
        <KpiCard label="Quotations to Review" value={quotedRfqs} icon={IndianRupee} tone="slate" />
        <KpiCard label="Compliance Score" value={`${complianceScore}%`} icon={Gauge} tone="green" />
      </div>

      {(overdueAssets > 0 || expiringCerts > 0 || openCapa > 0) && (
        <div className="mt-4 rounded-2xl bg-amber-50 p-4 ring-1 ring-amber-100">
          <p className="text-xs font-bold uppercase tracking-wide text-amber-700">Compliance is reduced because</p>
          <ul className="mt-1.5 space-y-0.5 text-xs text-amber-700">
            {overdueAssets > 0 && <li>— {overdueAssets} asset(s) overdue for inspection</li>}
            {expiringCerts > 0 && <li>— {expiringCerts} certificate(s) expired or expiring soon</li>}
            {openCapa > 0 && <li>— {openCapa} CAPA(s) open</li>}
          </ul>
        </div>
      )}

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <SectionCard title="Assets by Condition">
          <div className="h-60 p-4">
            {assets.data.length === 0 ? <EmptyState icon={Boxes} title="No assets registered" description="Register assets to see condition insights." /> : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={conditionData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="m" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0" }} />
                  <Bar dataKey="v" fill="#6366f1" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </SectionCard>
        <SectionCard title="Asset Status">
          <div className="h-60 p-4">
            {assets.data.length === 0 ? <EmptyState icon={Boxes} title="No assets registered" /> : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={statusData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="m" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0" }} />
                  <Bar dataKey="v" fill="#e11d48" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </SectionCard>
      </div>

      <div className="mt-6">
        <SectionCard title={`Order Spend by Month — ${formatINR(totalSpend)} total`}>
          <div className="h-56 p-4">
            {orders.data.length === 0 ? <EmptyState icon={IndianRupee} title="No orders yet" description="Your procurement spend will chart here as orders are placed." /> : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={spendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="m" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}k`} />
                  <Tooltip formatter={(v) => formatINR(v)} contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0" }} />
                  <Bar dataKey="v" fill="#e11d48" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}