import React, { useState } from "react";
import { useAuth } from "@/lib/AuthContext";
import { useRole } from "@/lib/RoleContext";
import { ROLES } from "@/lib/roles";
import { getIcon } from "@/lib/icons";
import { PageHeader, SectionCard } from "@/components/ui-bits";
import { User, Mail, Phone, Building2, Shield, Bell, Lock, KeyRound, LogOut, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

export default function Profile() {
  const { user, logout } = useAuth();
  const { activeRole, setActiveRole } = useRole();
  const [tab, setTab] = useState("profile");

  const tabs = [
    { id: "profile", label: "Profile", icon: User },
    { id: "security", label: "Security", icon: Lock },
    { id: "roles", label: "Roles", icon: Shield },
    { id: "notifications", label: "Notifications", icon: Bell },
  ];

  return (
    <div>
      <PageHeader title="Profile & Settings" subtitle="Manage your account, security and preferences." icon={User} />

      <div className="grid gap-4 lg:grid-cols-4">
        <div className="lg:col-span-1">
          <SectionCard>
            <div className="p-4">
              <div className="flex flex-col items-center text-center">
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-rose-500 to-red-700 text-2xl font-bold text-white shadow-md">
                  {(user?.full_name || "U").charAt(0).toUpperCase()}
                </div>
                <p className="mt-3 text-sm font-semibold text-slate-900">{user?.full_name || "Demo User"}</p>
                <p className="text-xs text-slate-500">{user?.email || "demo@fsc.app"}</p>
                <div className={cn("mt-2 rounded-full bg-gradient-to-r px-3 py-1 text-[11px] font-semibold text-white", ROLES[activeRole].color)}>
                  {ROLES[activeRole].label}
                </div>
              </div>
              <div className="mt-4 space-y-1">
                {tabs.map((t) => (
                  <button key={t.id} onClick={() => setTab(t.id)} className={cn("flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition", tab === t.id ? "bg-rose-50 text-rose-700" : "text-slate-600 hover:bg-slate-50")}>
                    <t.icon className="h-4 w-4" /> {t.label}
                  </button>
                ))}
                <button onClick={() => logout()} className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium text-rose-600 hover:bg-rose-50">
                  <LogOut className="h-4 w-4" /> Log out
                </button>
              </div>
            </div>
          </SectionCard>
        </div>

        <div className="lg:col-span-3">
          <SectionCard>
            {tab === "profile" && (
              <div className="p-5">
                <h3 className="mb-4 text-sm font-semibold text-slate-800">Personal Information</h3>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field icon={User} label="Full Name" value={user?.full_name || "Demo User"} />
                  <Field icon={Mail} label="Email" value={user?.email || "demo@fsc.app"} />
                  <Field icon={Phone} label="Phone" value="+91 98765 43210" />
                  <Field icon={Building2} label="Organization" value="Patel Enterprises" />
                </div>
                <div className="mt-5">
                  <h3 className="mb-3 text-sm font-semibold text-slate-800">GST & Billing</h3>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div><Label>GST Number</Label><Input defaultValue="24ABCDE1234F1Z5" /></div>
                    <div><Label>Billing Address</Label><Input defaultValue="Ahmedabad, Gujarat" /></div>
                  </div>
                </div>
                <Button className="mt-5 bg-rose-600 hover:bg-rose-700">Save Changes</Button>
              </div>
            )}
            {tab === "security" && (
              <div className="p-5">
                <h3 className="mb-4 text-sm font-semibold text-slate-800">Security</h3>
                <div className="space-y-3">
                  <SecurityItem icon={KeyRound} title="Change Password" desc="Update your account password." action="Change" />
                  <SecurityItem icon={Lock} title="Two-Factor Authentication" desc="Add an extra layer of security." action="Enable" />
                  <SecurityItem icon={LogOut} title="Active Sessions" desc="Manage logged-in devices." action="View" />
                </div>
              </div>
            )}
            {tab === "roles" && (
              <div className="p-5">
                <h3 className="mb-1 text-sm font-semibold text-slate-800">Switch Role</h3>
                <p className="mb-4 text-xs text-slate-500">Preview any role's workspace. Your data and navigation update instantly.</p>
                <div className="grid gap-2 sm:grid-cols-2">
                  {Object.entries(ROLES).map(([key, r]) => (
                    <button key={key} onClick={() => setActiveRole(key)} className={cn("flex items-center gap-3 rounded-xl border p-3 text-left transition", activeRole === key ? "border-rose-300 bg-rose-50" : "border-slate-200 hover:bg-slate-50")}>
                      {React.createElement(getIcon(r.icon), { className: "h-5 w-5 text-slate-500" })}
                      <span className="flex-1 text-sm font-medium text-slate-800">{r.label}</span>
                      {activeRole === key && <Check className="h-4 w-4 text-rose-600" />}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {tab === "notifications" && (
              <div className="p-5">
                <h3 className="mb-4 text-sm font-semibold text-slate-800">Notification Preferences</h3>
                <div className="space-y-2">
                  {["Order updates", "RFQ & quotation updates", "Certificate expiry alerts", "Service & inspection due", "Fire NOC expiry", "CAPA overdue", "Support ticket updates"].map((n, i) => (
                    <label key={n} className="flex items-center justify-between rounded-lg border border-slate-100 px-4 py-3">
                      <span className="text-sm text-slate-700">{n}</span>
                      <input type="checkbox" defaultChecked={i < 5} className="h-4 w-4 accent-rose-600" />
                    </label>
                  ))}
                </div>
              </div>
            )}
          </SectionCard>
        </div>
      </div>
    </div>
  );
}

const Field = ({ icon: Icon, label, value }) => (
  <div>
    <Label className="mb-1.5">{label}</Label>
    <div className="flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700">
      <Icon className="h-4 w-4 text-slate-400" /> {value}
    </div>
  </div>
);
const SecurityItem = ({ icon: Icon, title, desc, action }) => (
  <div className="flex items-center gap-3 rounded-xl border border-slate-100 p-4">
    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100 text-slate-500"><Icon className="h-5 w-5" /></div>
    <div className="flex-1"><p className="text-sm font-medium text-slate-800">{title}</p><p className="text-xs text-slate-500">{desc}</p></div>
    <Button variant="outline" size="sm">{action}</Button>
  </div>
);