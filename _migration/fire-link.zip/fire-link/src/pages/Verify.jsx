import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Flame, ShieldCheck, CheckCircle2, XCircle, Calendar, Building2, FileText, ArrowLeft, Printer } from "lucide-react";
import Logo from "@/components/Logo";

// Public QR verification page. Data comes from the verify_qr backend function,
// which returns only safe, non-confidential fields — no private asset details.
export default function Verify() {
  const { qrCode } = useParams();
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const res = await base44.functions.invoke("verify_qr", { qr_code: qrCode });
        if (!alive) return;
        const data = res.data || {};
        setResult(data && data.found === false ? null : data);
      } catch {
        if (alive) setResult(null);
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => { alive = false; };
  }, [qrCode]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-orange-50/50 print:min-h-0 print:bg-white">
      <div className="mx-auto max-w-lg px-4 py-10">
        <div className="mb-6 flex items-center gap-2.5">
          <Logo className="h-10 w-10 shrink-0 rounded-none" />
          <div>
            <p className="font-display text-base font-extrabold tracking-tight text-slate-900">FIRE<span className="text-fire-gradient">LINK</span></p>
            <p className="text-[11px] font-medium text-orange-600">QR Verification</p>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-slate-200 border-t-rose-600" />
          </div>
        ) : !result ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm">
            <XCircle className="mx-auto h-12 w-12 text-rose-500" />
            <h2 className="mt-3 text-lg font-semibold text-slate-900">Not Found</h2>
            <p className="mt-1 text-sm text-slate-500">No record matches QR code <span className="font-mono text-slate-700">{qrCode}</span>.</p>
          </div>
        ) : (
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-center gap-3 border-b border-slate-100 bg-emerald-50 px-5 py-4">
              <CheckCircle2 className="h-6 w-6 text-emerald-600" />
              <div>
                <p className="text-sm font-semibold text-emerald-800">Verified Successfully</p>
                <p className="text-xs text-emerald-600">This record is authentic and registered on FIRELINK.</p>
              </div>
            </div>
            <div className="space-y-4 p-5">
              <div className="flex items-center gap-2.5">
                <FileText className="h-4 w-4 text-slate-400" />
                <span className="text-sm font-semibold text-slate-900">{result.title}</span>
              </div>
              <Row icon={ShieldCheck} label="Reference" value={result.reference || "—"} />
              <Row icon={Building2} label="Issuing Organization" value={result.organization_name || "—"} />
              <Row icon={Calendar} label="Issue Date" value={result.issue_date || "—"} />
              {result.kind === "certificate" && (
                <Row icon={Calendar} label="Expiry Date" value={result.expiry_date || "—"} />
              )}
              <div className="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3">
                <span className="text-xs font-medium text-slate-500">Status</span>
                <span className="text-sm font-semibold capitalize text-slate-800">{(result.status || "valid").replace(/_/g, " ")}</span>
              </div>
            </div>
          </div>
        )}

        <div className="mt-4 flex flex-wrap items-center gap-2 print:hidden">
          {result && (
            <>
              <button onClick={() => window.print()} className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-medium text-white hover:bg-slate-800">
                <Printer className="h-3.5 w-3.5" /> Print / Save as PDF
              </button>
              <button onClick={async () => {
                const { downloadQrLabel } = await import("@/lib/certificate");
                downloadQrLabel(result);
              }} className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50">
                <Printer className="h-3.5 w-3.5" /> Download QR Label
              </button>
            </>
          )}
          <Link to="/" className="ml-auto inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-900 mt-auto">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to app
          </Link>
        </div>
      </div>
    </div>
  );
}

function Row({ icon: Icon, label, value }) {
  return (
    <div className="flex items-center justify-between border-b border-slate-50 pb-3">
      <span className="flex items-center gap-2 text-xs font-medium text-slate-500">
        <Icon className="h-3.5 w-3.5" /> {label}
      </span>
      <span className="text-sm font-medium text-slate-800">{value}</span>
    </div>
  );
}