import React from "react";
import Hero from "@/components/landing/Hero";
import Categories from "@/components/landing/Categories";
import FeaturedProducts from "@/components/landing/FeaturedProducts";
import ServicesSolutions from "@/components/landing/ServicesSolutions";
import WhyConnect from "@/components/landing/WhyConnect";
import AssetQr from "@/components/landing/AssetQr";
import ComplianceAi from "@/components/landing/ComplianceAi";
import VendorsSection from "@/components/landing/VendorsSection";
import Resources from "@/components/landing/Resources";

export default function Landing() {
  return (
    <div>
      <Hero />
      <Categories />
      <FeaturedProducts />
      <ServicesSolutions />
      <WhyConnect />
      <AssetQr />
      <ComplianceAi />
      <VendorsSection />
      <Resources />
    </div>
  );
}