import React from "react";
import { useList } from "@/hooks/useList";
import { KpiCard, PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Wrench, Clock, AlertCircle, CheckCircle2, MapPin, QrCode, Play } from "lucide-react";

export default function TechnicianDashboard() {
  const services = useList("ServiceRequest", {}, "-scheduled_date", 100);

  const today = services.data.slice(0, 6);
  const pending = services.data.filter((s) => ["open", "assigned"].includes(s.status)).length;
  const overdue = services.data.filter((s) => s.scheduled_date && new Date(s.scheduled_date) < new Date() && !["completed", "cancelled"].includes(s.status)).length;
  const completedToday = services.data.filter((s) => s.status === "completed").length;

  return (
    <div>
      <PageHeader title="My Jobs" subtitle="Today's field service assignments." />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="Jobs Today" value={today.length} icon={Wrench} tone="amber" />
        <KpiCard label="Pending" value={pending} icon={Clock} tone="blue" />
        <KpiCard label="Overdue" value={overdue} icon={AlertCircle} tone="rose" />
        <KpiCard label="Completed Today" value={completedToday} icon={CheckCircle2} tone="green" />
      </div>

      <div className="mt-6">
        <SectionCard title="Today's Assigned Jobs">
          {today.length === 0 ? <EmptyState icon={Wrench} title="No jobs assigned" description="Check back later for new assignments." /> : (
            <div className="grid gap-3 p-4 sm:grid-cols-2">
              {today.map((s) => (
                <div key={s.id} className="rounded-xl border border-slate-200 bg-white p-4 transition hover:shadow-sm">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-xs font-medium text-amber-600">{s.request_number}</p>
                      <p className="mt-1 text-sm font-semibold text-slate-900">{s.service_type}</p>
                    </div>
                    <StatusBadge status={s.priority} tone={statusTone(s.priority)} />
                  </div>
                  <div className="mt-3 space-y-1.5 text-xs text-slate-500">
                    <p className="flex items-center gap-1.5"><Wrench className="h-3.5 w-3.5" /> {s.asset_name || "Asset"}</p>
                    <p className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /> {s.site_name || "Site"}</p>
                    <p className="flex items-center gap-1.5"><Clock className="h-3.5 w-3.5" /> {s.scheduled_date || "Today"}</p>
                  </div>
                  <div className="mt-4 flex gap-2">
                    <button className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-amber-500 px-3 py-2 text-xs font-medium text-white hover:bg-amber-600">
                      <Play className="h-3.5 w-3.5" /> Start Job
                    </button>
                    <button className="flex items-center justify-center rounded-lg border border-slate-200 px-3 py-2 text-slate-600 hover:bg-slate-50">
                      <QrCode className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </SectionCard>
      </div>
    </div>
  );
}