import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { QrCode, ScanLine, MapPin, CalendarDays, CheckCircle2, Boxes } from "lucide-react";

export default function ScanQR() {
  const [code, setCode] = useState("");
  const [asset, setAsset] = useState(null);
  const [searching, setSearching] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const scan = async (e) => {
    e?.preventDefault();
    if (!code.trim()) return;
    setSearching(true);
    setAsset(null);
    try {
      const results = await base44.entities.Asset.filter({ qr_code: code.trim() }, "-created_date", 5);
      if (results.length === 0) {
        toast({ title: "Asset not found", description: "No asset matches this QR code.", variant: "destructive" });
      } else {
        setAsset(results[0]);
      }
    } catch (err) {
      toast({ title: "Scan failed", description: err.message, variant: "destructive" });
    } finally { setSearching(false); }
  };

  const logInspection = async () => {
    if (!asset) return;
    const today = new Date().toISOString().slice(0, 10);
    const next = new Date(Date.now() + 90 * 864e5).toISOString().slice(0, 10);
    try {
      await base44.entities.Asset.update(asset.id, { last_inspection_date: today, next_inspection_date: next, condition: "good", status: "active" });
      await base44.entities.AuditLog.create({ user_name: "Amit Sharma", user_id: "tech_amit", action: "Inspection completed via QR scan", module: "Asset", entity_id: asset.asset_code });
      toast({ title: "Inspection logged", description: `${asset.asset_code} · next due ${next}` });
      setAsset({ ...asset, last_inspection_date: today, next_inspection_date: next, condition: "good" });
    } catch (err) {
      toast({ title: "Failed to log", description: err.message, variant: "destructive" });
    }
  };

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Scan Asset QR" icon={QrCode} subtitle="Enter or scan the QR code on any fire safety asset." />

      <form onSubmit={scan} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <ScanLine className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
            <input
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="e.g. QR-AST-000001"
              className="w-full rounded-xl border border-slate-200 py-3 pl-11 pr-3 text-base outline-none focus:border-rose-300"
            />
          </div>
          <Button type="submit" size="lg" disabled={searching}>{searching ? "Searching…" : "Verify Asset"}</Button>
        </div>
        <p className="mt-2 text-xs text-slate-400">Try a demo code: QR-AST-000001</p>
      </form>

      {asset && (
        <SectionCard title="Asset Found" className="mt-5">
          <div className="p-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-mono text-xs text-slate-400">{asset.asset_code}</p>
                <h3 className="mt-0.5 text-lg font-bold text-slate-900">{asset.name}</h3>
                <p className="text-sm text-slate-500">{asset.brand} · {asset.category}</p>
              </div>
              <StatusBadge status={asset.condition} tone={statusTone(asset.condition)} />
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
              <div className="rounded-xl bg-slate-50 p-3">
                <p className="flex items-center gap-1.5 text-slate-500"><MapPin className="h-3.5 w-3.5" /> Location</p>
                <p className="mt-1 font-semibold text-slate-800">{asset.site_name}</p>
                <p className="text-slate-500">{asset.building} · {asset.floor} · {asset.zone}</p>
              </div>
              <div className="rounded-xl bg-slate-50 p-3">
                <p className="flex items-center gap-1.5 text-slate-500"><CalendarDays className="h-3.5 w-3.5" /> Inspection</p>
                <p className="mt-1 font-semibold text-slate-800">Last: {asset.last_inspection_date || "—"}</p>
                <p className="text-slate-500">Next due: {asset.next_inspection_date || "—"}</p>
              </div>
            </div>
            <div className="mt-5 flex flex-col gap-2 sm:flex-row">
              <Button onClick={logInspection} className="flex-1"><CheckCircle2 className="h-4 w-4" /> Log Inspection (Done Today)</Button>
              <Button variant="outline" className="flex-1" onClick={() => navigate("/technician/inspections")}><Boxes className="h-4 w-4" /> View All Inspections</Button>
            </div>
          </div>
        </SectionCard>
      )}

      {!asset && !searching && (
        <SectionCard className="mt-5">
          <EmptyState icon={QrCode} title="Scan to begin" description="Point your camera at the asset QR code or type the code above to pull up asset details, history and log inspections." />
        </SectionCard>
      )}
    </div>
  );
}