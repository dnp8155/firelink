import React from "react";
import { base44 } from "@/api/base44Client";
import { useList } from "@/hooks/useList";
import { PageHeader, SectionCard, EmptyState } from "@/components/ui-bits";
import { StatusBadge, statusTone } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { ClipboardCheck, CheckCircle2, MapPin, CalendarDays, AlertCircle } from "lucide-react";

const today = () => new Date().toISOString().slice(0, 10);
const plus90 = () => new Date(Date.now() + 90 * 864e5).toISOString().slice(0, 10);

export default function Inspections() {
  const { data: assets, loading, reload } = useList("Asset", {}, "next_inspection_date", 200);
  const { toast } = useToast();

  const due = assets.filter((a) => !a.next_inspection_date || a.next_inspection_date <= today() || a.condition === "needs_attention" || a.condition === "faulty");

  const markInspected = async (a) => {
    try {
      await base44.entities.Asset.update(a.id, { last_inspection_date: today(), next_inspection_date: plus90(), condition: "good", status: "active" });
      await base44.entities.AuditLog.create({ user_name: "Amit Sharma", user_id: "tech_amit", action: "Asset inspection completed", module: "Asset", entity_id: a.asset_code });
      toast({ title: "Inspection complete", description: `${a.asset_code} · next due ${plus90()}` });
      reload();
    } catch (e) {
      toast({ title: "Update failed", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div>
      <PageHeader title="Inspections" icon={ClipboardCheck} subtitle="Assets due for inspection and their schedules." />
      <div className="mb-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <SectionCard><div className="p-4"><p className="text-xs text-slate-500">Total Assets</p><p className="mt-1 text-2xl font-bold text-slate-900">{assets.length}</p></div></SectionCard>
        <SectionCard><div className="p-4"><p className="text-xs text-slate-500">Due for Inspection</p><p className="mt-1 text-2xl font-bold text-amber-600">{due.length}</p></div></SectionCard>
        <SectionCard><div className="p-4"><p className="text-xs text-slate-500">Needs Attention</p><p className="mt-1 text-2xl font-bold text-rose-600">{assets.filter((a) => a.condition === "needs_attention").length}</p></div></SectionCard>
        <SectionCard><div className="p-4"><p className="text-xs text-slate-500">Faulty</p><p className="mt-1 text-2xl font-bold text-rose-700">{assets.filter((a) => a.condition === "faulty").length}</p></div></SectionCard>
      </div>

      {loading ? (
        <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-slate-100" />)}</div>
      ) : assets.length === 0 ? (
        <SectionCard><EmptyState icon={ClipboardCheck} title="No assets" description="Assets registered by organizations will appear here." /></SectionCard>
      ) : (
        <SectionCard title={due.length ? `Due Now (${due.length})` : "All Up to Date"}>
          <div className="divide-y divide-slate-50">
            {assets.map((a) => {
              const isDue = due.includes(a);
              return (
                <div key={a.id} className="flex flex-col gap-2 px-5 py-3.5 sm:flex-row sm:items-center">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-blue-600"><MapPin className="h-5 w-5" /></div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-mono text-xs text-slate-400">{a.asset_code}</p>
                      {isDue && <span className="flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[10px] font-semibold text-amber-600"><AlertCircle className="h-3 w-3" /> Due</span>}
                    </div>
                    <p className="text-sm font-semibold text-slate-800">{a.name}</p>
                    <p className="flex items-center gap-1 text-xs text-slate-500"><CalendarDays className="h-3 w-3" /> Last: {a.last_inspection_date || "—"} · Next: {a.next_inspection_date || "—"} · {a.building}, {a.site_name}</p>
                  </div>
                  <StatusBadge status={a.condition} tone={statusTone(a.condition)} />
                  {isDue && <Button size="sm" onClick={() => markInspected(a)}><CheckCircle2 className="h-3.5 w-3.5" /> Mark Inspected</Button>}
                </div>
              );
            })}
          </div>
        </SectionCard>
      )}
    </div>
  );
}