import React, { useState, useEffect, useRef } from "react";

const DESKTOP_VIDEO = "https://media.base44.com/videos/public/6aa4425cbf7ee7adfbdf102e/13752a5a6_bhai_dkeh_yeh_meri_app_k_liye.mp4";
const MOBILE_VIDEO = "https://media.base44.com/videos/public/6aa4425cbf7ee7adfbdf102e/5f871f9d6_NHI_LOGO_DEKH_BHAI_LOGO_MESE_F.mp4";
const STORAGE_KEY = "firelink_splash_shown";

function getVideoUrl() {
  if (typeof window !== "undefined" && window.innerWidth < 1024) {
    return MOBILE_VIDEO;
  }
  return DESKTOP_VIDEO;
}

export default function SplashScreen({ children }) {
  const [showSplash, setShowSplash] = useState(false);
  const [videoUrl, setVideoUrl] = useState(DESKTOP_VIDEO);
  const videoRef = useRef(null);

  useEffect(() => {
    setVideoUrl(getVideoUrl());
    try {
      const seen = localStorage.getItem(STORAGE_KEY);
      if (!seen) {
        setShowSplash(true);
      }
    } catch {
      setShowSplash(true);
    }
  }, []);

  useEffect(() => {
    if (showSplash && videoRef.current) {
      const v = videoRef.current;
      v.muted = true;
      v.play().catch(() => {
        v.muted = true;
        v.play().catch(() => {});
      });
    }
  }, [showSplash, videoUrl]);

  const handleEnd = () => {
    try {
      localStorage.setItem(STORAGE_KEY, "1");
    } catch {}
    setShowSplash(false);
  };

  const handleSkip = () => {
    try {
      localStorage.setItem(STORAGE_KEY, "1");
    } catch {}
    setShowSplash(false);
  };

  if (!showSplash) return <>{children}</>;

  return (
    <>
      {children}
      <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black">
        <video
          ref={videoRef}
          src={videoUrl}
          autoPlay
          muted
          playsInline
          onEnded={handleEnd}
          onError={handleSkip}
          className="h-full w-full object-contain"
        />
        <button
          onClick={handleSkip}
          className="absolute bottom-6 right-6 rounded-full bg-white/10 px-5 py-2 text-sm font-medium text-white/70 backdrop-blur-sm transition hover:bg-white/20 hover:text-white"
        >
          Skip
        </button>
      </div>
    </>
  );
}