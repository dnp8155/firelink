import React from "react";
import { Image } from "@/components/ui/image";
import { cn } from "@/lib/utils";

export const LOGO_URL =
  "https://media.base44.com/images/public/6aa4425cbf7ee7adfbdf102e/5e0b617ce_firelink_logo.png";

export default function Logo({ className }) {
  return (
    <span className={cn("block shrink-0 overflow-hidden rounded-none", className)}>
      <Image src={LOGO_URL} alt="FIRELINK" fittingType="fit" className="h-full w-full" />
    </span>
  );
}